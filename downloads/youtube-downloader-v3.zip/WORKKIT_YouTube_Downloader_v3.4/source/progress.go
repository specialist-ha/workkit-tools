package main

// 진행률 계산 로직 (플랫폼 독립 — Linux에서도 단위 테스트 가능)
//
// yt-dlp는 "영상 + 음성"을 따로 받은 뒤 합치기 때문에, 파일별 %를 그대로 쓰면
// 0→100%가 두 번 반복된다. 여기서는 실제 바이트 수를 합산해 영상 1개 기준
// 0→100%가 한 번만, 뒤로 가지 않고 진행되도록 계산한다.

import (
	"fmt"
	"strconv"
	"strings"
)

const (
	itemPrefix = "WK_ITEM:"
	progPrefix = "WK_PROG:"
)

// yt-dlp 출력 템플릿. 제목에 '|'가 들어갈 수 있으므로 제목은 항상 마지막 필드.
const itemTemplate = "before_dl:" + itemPrefix +
	"%(playlist_index|1)s|%(n_entries,playlist_count|1)s|" +
	"%(requested_formats.0.filesize,requested_formats.0.filesize_approx|0)s|" +
	"%(requested_formats.1.filesize,requested_formats.1.filesize_approx|0)s|" +
	"%(filesize,filesize_approx|0)s|%(title)s"

const progressTemplate = "download:" + progPrefix +
	"%(progress.status)s|%(progress.downloaded_bytes|0)s|" +
	"%(progress.total_bytes,progress.total_bytes_estimate|0)s|" +
	"%(progress.speed|0)s|%(progress.eta|-1)s|%(progress.filename)s"

type itemInfo struct {
	Index, Count int
	Parts        []float64 // 예상 파트 크기(바이트). 모르면 0
	Title        string
}

type progressLine struct {
	Status     string
	Downloaded float64
	Total      float64
	Speed      float64
	ETA        float64
	Filename   string
}

func num(s string) float64 {
	s = strings.TrimSpace(s)
	if s == "" || s == "NA" || s == "None" {
		return 0
	}
	f, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return 0
	}
	return f
}

func parseItemLine(line string) (itemInfo, bool) {
	if !strings.HasPrefix(line, itemPrefix) {
		return itemInfo{}, false
	}
	f := strings.SplitN(strings.TrimPrefix(line, itemPrefix), "|", 6)
	if len(f) < 6 {
		return itemInfo{}, false
	}
	it := itemInfo{Index: int(num(f[0])), Count: int(num(f[1])), Title: strings.TrimSpace(f[5])}
	if it.Index < 1 {
		it.Index = 1
	}
	if it.Count < it.Index {
		it.Count = it.Index
	}
	a, b, single := num(f[2]), num(f[3]), num(f[4])
	switch {
	case a > 0 || b > 0:
		it.Parts = []float64{a, b}
	default:
		it.Parts = []float64{single}
	}
	return it, true
}

func parseProgressLine(line string) (progressLine, bool) {
	if !strings.HasPrefix(line, progPrefix) {
		return progressLine{}, false
	}
	f := strings.SplitN(strings.TrimPrefix(line, progPrefix), "|", 6)
	if len(f) < 6 {
		return progressLine{}, false
	}
	return progressLine{
		Status:     strings.TrimSpace(f[0]),
		Downloaded: num(f[1]),
		Total:      num(f[2]),
		Speed:      num(f[3]),
		ETA:        num(f[4]),
		Filename:   strings.TrimSpace(f[5]),
	}, true
}

// byteTracker: 한 영상(=한 번의 before_dl) 동안 여러 파트의 바이트를 누적한다.
type byteTracker struct {
	expected []float64 // 파트별 예상 크기
	actual   []float64 // 끝난 파트의 실제 크기
	file     string
	curTotal float64
	best     float64 // 지금까지 보고한 최대 비율 (뒤로 가지 않게)
}

func newByteTracker(parts []float64) *byteTracker {
	exp := append([]float64(nil), parts...)
	if len(exp) == 0 {
		exp = []float64{0}
	}
	return &byteTracker{expected: exp}
}

// update는 0~1 사이의 비율을 돌려준다.
func (t *byteTracker) update(p progressLine) float64 {
	if p.Filename != "" && p.Filename != t.file {
		if t.file != "" {
			t.actual = append(t.actual, t.curTotal)
		}
		t.file = p.Filename
		t.curTotal = 0
	}
	idx := len(t.actual)
	total := p.Total
	if total <= 0 && idx < len(t.expected) {
		total = t.expected[idx]
	}
	if p.Status == "finished" && p.Downloaded > 0 {
		total = p.Downloaded
	}
	if total > 0 {
		t.curTotal = total
	}
	down := p.Downloaded
	if total > 0 && down > total {
		down = total
	}

	var done, grand float64
	for _, a := range t.actual {
		done += a
		grand += a
	}
	grand += t.curTotal
	for i := idx + 1; i < len(t.expected); i++ {
		if t.expected[i] > 0 {
			grand += t.expected[i]
		} else {
			grand += t.curTotal // 크기를 모르는 다음 파트는 현재 파트와 비슷하다고 가정
		}
	}
	frac := 0.0
	if grand > 0 {
		frac = (done + down) / grand
	}
	if frac > 1 {
		frac = 1
	}
	if frac < t.best {
		frac = t.best
	}
	t.best = frac
	return frac
}

func humanBytes(b float64) string {
	switch {
	case b >= 1<<30:
		return fmt.Sprintf("%.2f GB", b/(1<<30))
	case b >= 1<<20:
		return fmt.Sprintf("%.1f MB", b/(1<<20))
	case b >= 1<<10:
		return fmt.Sprintf("%.0f KB", b/(1<<10))
	default:
		return fmt.Sprintf("%.0f B", b)
	}
}

func humanETA(sec float64) string {
	if sec < 0 {
		return ""
	}
	s := int(sec + 0.5)
	if s >= 3600 {
		return fmt.Sprintf("%d시간 %d분", s/3600, (s%3600)/60)
	}
	if s >= 60 {
		return fmt.Sprintf("%d분 %d초", s/60, s%60)
	}
	return fmt.Sprintf("%d초", s)
}

// speedText: "12.3 MB/s · 남은 시간 1분 4초"
func speedText(p progressLine) string {
	var parts []string
	if p.Speed > 0 {
		parts = append(parts, humanBytes(p.Speed)+"/s")
	}
	if e := humanETA(p.ETA); e != "" && p.Status != "finished" {
		parts = append(parts, "남은 시간 "+e)
	}
	return strings.Join(parts, " · ")
}

// postStage: yt-dlp 후처리 로그를 사용자용 단계 이름으로 바꾼다.
func postStage(line string) string {
	switch {
	case strings.HasPrefix(line, "[Merger]"):
		return "영상·음성 합치는 중"
	case strings.HasPrefix(line, "[ExtractAudio]"):
		return "MP3로 변환 중"
	case strings.HasPrefix(line, "[EmbedThumbnail]"), strings.HasPrefix(line, "[Metadata]"), strings.HasPrefix(line, "[FixupM"):
		return "마무리 중"
	case strings.HasPrefix(line, "[SubtitlesConvertor]"):
		return "자막 변환 중"
	}
	return ""
}

// isSideFile: 자막·썸네일 등 본 영상이 아닌 부가 파일
func isSideFile(name string) bool {
	n := strings.ToLower(name)
	for _, ext := range []string{".vtt", ".srt", ".ttml", ".srv1", ".srv2", ".srv3", ".json3", ".ass", ".lrc", ".jpg", ".jpeg", ".png", ".webp"} {
		if strings.HasSuffix(n, ext) {
			return true
		}
	}
	return false
}
