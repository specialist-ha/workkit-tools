//go:build windows

package main

import (
	"archive/zip"
	"bufio"
	"context"
	"crypto/tls"
	_ "embed"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

const (
	appName    = "YouTube 다운로더"
	appBrand   = "WORKKIT"
	appTitle   = "WORKKIT YouTube 다운로더"
	appVersion = "v3.4"
	buildDate  = "2026-10-26"
)

//go:embed fonts/Pretendard-Regular.otf
var fontRegular []byte

//go:embed fonts/Pretendard-SemiBold.otf
var fontSemiBold []byte

//go:embed fonts/Pretendard-Bold.otf
var fontBold []byte

// ============================================================
// Win32 상수
// ============================================================

const (
	WM_CREATE                = 0x0001
	WM_DESTROY               = 0x0002
	WM_PAINT                 = 0x000F
	WM_CLOSE                 = 0x0010
	WM_ERASEBKGND            = 0x0014
	WM_COMMAND               = 0x0111
	WM_TIMER                 = 0x0113
	WM_CTLCOLOREDIT          = 0x0133
	WM_CTLCOLORSTATIC        = 0x0138
	WM_SETFONT               = 0x0030
	WM_DRAWITEM              = 0x002B
	WM_NCHITTEST             = 0x0084
	WM_MOUSEMOVE             = 0x0200
	WM_MOUSELEAVE            = 0x02A3
	WM_SETCURSOR             = 0x0020
	EM_SETMARGINS            = 0x00D3
	EC_LEFTMARGIN            = 0x0001
	EC_RIGHTMARGIN           = 0x0002
	EN_SETFOCUS              = 0x0100
	EN_KILLFOCUS             = 0x0200
	WS_POPUP                 = 0x80000000
	WS_SYSMENU               = 0x00080000
	WS_MINIMIZEBOX           = 0x00020000
	WS_VISIBLE               = 0x10000000
	WS_CHILD                 = 0x40000000
	WS_TABSTOP               = 0x00010000
	WS_VSCROLL               = 0x00200000
	WS_CLIPCHILDREN          = 0x02000000
	ES_LEFT                  = 0x0000
	ES_MULTILINE             = 0x0004
	ES_AUTOVSCROLL           = 0x0040
	ES_AUTOHSCROLL           = 0x0080
	ES_READONLY              = 0x0800
	ES_WANTRETURN            = 0x1000
	BS_OWNERDRAW             = 0x0000000B
	SW_HIDE                  = 0
	SW_SHOW                  = 5
	SW_SHOWNORMAL            = 1
	SW_MINIMIZE              = 6
	IDC_ARROW                = 32512
	IDC_HAND                 = 32649
	MB_OK                    = 0x00000000
	MB_ICONERROR             = 0x00000010
	MB_ICONWARNING           = 0x00000030
	MB_ICONINFORMATION       = 0x00000040
	MB_YESNO                 = 0x00000004
	IDYES                    = 6
	BN_CLICKED               = 0
	EM_SETSEL                = 0x00B1
	EM_REPLACESEL            = 0x00C2
	EM_SCROLLCARET           = 0x00B7
	BIF_RETURNONLYFSDIRS     = 0x00000001
	BIF_NEWDIALOGSTYLE       = 0x00000040
	COINIT_APARTMENTTHREADED = 0x2
	CREATE_NO_WINDOW         = 0x08000000
	ODS_SELECTED             = 0x0001
	ODS_DISABLED             = 0x0004
	ODS_FOCUS                = 0x0010
	TME_LEAVE                = 0x00000002
	HTCAPTION                = 2
	GWLP_WNDPROC             = -4
	SWP_NOMOVE               = 0x0002
	SWP_NOZORDER             = 0x0004
	SPI_GETWORKAREA          = 0x0030
	LOGPIXELSY               = 90
	DT_LEFT                  = 0x00000000
	DT_CENTER                = 0x00000001
	DT_RIGHT                 = 0x00000002
	DT_VCENTER               = 0x00000004
	DT_SINGLELINE            = 0x00000020
	DT_END_ELLIPSIS          = 0x00008000
	DT_NOPREFIX              = 0x00000800
	PS_SOLID                 = 0
	NULL_BRUSH               = 5
	TRANSPARENT_BK           = 1
)

const (
	ID_URL = 1001 + iota
	ID_FOLDER
	ID_BROWSE
	ID_OPEN
	ID_FMT_VIDEO
	ID_FMT_AUDIO
	ID_Q0 // 최고 ~ 360p: ID_Q0..ID_Q0+6
	_
	_
	_
	_
	_
	_
	ID_PLAYLIST
	ID_SUBTITLE
	ID_SSL
	ID_START
	ID_CANCEL
	ID_UPDATE
	ID_LOGTOGGLE
	ID_PROGRESS
	ID_LOG
	ID_MINBTN
	ID_CLOSEBTN
)

var qualityLabels = []string{"최고", "2160p", "1440p", "1080p", "720p", "480p", "360p"}

// ============================================================
// DLL / 프로시저
// ============================================================

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	comctl32 = syscall.NewLazyDLL("comctl32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")
	uxtheme  = syscall.NewLazyDLL("uxtheme.dll")
	ntdll    = syscall.NewLazyDLL("ntdll.dll")

	procRegisterClassExW      = user32.NewProc("RegisterClassExW")
	procCreateWindowExW       = user32.NewProc("CreateWindowExW")
	procDefWindowProcW        = user32.NewProc("DefWindowProcW")
	procShowWindow            = user32.NewProc("ShowWindow")
	procUpdateWindow          = user32.NewProc("UpdateWindow")
	procGetMessageW           = user32.NewProc("GetMessageW")
	procIsDialogMessageW      = user32.NewProc("IsDialogMessageW")
	procTranslateMessage      = user32.NewProc("TranslateMessage")
	procDispatchMessageW      = user32.NewProc("DispatchMessageW")
	procPostQuitMessage       = user32.NewProc("PostQuitMessage")
	procDestroyWindow         = user32.NewProc("DestroyWindow")
	procSetWindowTextW        = user32.NewProc("SetWindowTextW")
	procGetWindowTextW        = user32.NewProc("GetWindowTextW")
	procGetWindowTextLengthW  = user32.NewProc("GetWindowTextLengthW")
	procEnableWindow          = user32.NewProc("EnableWindow")
	procIsWindowEnabled       = user32.NewProc("IsWindowEnabled")
	procSendMessageW          = user32.NewProc("SendMessageW")
	procSetTimer              = user32.NewProc("SetTimer")
	procMessageBoxW           = user32.NewProc("MessageBoxW")
	procLoadCursorW           = user32.NewProc("LoadCursorW")
	procSetCursor             = user32.NewProc("SetCursor")
	procLoadIconW             = user32.NewProc("LoadIconW")
	procSetProcessDPIAware    = user32.NewProc("SetProcessDPIAware")
	procInvalidateRect        = user32.NewProc("InvalidateRect")
	procGetClientRect         = user32.NewProc("GetClientRect")
	procBeginPaint            = user32.NewProc("BeginPaint")
	procEndPaint              = user32.NewProc("EndPaint")
	procFillRect              = user32.NewProc("FillRect")
	procDrawTextW             = user32.NewProc("DrawTextW")
	procSetWindowPos          = user32.NewProc("SetWindowPos")
	procSetWindowLongPtrW     = user32.NewProc("SetWindowLongPtrW")
	procCallWindowProcW       = user32.NewProc("CallWindowProcW")
	procTrackMouseEvent       = user32.NewProc("TrackMouseEvent")
	procSetWindowRgn          = user32.NewProc("SetWindowRgn")
	procMoveWindow            = user32.NewProc("MoveWindow")
	procScreenToClient        = user32.NewProc("ScreenToClient")
	procGetDC                 = user32.NewProc("GetDC")
	procReleaseDC             = user32.NewProc("ReleaseDC")
	procSystemParametersInfoW = user32.NewProc("SystemParametersInfoW")
	procSetFocus              = user32.NewProc("SetFocus")
	procGetWindowRect         = user32.NewProc("GetWindowRect")

	procGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")

	procSHBrowseForFolderW   = shell32.NewProc("SHBrowseForFolderW")
	procSHGetPathFromIDListW = shell32.NewProc("SHGetPathFromIDListW")
	procShellExecuteW        = shell32.NewProc("ShellExecuteW")

	procCoInitializeEx = ole32.NewProc("CoInitializeEx")
	procCoUninitialize = ole32.NewProc("CoUninitialize")
	procCoTaskMemFree  = ole32.NewProc("CoTaskMemFree")

	procInitCommonControlsEx = comctl32.NewProc("InitCommonControlsEx")

	procCreateFontW            = gdi32.NewProc("CreateFontW")
	procAddFontMemResourceEx   = gdi32.NewProc("AddFontMemResourceEx")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procSetBkColor             = gdi32.NewProc("SetBkColor")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procRoundRect              = gdi32.NewProc("RoundRect")
	procCreatePen              = gdi32.NewProc("CreatePen")
	procCreateRoundRectRgn     = gdi32.NewProc("CreateRoundRectRgn")
	procGetStockObject         = gdi32.NewProc("GetStockObject")
	procGetDeviceCaps          = gdi32.NewProc("GetDeviceCaps")
	procPolygon                = gdi32.NewProc("Polygon")
	procMoveToEx               = gdi32.NewProc("MoveToEx")
	procLineTo                 = gdi32.NewProc("LineTo")

	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
	procSetWindowTheme        = uxtheme.NewProc("SetWindowTheme")
	procRtlGetVersion         = ntdll.NewProc("RtlGetVersion")
)

type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}

type MSG struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      POINT
}

type INITCOMMONCONTROLSEX struct {
	DwSize uint32
	DwICC  uint32
}

type BROWSEINFO struct {
	HwndOwner      uintptr
	PidlRoot       uintptr
	PszDisplayName *uint16
	LpszTitle      *uint16
	UlFlags        uint32
	Lpfn           uintptr
	LParam         uintptr
	IImage         int32
}

type RECT struct{ Left, Top, Right, Bottom int32 }
type POINT struct{ X, Y int32 }

type PAINTSTRUCT struct {
	Hdc         uintptr
	FErase      int32
	RcPaint     RECT
	FRestore    int32
	FIncUpdate  int32
	RgbReserved [32]byte
}

type DRAWITEMSTRUCT struct {
	CtlType    uint32
	CtlID      uint32
	ItemID     uint32
	ItemAction uint32
	ItemState  uint32
	HwndItem   uintptr
	Hdc        uintptr
	RcItem     RECT
	ItemData   uintptr
}

type TRACKMOUSEEVENT struct {
	CbSize      uint32
	DwFlags     uint32
	HwndTrack   uintptr
	DwHoverTime uint32
}

type OSVERSIONINFOW struct {
	Size, Major, Minor, Build, Platform uint32
	CSD                                 [128]uint16
}

// ============================================================
// 색상 (WORKKIT 다크 테마)
// ============================================================

func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

var (
	clrBg        = rgb(19, 19, 19)
	clrPanel     = rgb(28, 28, 28)
	clrInput     = rgb(15, 15, 15)
	clrLine      = rgb(46, 47, 47)
	clrLine2     = rgb(69, 71, 70)
	clrText      = rgb(242, 243, 242)
	clrSub       = rgb(169, 174, 171)
	clrMuted     = rgb(110, 114, 112)
	clrAccent    = rgb(9, 235, 193)
	clrAccentHi  = rgb(70, 245, 212)
	clrAccentDim = rgb(6, 160, 132)
	clrAccentBg  = rgb(30, 52, 47)
	clrOnAccent  = rgb(6, 34, 28)
	clrDanger    = rgb(255, 122, 110)
	clrWarn      = rgb(255, 192, 97)
	clrHover     = rgb(38, 38, 38)
	clrTrack     = rgb(42, 43, 43)
)

// ============================================================
// 전역 상태
// ============================================================

type controls struct {
	main, url, folder, browse, open  uintptr
	fmtVideo, fmtAudio               uintptr
	quality                          [7]uintptr
	playlist, subtitle, ssl          uintptr
	start, cancel, update, logToggle uintptr
	progress, log, minBtn, closeBtn  uintptr
	font, fontSemi, fontSmall        uintptr
	fontTitle, fontPct, fontLog      uintptr
}

var ui controls
var brushInput uintptr

var running atomic.Bool
var cancelMu sync.Mutex
var cancelCurrent context.CancelFunc

var formatSel = 0  // 0=영상, 1=음원
var qualitySel = 0 // qualityLabels 인덱스
var toggleState = map[uintptr]bool{}
var hoverState = map[uintptr]bool{}
var origProc = map[uintptr]uintptr{}
var focusedEdit uintptr
var logOpen = false
var fontFace, fontFaceSemi = "Malgun Gothic", "Malgun Gothic"

// 진행 패널 상태 (UI 스레드에서만 접근)
type progressView struct {
	stage  string  // "다운로드 중" 등
	pct    float64 // 0~100, 음수 = 진행률을 알 수 없는 단계
	count  string  // "2 / 5"
	detail string  // 영상 제목 등
	right  string  // 속도 · 남은 시간
	tone   int     // 0 보통, 1 완료, 2 경고, 3 오류
}

var pv = progressView{stage: "대기 중", pct: 0, detail: "링크를 넣고 다운로드를 시작하세요."}
var animTick int

type uiUpdate struct {
	kind   string
	text   string
	ok     bool
	stage  string
	pct    float64
	count  string
	detail string
	right  string
}

var updates = make(chan uiUpdate, 1000)

// 진행 정보 전송 (작업 스레드 → UI 스레드). 채널이 가득 차면 진행률 갱신은 건너뛴다.
func sendProgress(u uiUpdate) {
	u.kind = "progress"
	select {
	case updates <- u:
	default:
	}
}

func logLine(text string) { updates <- uiUpdate{kind: "log", text: text} }

// ============================================================
// DPI 스케일
// ============================================================

var dpiScale = 1.0

func S(v float64) int32 { return int32(math.Round(v * dpiScale)) }

func initDPI() {
	hdc, _, _ := procGetDC.Call(0)
	dpi, _, _ := procGetDeviceCaps.Call(hdc, LOGPIXELSY)
	procReleaseDC.Call(0, hdc)
	if dpi > 0 {
		dpiScale = float64(dpi) / 96.0
	}
}

// ============================================================
// 기본 유틸리티
// ============================================================

func utf16Ptr(s string) *uint16 {
	p, _ := syscall.UTF16PtrFromString(s)
	return p
}

func loword(v uintptr) uint16 { return uint16(v & 0xffff) }
func hiword(v uintptr) uint16 { return uint16((v >> 16) & 0xffff) }

func setText(hwnd uintptr, s string) {
	procSetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(utf16Ptr(s))))
}

func getText(hwnd uintptr) string {
	n, _, _ := procGetWindowTextLengthW.Call(hwnd)
	buf := make([]uint16, n+1)
	procGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}

func send(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	r, _, _ := procSendMessageW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func messageBox(hwnd uintptr, text, title string, flags uint32) int {
	r, _, _ := procMessageBoxW.Call(hwnd, uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(unsafe.Pointer(utf16Ptr(title))), uintptr(flags))
	return int(r)
}

func createControl(class, text string, style uint32, r RECT, parent uintptr, id int) uintptr {
	h, _, _ := procCreateWindowExW.Call(0,
		uintptr(unsafe.Pointer(utf16Ptr(class))), uintptr(unsafe.Pointer(utf16Ptr(text))),
		uintptr(style), uintptr(r.Left), uintptr(r.Top), uintptr(r.Right-r.Left), uintptr(r.Bottom-r.Top),
		parent, uintptr(id), 0, 0)
	if h != 0 && ui.font != 0 {
		send(h, WM_SETFONT, ui.font, 1)
	}
	return h
}

func appendLog(text string) {
	if text == "" {
		return
	}
	if !strings.HasSuffix(text, "\r\n") {
		text += "\r\n"
	}
	send(ui.log, EM_SETSEL, ^uintptr(0), ^uintptr(0))
	send(ui.log, EM_REPLACESEL, 0, uintptr(unsafe.Pointer(utf16Ptr(text))))
	send(ui.log, EM_SCROLLCARET, 0, 0)
}

func userLog(text string) { appendLog(time.Now().Format("15:04:05") + "   " + text) }

func enable(hwnd uintptr, yes bool) {
	var v uintptr
	if yes {
		v = 1
	}
	procEnableWindow.Call(hwnd, v)
	invalidate(hwnd)
}

func isEnabled(hwnd uintptr) bool { r, _, _ := procIsWindowEnabled.Call(hwnd); return r != 0 }

func invalidate(hwnd uintptr) { procInvalidateRect.Call(hwnd, 0, 0) }

func setRunningState(on bool) {
	running.Store(on)
	for _, h := range []uintptr{ui.start, ui.update, ui.url, ui.folder, ui.browse, ui.fmtVideo, ui.fmtAudio, ui.playlist, ui.subtitle, ui.ssl} {
		enable(h, !on)
	}
	for _, h := range ui.quality {
		enable(h, !on && formatSel == 0)
	}
	enable(ui.cancel, on)
	invalidate(ui.main)
}

func setProgress(stage string, pct float64, detail, right string, tone int) {
	pv.stage, pv.pct, pv.detail, pv.right, pv.tone = stage, pct, detail, right, tone
	invalidate(ui.progress)
}

func drainUpdates() {
	for {
		select {
		case u := <-updates:
			switch u.kind {
			case "log":
				userLog(u.text)
			case "progress":
				if u.stage != "" {
					pv.stage = u.stage
				}
				pv.pct = u.pct
				if u.count != "-" {
					pv.count = u.count
				}
				if u.detail != "" {
					pv.detail = u.detail
				}
				pv.right = u.right
				pv.tone = 0
				invalidate(ui.progress)
			case "done":
				setRunningState(false)
				if u.ok {
					setProgress("완료", 100, u.text, "", 1)
					messageBox(ui.main, u.text, appTitle, MB_OK|MB_ICONINFORMATION)
				} else {
					setProgress("실패", pv.pct, u.text, "", 3)
					messageBox(ui.main, u.text, appTitle, MB_OK|MB_ICONERROR)
				}
			case "donewarn":
				setRunningState(false)
				setProgress("일부 실패", 100, u.text, "", 2)
				messageBox(ui.main, u.text, appTitle, MB_OK|MB_ICONWARNING)
			case "cancelled":
				setRunningState(false)
				setProgress("취소됨", pv.pct, "작업을 취소했습니다.", "", 2)
				userLog("[취소] 작업을 중단했습니다.")
			}
		default:
			return
		}
	}
}

// ============================================================
// GDI 헬퍼
// ============================================================

func createPen(width int32, color uintptr) uintptr {
	h, _, _ := procCreatePen.Call(PS_SOLID, uintptr(width), color)
	return h
}
func createBrush(color uintptr) uintptr  { h, _, _ := procCreateSolidBrush.Call(color); return h }
func selectObj(hdc, obj uintptr) uintptr { o, _, _ := procSelectObject.Call(hdc, obj); return o }
func deleteObj(obj uintptr) {
	if obj != 0 {
		procDeleteObject.Call(obj)
	}
}

func fillRect(hdc uintptr, l, t, r, b int32, color uintptr) {
	br := createBrush(color)
	rc := RECT{l, t, r, b}
	procFillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), br)
	deleteObj(br)
}

// roundBox: 채움 + 외곽선이 있는 둥근 사각형 (stroke가 fill과 같으면 외곽선 없음)
func roundBox(hdc uintptr, l, t, r, b, radius int32, fill, stroke uintptr) {
	br := createBrush(fill)
	pen := createPen(1, stroke)
	ob, op := selectObj(hdc, br), selectObj(hdc, pen)
	procRoundRect.Call(hdc, uintptr(l), uintptr(t), uintptr(r), uintptr(b), uintptr(radius), uintptr(radius))
	selectObj(hdc, ob)
	selectObj(hdc, op)
	deleteObj(br)
	deleteObj(pen)
}

func strokeBox(hdc uintptr, l, t, r, b, radius int32, stroke uintptr, width int32) {
	pen := createPen(width, stroke)
	nb, _, _ := procGetStockObject.Call(NULL_BRUSH)
	ob, op := selectObj(hdc, nb), selectObj(hdc, pen)
	procRoundRect.Call(hdc, uintptr(l), uintptr(t), uintptr(r), uintptr(b), uintptr(radius), uintptr(radius))
	selectObj(hdc, ob)
	selectObj(hdc, op)
	deleteObj(pen)
}

func drawText(hdc uintptr, text string, x, y, w, h int32, color, font uintptr, format uint32) {
	if font != 0 {
		selectObj(hdc, font)
	}
	procSetBkMode.Call(hdc, TRANSPARENT_BK)
	procSetTextColor.Call(hdc, color)
	rc := RECT{x, y, x + w, y + h}
	procDrawTextW.Call(hdc, uintptr(unsafe.Pointer(utf16Ptr(text))), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), uintptr(format|DT_NOPREFIX))
}

func drawLine(hdc uintptr, x1, y1, x2, y2, width int32, color uintptr) {
	pen := createPen(width, color)
	op := selectObj(hdc, pen)
	procMoveToEx.Call(hdc, uintptr(x1), uintptr(y1), 0)
	procLineTo.Call(hdc, uintptr(x2), uintptr(y2))
	selectObj(hdc, op)
	deleteObj(pen)
}

func polygon(hdc uintptr, pts []POINT, color uintptr) {
	br := createBrush(color)
	pen := createPen(1, color)
	ob, op := selectObj(hdc, br), selectObj(hdc, pen)
	procPolygon.Call(hdc, uintptr(unsafe.Pointer(&pts[0])), uintptr(len(pts)))
	selectObj(hdc, ob)
	selectObj(hdc, op)
	deleteObj(br)
	deleteObj(pen)
}

// withBuffer: 깜빡임 없이 그리기 위한 메모리 DC
func withBuffer(hdc uintptr, w, h int32, draw func(mdc uintptr)) {
	mdc, _, _ := procCreateCompatibleDC.Call(hdc)
	bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
	old := selectObj(mdc, bmp)
	draw(mdc)
	procBitBlt.Call(hdc, 0, 0, uintptr(w), uintptr(h), mdc, 0, 0, 0x00CC0020)
	selectObj(mdc, old)
	procDeleteDC.Call(mdc)
	deleteObj(bmp)
}

// ============================================================
// 글꼴 (Pretendard 내장)
// ============================================================

func loadEmbeddedFonts() {
	ok := true
	for _, data := range [][]byte{fontRegular, fontSemiBold, fontBold} {
		var n uint32
		h, _, _ := procAddFontMemResourceEx.Call(uintptr(unsafe.Pointer(&data[0])), uintptr(len(data)), 0, uintptr(unsafe.Pointer(&n)))
		if h == 0 {
			ok = false
		}
	}
	if ok {
		fontFace, fontFaceSemi = "Pretendard", "Pretendard SemiBold"
	}
}

func makeFont(px float64, weight uint32, face string) uintptr {
	h, _, _ := procCreateFontW.Call(uintptr(-S(px)), 0, 0, 0, uintptr(weight), 0, 0, 0,
		1 /*DEFAULT_CHARSET*/, 0, 0, 5 /*CLEARTYPE_QUALITY*/, 0, uintptr(unsafe.Pointer(utf16Ptr(face))))
	return h
}

// ============================================================
// 레이아웃
// ============================================================

type layout struct {
	w, h, title, pad              int32
	lblLink, boxLink              RECT
	lblFolder, boxFolder          RECT
	lblFormat, lblQuality, rowFmt RECT
	rowToggle, panel, rowBtn      RECT
	boxLog, footer                RECT
}

var L layout

func computeLayout() {
	W := 760.0
	pad := 28.0
	x := pad
	cw := W - pad*2
	y := 56.0 + 22
	r := func(x, y, w, h float64) RECT { return RECT{S(x), S(y), S(x + w), S(y + h)} }

	L.w, L.title, L.pad = S(W), S(56), S(pad)
	L.lblLink = r(x, y, cw, 20)
	y += 28
	L.boxLink = r(x, y, cw, 78)
	y += 78 + 20
	L.lblFolder = r(x, y, cw, 20)
	y += 28
	L.boxFolder = r(x, y, cw-2*92-16, 40)
	y += 40 + 20
	L.lblFormat = r(x, y, 200, 20)
	L.lblQuality = r(x+212, y, 300, 20)
	y += 28
	L.rowFmt = r(x, y, cw, 36)
	y += 36 + 20
	L.rowToggle = r(x, y, cw, 26)
	y += 26 + 22
	L.panel = r(x, y, cw, 104)
	y += 104 + 16
	L.rowBtn = r(x, y, cw, 44)
	y += 44 + 16
	if logOpen {
		L.boxLog = r(x, y, cw, 110)
		y += 110 + 14
	}
	L.footer = r(x, y, cw, 18)
	y += 18 + 18
	L.h = S(y)
}

// ============================================================
// 메인 창 그리기
// ============================================================

func paintMain(hdc uintptr, w, h int32) {
	fillRect(hdc, 0, 0, w, h, clrBg)

	// 타이틀 바
	fillRect(hdc, 0, 0, w, L.title, rgb(24, 24, 24))
	drawLine(hdc, 0, L.title-1, w, L.title-1, 1, clrLine)
	lx, ly, ls := L.pad, (L.title-S(28))/2, S(28)
	roundBox(hdc, lx, ly, lx+ls, ly+ls, S(9), clrBg, clrAccent)
	cx, cy := lx+ls/2, ly+ls/2
	polygon(hdc, []POINT{{cx - S(4), cy - S(6)}, {cx - S(4), cy + S(6)}, {cx + S(6), cy}}, clrText)
	drawText(hdc, appName, lx+ls+S(12), 0, S(240), L.title, clrText, ui.fontTitle, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, appBrand, lx+ls+S(12)+S(138), 0, S(120), L.title, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	label := func(r RECT, text string) {
		drawText(hdc, text, r.Left, r.Top, r.Right-r.Left, r.Bottom-r.Top, clrSub, ui.fontSemi, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	}
	hint := func(r RECT, text string) {
		drawText(hdc, text, r.Left, r.Top, r.Right-r.Left, r.Bottom-r.Top, clrMuted, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)
	}
	inputBox := func(r RECT, edit uintptr) {
		stroke := clrLine2
		if focusedEdit == edit && isEnabled(edit) {
			stroke = clrAccent
		}
		roundBox(hdc, r.Left, r.Top, r.Right, r.Bottom, S(10), clrInput, stroke)
	}

	label(L.lblLink, "YouTube 링크")
	hint(L.lblLink, "여러 개는 줄을 바꿔 입력")
	inputBox(L.boxLink, ui.url)

	label(L.lblFolder, "저장 위치")
	inputBox(L.boxFolder, ui.folder)

	label(L.lblFormat, "형식")
	label(L.lblQuality, "화질")

	if logOpen {
		roundBox(hdc, L.boxLog.Left, L.boxLog.Top, L.boxLog.Right, L.boxLog.Bottom, S(10), clrInput, clrLine)
	}
	f := L.footer
	drawText(hdc, "권한이 있는 영상에만 사용하세요.", f.Left, f.Top, S(400), f.Bottom-f.Top, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, appVersion+"  ·  "+buildDate, f.Right-S(300), f.Top, S(300), f.Bottom-f.Top, clrMuted, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)

	// 창 테두리
	strokeBox(hdc, 0, 0, w, h, windowRadius(), clrLine, 1)
}

// ============================================================
// 오너드로우 컨트롤
// ============================================================

type btnKind int

const (
	kindPrimary btnKind = iota
	kindDanger
	kindNeutral
	kindChip
	kindToggle
	kindLink
	kindTitle
)

var buttonKind = map[uintptr]btnKind{}
var buttonLabel = map[uintptr]string{}

func ownerButton(kind btnKind, label string, r RECT, parent uintptr, id int) uintptr {
	h := createControl("BUTTON", label, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, r, parent, id)
	buttonKind[h] = kind
	buttonLabel[h] = label
	subclassForHover(h)
	return h
}

func subclassForHover(hwnd uintptr) {
	cb := syscall.NewCallback(hoverSubclassProc)
	idx := int32(GWLP_WNDPROC)
	old, _, _ := procSetWindowLongPtrW.Call(hwnd, uintptr(idx), cb)
	origProc[hwnd] = old
}

var cursorHand, cursorArrow uintptr

func hoverSubclassProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_MOUSEMOVE:
		if !hoverState[hwnd] {
			hoverState[hwnd] = true
			invalidate(hwnd)
			tme := TRACKMOUSEEVENT{DwFlags: TME_LEAVE, HwndTrack: hwnd}
			tme.CbSize = uint32(unsafe.Sizeof(tme))
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		}
	case WM_MOUSELEAVE:
		hoverState[hwnd] = false
		invalidate(hwnd)
	case WM_SETCURSOR:
		if isEnabled(hwnd) {
			procSetCursor.Call(cursorHand)
			return 1
		}
	}
	r, _, _ := procCallWindowProcW.Call(origProc[hwnd], hwnd, uintptr(msg), wParam, lParam)
	return r
}

func isSelected(h uintptr) bool {
	if h == ui.fmtVideo {
		return formatSel == 0
	}
	if h == ui.fmtAudio {
		return formatSel == 1
	}
	for i, q := range ui.quality {
		if q == h {
			return qualitySel == i
		}
	}
	return false
}

func drawOwner(dis *DRAWITEMSTRUCT) {
	h := dis.HwndItem
	w, hh := dis.RcItem.Right-dis.RcItem.Left, dis.RcItem.Bottom-dis.RcItem.Top
	pressed := dis.ItemState&ODS_SELECTED != 0
	disabled := dis.ItemState&ODS_DISABLED != 0
	hovered := hoverState[h] && !disabled
	focus := dis.ItemState&ODS_FOCUS != 0 && dis.ItemState&0x0200 == 0 && !disabled // 0x0200 = ODS_NOFOCUSRECT(마우스 클릭 시 테두리 숨김)
	label := buttonLabel[h]
	center := uint32(DT_CENTER | DT_VCENTER | DT_SINGLELINE)

	withBuffer(dis.Hdc, w, hh, func(m uintptr) {
		bg := clrBg
		if h == ui.minBtn || h == ui.closeBtn {
			bg = rgb(24, 24, 24)
		}
		fillRect(m, 0, 0, w, hh, bg)
		rad := S(10)
		switch buttonKind[h] {
		case kindPrimary:
			fill, txt := clrAccent, clrOnAccent
			switch {
			case disabled:
				fill, txt = rgb(40, 60, 56), rgb(110, 140, 132)
			case pressed:
				fill = clrAccentDim
			case hovered:
				fill = clrAccentHi
			}
			roundBox(m, 0, 0, w, hh, rad, fill, fill)
			drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
		case kindDanger:
			fill, stroke, txt := clrBg, clrLine2, clrSub
			if disabled {
				stroke, txt = clrLine, clrMuted
			} else if hovered || pressed {
				stroke, txt = clrDanger, clrDanger
			}
			roundBox(m, 0, 0, w, hh, rad, fill, stroke)
			drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
		case kindNeutral:
			fill, stroke, txt := clrPanel, clrLine2, clrText
			if disabled {
				fill, stroke, txt = clrBg, clrLine, clrMuted
			} else if pressed {
				fill, stroke = clrAccentBg, clrAccent
			} else if hovered {
				fill, stroke = clrHover, rgb(96, 99, 97)
			}
			roundBox(m, 0, 0, w, hh, rad, fill, stroke)
			drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
		case kindChip:
			sel := isSelected(h)
			fill, stroke, txt := clrPanel, clrLine2, clrSub
			if sel {
				fill, stroke, txt = clrAccentBg, clrAccent, clrText
			} else if hovered {
				fill, txt = clrHover, clrText
			}
			if disabled {
				fill, stroke, txt = clrBg, clrLine, clrMuted
				if sel {
					stroke = clrLine2
				}
			}
			roundBox(m, 0, 0, w, hh, S(8), fill, stroke)
			font := ui.font
			if sel {
				font = ui.fontSemi
			}
			drawText(m, label, 0, 0, w, hh, txt, font, center)
		case kindToggle:
			on := toggleState[h]
			sw, sh := S(36), S(20)
			sy := (hh - sh) / 2
			track, knob := clrTrack, rgb(150, 154, 152)
			if on {
				track, knob = clrAccent, clrOnAccent
			}
			if disabled {
				track, knob = clrLine, clrMuted
			}
			roundBox(m, 0, sy, sw, sy+sh, sh, track, track)
			kd := sh - S(6)
			kx := S(3)
			if on {
				kx = sw - kd - S(3)
			}
			roundBox(m, kx, sy+S(3), kx+kd, sy+S(3)+kd, kd, knob, knob)
			txt := clrText
			if disabled {
				txt = clrMuted
			} else if hovered {
				txt = rgb(255, 255, 255)
			}
			drawText(m, label, sw+S(10), 0, w-sw-S(10), hh, txt, ui.font, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		case kindLink:
			txt := clrSub
			if hovered {
				txt = clrText
			}
			roundBox(m, 0, 0, w, hh, rad, clrBg, clrBg)
			if hovered {
				roundBox(m, 0, 0, w, hh, rad, clrHover, clrHover)
			}
			if logOpen {
				label = "기록 닫기"
			}
			drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
		case kindTitle:
			if hovered {
				c := clrHover
				if h == ui.closeBtn {
					c = rgb(229, 72, 77)
				}
				roundBox(m, S(2), S(2), w-S(2), hh-S(2), S(8), c, c)
			}
			cx, cy, a := w/2, hh/2, S(5)
			if h == ui.closeBtn {
				drawLine(m, cx-a, cy-a, cx+a+1, cy+a+1, S(1)+1, clrText)
				drawLine(m, cx-a, cy+a, cx+a+1, cy-a-1, S(1)+1, clrText)
			} else {
				drawLine(m, cx-a, cy, cx+a+1, cy, S(1)+1, clrText)
			}
		}
		if focus && buttonKind[h] != kindTitle && buttonKind[h] != kindToggle {
			strokeBox(m, 0, 0, w, hh, rad, rgb(255, 255, 255), 1)
		}
	})
}

// ============================================================
// 진행 패널 (전용 윈도우 클래스)
// ============================================================

const progressClassName = "WorkkitProgressPanel"

func registerProgressClass(hInstance uintptr) {
	wc := WNDCLASSEX{
		CbSize:        uint32(unsafe.Sizeof(WNDCLASSEX{})),
		LpfnWndProc:   syscall.NewCallback(progressWndProc),
		HInstance:     hInstance,
		HCursor:       cursorArrow,
		LpszClassName: utf16Ptr(progressClassName),
	}
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))
}

func progressWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		var ps PAINTSTRUCT
		hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		w, h := rc.Right, rc.Bottom
		withBuffer(hdc, w, h, func(m uintptr) { paintProgress(m, w, h) })
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func paintProgress(m uintptr, w, h int32) {
	fillRect(m, 0, 0, w, h, clrBg)
	roundBox(m, 0, 0, w, h, S(14), clrPanel, clrLine)
	p := S(20)

	stageColor := clrText
	barColor := clrAccent
	switch pv.tone {
	case 1:
		stageColor = clrAccent
	case 2:
		stageColor, barColor = clrWarn, clrWarn
	case 3:
		stageColor, barColor = clrDanger, clrDanger
	}

	// 1행: 단계 · 개수 / 퍼센트
	top := S(16)
	drawText(m, pv.stage, p, top, w/2, S(28), stageColor, ui.fontSemi, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	if pv.count != "" {
		drawText(m, pv.count, w-p-S(360), top, S(240), S(28), clrMuted, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)
	}
	pctText := "—"
	if pv.pct >= 0 {
		pctText = fmt.Sprintf("%.1f%%", pv.pct)
	} else if running.Load() {
		pctText = "처리 중"
	}
	drawText(m, pctText, w-p-S(200), top-S(2), S(200), S(32), clrText, ui.fontPct, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)

	// 2행: 진행 바
	by, bh := S(54), S(8)
	bw := w - p*2
	roundBox(m, p, by, p+bw, by+bh, bh, clrTrack, clrTrack)
	if pv.pct >= 0 {
		fw := int32(float64(bw) * math.Min(pv.pct, 100) / 100)
		if fw > 0 {
			if fw < bh {
				fw = bh
			}
			roundBox(m, p, by, p+fw, by+bh, bh, barColor, barColor)
		}
	} else if running.Load() {
		// 진행률을 알 수 없는 단계: 움직이는 막대
		seg := bw / 4
		pos := (int32(animTick) * S(6)) % (bw + seg)
		l, r := p+pos-seg, p+pos
		if l < p {
			l = p
		}
		if r > p+bw {
			r = p + bw
		}
		if r > l {
			roundBox(m, l, by, r, by+bh, bh, clrAccentDim, clrAccentDim)
		}
	}

	// 3행: 제목 / 속도·남은 시간
	ty := S(72)
	rw := int32(0)
	if pv.right != "" {
		rw = S(240)
		drawText(m, pv.right, w-p-rw, ty, rw, S(20), clrSub, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)
	}
	drawText(m, pv.detail, p, ty, bw-rw-S(12), S(20), clrSub, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
}

// ============================================================
// 컨트롤 생성
// ============================================================

func darkScroll(h uintptr) {
	procSetWindowTheme.Call(h, uintptr(unsafe.Pointer(utf16Ptr("DarkMode_Explorer"))), 0)
}

func inset(r RECT, x, y int32) RECT { return RECT{r.Left + x, r.Top + y, r.Right - x, r.Bottom - y} }

func createUI(hwnd uintptr) {
	ui.font = makeFont(14, 400, fontFace)
	ui.fontSemi = makeFont(14, 600, fontFaceSemi)
	ui.fontSmall = makeFont(12.5, 400, fontFace)
	ui.fontTitle = makeFont(16, 700, fontFace)
	ui.fontPct = makeFont(24, 700, fontFace)
	ui.fontLog = makeFont(12.5, 400, fontFace)

	// 타이틀 바 버튼
	bs := S(36)
	by := (L.title - bs) / 2
	ui.closeBtn = ownerButton(kindTitle, "", RECT{L.w - S(12) - bs, by, L.w - S(12), by + bs}, hwnd, ID_CLOSEBTN)
	ui.minBtn = ownerButton(kindTitle, "", RECT{L.w - S(12) - bs*2 - S(4), by, L.w - S(12) - bs - S(4), by + bs}, hwnd, ID_MINBTN)

	// 링크 입력
	ui.url = createControl("EDIT", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_LEFT|ES_MULTILINE|ES_AUTOVSCROLL|ES_WANTRETURN,
		inset(L.boxLink, S(12), S(9)), hwnd, ID_URL)
	darkScroll(ui.url)

	// 저장 위치
	defaultFolder := filepath.Join(userHomeDir(), "Downloads", "YouTube")
	fr := L.boxFolder
	ui.folder = createControl("EDIT", defaultFolder, WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_LEFT|ES_AUTOHSCROLL,
		RECT{fr.Left + S(12), fr.Top + (fr.Bottom-fr.Top-S(20))/2, fr.Right - S(12), fr.Top + (fr.Bottom-fr.Top-S(20))/2 + S(20)}, hwnd, ID_FOLDER)
	bx := fr.Right + S(8)
	ui.browse = ownerButton(kindNeutral, "변경", RECT{bx, fr.Top, bx + S(92), fr.Bottom}, hwnd, ID_BROWSE)
	bx += S(92) + S(8)
	ui.open = ownerButton(kindNeutral, "폴더 열기", RECT{bx, fr.Top, bx + S(92), fr.Bottom}, hwnd, ID_OPEN)

	// 형식 / 화질 칩
	row := L.rowFmt
	cx := row.Left
	ui.fmtVideo = ownerButton(kindChip, "영상 MP4", RECT{cx, row.Top, cx + S(96), row.Bottom}, hwnd, ID_FMT_VIDEO)
	cx += S(96) + S(6)
	ui.fmtAudio = ownerButton(kindChip, "음원 MP3", RECT{cx, row.Top, cx + S(96), row.Bottom}, hwnd, ID_FMT_AUDIO)
	cx = L.lblQuality.Left
	cwid := (row.Right - cx - S(6)*6) / 7
	for i, q := range qualityLabels {
		ui.quality[i] = ownerButton(kindChip, q, RECT{cx, row.Top, cx + cwid, row.Bottom}, hwnd, ID_Q0+i)
		cx += cwid + S(6)
	}

	// 옵션 토글
	tr := L.rowToggle
	tx := tr.Left
	for _, t := range []struct {
		h     *uintptr
		label string
		w     int32
		id    int
	}{
		{&ui.playlist, "재생목록 전체", S(150), ID_PLAYLIST},
		{&ui.subtitle, "한글·영어 자막", S(160), ID_SUBTITLE},
		{&ui.ssl, "사내망 SSL 호환 (인증서 오류 시)", S(260), ID_SSL},
	} {
		*t.h = ownerButton(kindToggle, t.label, RECT{tx, tr.Top, tx + t.w, tr.Bottom}, hwnd, t.id)
		toggleState[*t.h] = false
		tx += t.w + S(20)
	}

	// 진행 패널
	pr := L.panel
	ui.progress, _, _ = procCreateWindowExW.Call(0,
		uintptr(unsafe.Pointer(utf16Ptr(progressClassName))), uintptr(unsafe.Pointer(utf16Ptr(""))),
		WS_CHILD|WS_VISIBLE, uintptr(pr.Left), uintptr(pr.Top), uintptr(pr.Right-pr.Left), uintptr(pr.Bottom-pr.Top),
		hwnd, uintptr(ID_PROGRESS), 0, 0)

	// 버튼 행
	br := L.rowBtn
	ui.start = ownerButton(kindPrimary, "다운로드 시작", RECT{br.Left, br.Top, br.Left + S(220), br.Bottom}, hwnd, ID_START)
	ui.cancel = ownerButton(kindDanger, "취소", RECT{br.Left + S(230), br.Top, br.Left + S(330), br.Bottom}, hwnd, ID_CANCEL)
	ui.logToggle = ownerButton(kindLink, "작업 기록 보기", RECT{br.Right - S(118), br.Top, br.Right, br.Bottom}, hwnd, ID_LOGTOGGLE)
	ui.update = ownerButton(kindNeutral, "도구 업데이트", RECT{br.Right - S(118) - S(8) - S(130), br.Top, br.Right - S(118) - S(8), br.Bottom}, hwnd, ID_UPDATE)
	enable(ui.cancel, false)

	// 작업 기록 (기본 접힘)
	ui.log = createControl("EDIT", "", WS_CHILD|ES_LEFT|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY, RECT{0, 0, 10, 10}, hwnd, ID_LOG)
	send(ui.log, WM_SETFONT, ui.fontLog, 1)
	darkScroll(ui.log)
}

func windowRadius() int32 {
	if isWin11 {
		return 0
	}
	return S(14)
}

var isWin11 bool

func applyWindowShape(hwnd uintptr) {
	if isWin11 {
		pref := int32(2) // DWMWCP_ROUND
		procDwmSetWindowAttribute.Call(hwnd, 33, uintptr(unsafe.Pointer(&pref)), unsafe.Sizeof(pref))
		return
	}
	rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(L.w+1), uintptr(L.h+1), uintptr(S(14)), uintptr(S(14)))
	procSetWindowRgn.Call(hwnd, rgn, 1)
}

func setLogOpen(open bool) {
	logOpen = open
	computeLayout()
	if open {
		r := inset(L.boxLog, S(12), S(8))
		procMoveWindow.Call(ui.log, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right-r.Left), uintptr(r.Bottom-r.Top), 1)
		procShowWindow.Call(ui.log, SW_SHOW)
	} else {
		procShowWindow.Call(ui.log, SW_HIDE)
	}
	// 펼쳤을 때 화면 아래로 넘치면 창을 위로 올린다
	var wr, wa RECT
	procGetWindowRect.Call(ui.main, uintptr(unsafe.Pointer(&wr)))
	procSystemParametersInfoW.Call(SPI_GETWORKAREA, 0, uintptr(unsafe.Pointer(&wa)), 0)
	y := wr.Top
	if y+L.h > wa.Bottom {
		y = wa.Bottom - L.h
	}
	if y < wa.Top {
		y = wa.Top
	}
	procSetWindowPos.Call(ui.main, 0, uintptr(wr.Left), uintptr(y), uintptr(L.w), uintptr(L.h), SWP_NOZORDER)
	applyWindowShape(ui.main)
	procInvalidateRect.Call(ui.main, 0, 1)
	invalidate(ui.logToggle)
}

// ============================================================
// 메인 창 프로시저
// ============================================================

func wndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		ui.main = hwnd
		createUI(hwnd)
		procSetTimer.Call(hwnd, 1, 50, 0)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		var ps PAINTSTRUCT
		hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		withBuffer(hdc, rc.Right, rc.Bottom, func(m uintptr) { paintMain(m, rc.Right, rc.Bottom) })
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case WM_NCHITTEST:
		pt := POINT{int32(int16(loword(lParam))), int32(int16(hiword(lParam)))}
		procScreenToClient.Call(hwnd, uintptr(unsafe.Pointer(&pt)))
		if pt.Y >= 0 && pt.Y < L.title && pt.X < L.w-S(100) {
			return HTCAPTION
		}
	case WM_DRAWITEM:
		drawOwner((*DRAWITEMSTRUCT)(unsafe.Pointer(lParam)))
		return 1
	case WM_COMMAND:
		id := int(loword(wParam))
		code := int(hiword(wParam))
		if (id == ID_URL || id == ID_FOLDER) && (code == EN_SETFOCUS || code == EN_KILLFOCUS) {
			if code == EN_SETFOCUS {
				focusedEdit = lParam
			} else if focusedEdit == lParam {
				focusedEdit = 0
			}
			invalidate(hwnd)
			return 0
		}
		if code != BN_CLICKED {
			return 0
		}
		switch {
		case id == ID_BROWSE:
			chooseFolder()
		case id == ID_OPEN:
			openFolder()
		case id == ID_START:
			startDownload()
		case id == ID_CANCEL:
			cancelDownload()
		case id == ID_UPDATE:
			updateTools()
		case id == ID_LOGTOGGLE:
			setLogOpen(!logOpen)
		case id == ID_FMT_VIDEO || id == ID_FMT_AUDIO:
			formatSel = id - ID_FMT_VIDEO
			invalidate(ui.fmtVideo)
			invalidate(ui.fmtAudio)
			for _, q := range ui.quality {
				enable(q, formatSel == 0)
			}
		case id >= ID_Q0 && id < ID_Q0+7:
			qualitySel = id - ID_Q0
			for _, q := range ui.quality {
				invalidate(q)
			}
		case id == ID_PLAYLIST || id == ID_SUBTITLE || id == ID_SSL:
			t := lParam
			toggleState[t] = !toggleState[t]
			invalidate(t)
		case id == ID_MINBTN:
			procShowWindow.Call(hwnd, SW_MINIMIZE)
		case id == ID_CLOSEBTN:
			procSendMessageW.Call(hwnd, WM_CLOSE, 0, 0)
		}
		return 0
	case WM_TIMER:
		drainUpdates()
		if running.Load() && pv.pct < 0 {
			animTick++
			invalidate(ui.progress)
		}
		return 0
	case WM_CTLCOLOREDIT, WM_CTLCOLORSTATIC:
		txt := clrText
		if lParam == ui.log {
			txt = clrSub
		} else if !isEnabled(lParam) {
			txt = clrMuted
		}
		procSetBkColor.Call(wParam, clrInput)
		procSetTextColor.Call(wParam, txt)
		return brushInput
	case WM_CLOSE:
		if running.Load() {
			if messageBox(hwnd, "다운로드가 진행 중입니다. 취소하고 종료할까요?", appTitle, MB_YESNO|MB_ICONWARNING) != IDYES {
				return 0
			}
			cancelDownload()
		}
		procDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		for _, f := range []uintptr{ui.font, ui.fontSemi, ui.fontSmall, ui.fontTitle, ui.fontPct, ui.fontLog} {
			deleteObj(f)
		}
		deleteObj(brushInput)
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

// ============================================================
// 사용자 동작
// ============================================================

func chooseFolder() {
	display := make([]uint16, 260)
	bi := BROWSEINFO{
		HwndOwner:      ui.main,
		PszDisplayName: &display[0],
		LpszTitle:      utf16Ptr("저장할 폴더를 선택하세요."),
		UlFlags:        BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE,
	}
	pidl, _, _ := procSHBrowseForFolderW.Call(uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return
	}
	defer procCoTaskMemFree.Call(pidl)
	pathBuf := make([]uint16, 32768)
	ok, _, _ := procSHGetPathFromIDListW.Call(pidl, uintptr(unsafe.Pointer(&pathBuf[0])))
	if ok != 0 {
		setText(ui.folder, syscall.UTF16ToString(pathBuf))
	}
}

func openFolder() {
	folder := strings.TrimSpace(getText(ui.folder))
	if folder == "" {
		return
	}
	os.MkdirAll(folder, 0755)
	procShellExecuteW.Call(ui.main, uintptr(unsafe.Pointer(utf16Ptr("open"))), uintptr(unsafe.Pointer(utf16Ptr(folder))), 0, 0, SW_SHOWNORMAL)
}

func cancelDownload() {
	cancelMu.Lock()
	cancel := cancelCurrent
	cancelMu.Unlock()
	if cancel != nil {
		cancel()
	}
}

func beginJob() context.Context {
	ctx, cancel := context.WithCancel(context.Background())
	cancelMu.Lock()
	cancelCurrent = cancel
	cancelMu.Unlock()
	return ctx
}

func endJob() {
	cancelMu.Lock()
	cancelCurrent = nil
	cancelMu.Unlock()
}

func updateTools() {
	if running.Load() {
		return
	}
	setRunningState(true)
	pv.count = ""
	setProgress("도구 업데이트", 0, "최신 구성요소를 확인하는 중", "", 0)
	setText(ui.log, "")
	userLog("[도구] 최신 구성요소 확인 시작")
	insecure := toggleState[ui.ssl]
	ctx := beginJob()
	go func() {
		defer endJob()
		if err := ensureTools(ctx, true, insecure); err != nil {
			if ctx.Err() != nil {
				updates <- uiUpdate{kind: "cancelled"}
				return
			}
			updates <- uiUpdate{kind: "done", text: "도구 업데이트 실패: " + err.Error()}
			return
		}
		updates <- uiUpdate{kind: "done", text: "다운로드 도구를 최신 버전으로 업데이트했습니다.", ok: true}
	}()
}

func startDownload() {
	if running.Load() {
		return
	}
	urls, err := parseYouTubeURLs(strings.TrimSpace(getText(ui.url)))
	if err != nil {
		messageBox(ui.main, err.Error(), appTitle, MB_OK|MB_ICONERROR)
		return
	}
	folder := strings.TrimSpace(getText(ui.folder))
	if folder == "" {
		messageBox(ui.main, "저장 위치를 선택하세요.", appTitle, MB_OK|MB_ICONERROR)
		return
	}
	if err := os.MkdirAll(folder, 0755); err != nil {
		messageBox(ui.main, "저장 폴더를 만들 수 없습니다: "+err.Error(), appTitle, MB_OK|MB_ICONERROR)
		return
	}

	formatIdx, qualityIdx := formatSel, qualitySel
	playlist, subtitle, insecure := toggleState[ui.playlist], toggleState[ui.subtitle], toggleState[ui.ssl]

	setRunningState(true)
	pv.count = ""
	setProgress("준비 중", -1, "필요한 구성요소를 확인하는 중", "", 0)
	setText(ui.log, "")
	userLog(fmt.Sprintf("[시작] 링크 %d개", len(urls)))
	if insecure {
		userLog("[안내] 사내망 SSL 호환 모드 (인증서 검증 생략)")
	}
	ctx := beginJob()
	go func() {
		defer endJob()
		if err := ensureTools(ctx, false, insecure); err != nil {
			if ctx.Err() != nil {
				updates <- uiUpdate{kind: "cancelled"}
				return
			}
			updates <- uiUpdate{kind: "done", text: "구성요소 준비 실패: " + err.Error()}
			return
		}
		success, failed, err := executeDownload(ctx, urls, folder, formatIdx, qualityIdx, playlist, subtitle, insecure)
		if ctx.Err() != nil {
			updates <- uiUpdate{kind: "cancelled"}
			return
		}
		if err != nil && success == 0 {
			updates <- uiUpdate{kind: "done", text: "다운로드 실패: " + friendlyError(err.Error())}
			return
		}
		if failed > 0 {
			updates <- uiUpdate{kind: "donewarn", text: fmt.Sprintf("%d개 완료, %d개 실패했습니다. 작업 기록을 확인하세요.", success, failed)}
			return
		}
		updates <- uiUpdate{kind: "done", text: fmt.Sprintf("다운로드를 완료했습니다. (%d개)", success), ok: true}
	}()
}

func parseYouTubeURLs(raw string) ([]string, error) {
	if raw == "" {
		return nil, fmt.Errorf("YouTube 링크를 입력하세요.")
	}
	fields := strings.FieldsFunc(raw, func(r rune) bool { return r == '\n' || r == '\r' || r == '\t' || r == ' ' })
	var out []string
	seen := map[string]bool{}
	for _, s := range fields {
		s = strings.TrimSpace(s)
		u, err := url.Parse(s)
		if s == "" || err != nil || u.Scheme == "" || u.Host == "" {
			continue
		}
		host := strings.ToLower(strings.TrimPrefix(u.Hostname(), "www."))
		if host != "youtube.com" && host != "m.youtube.com" && host != "music.youtube.com" && host != "youtu.be" {
			continue
		}
		if !seen[s] {
			seen[s] = true
			out = append(out, s)
		}
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("올바른 YouTube 링크가 없습니다.")
	}
	return out, nil
}

func qualityHeight(idx int) int {
	return []int{0, 2160, 1440, 1080, 720, 480, 360}[idx]
}

// ============================================================
// 다운로드 실행
// ============================================================

func executeDownload(ctx context.Context, urls []string, folder string, formatIdx, qualityIdx int, playlist, subtitle, insecure bool) (int, int, error) {
	bin := toolDir()
	ytdlp := filepath.Join(bin, "yt-dlp.exe")
	ffmpeg := filepath.Join(bin, "ffmpeg.exe")
	ffprobe := filepath.Join(bin, "ffprobe.exe")
	deno := filepath.Join(bin, "deno.exe")
	success, failed := 0, 0
	var lastErr error

	for i, target := range urls {
		if ctx.Err() != nil {
			return success, failed, ctx.Err()
		}
		index, total := i+1, len(urls)
		pathLog, err := os.CreateTemp("", "workkit-ytdlp-paths-*.txt")
		if err != nil {
			failed++
			lastErr = fmt.Errorf("저장 경로 기록 파일 생성 실패: %w", err)
			logLine(fmt.Sprintf("[%d/%d] 실패: %s", index, total, lastErr.Error()))
			continue
		}
		pathLogPath := pathLog.Name()
		pathLog.Close()
		args := []string{
			"--no-color", "--newline", "--progress", "--progress-delta", "0.2", "--encoding", "utf-8",
			"--windows-filenames", "--continue", "--no-overwrites",
			"--paths", folder, "--ffmpeg-location", ffmpeg, "--js-runtimes", "deno:" + deno,
			"--progress-template", progressTemplate,
			"--print", itemTemplate,
			"--print-to-file", "after_move:%(filepath)s", pathLogPath,
			"-o", "%(title).180B [%(id)s].%(ext)s",
		}
		if insecure {
			args = append(args, "--no-check-certificates")
		}
		if playlist {
			args = append(args, "--yes-playlist")
		} else {
			args = append(args, "--no-playlist")
		}
		if subtitle {
			args = append(args, "--write-subs", "--write-auto-subs", "--sub-langs", "ko.*,en.*", "--convert-subs", "srt")
		}
		if formatIdx == 1 {
			args = append(args, "--extract-audio", "--audio-format", "mp3", "--audio-quality", "0", "--embed-thumbnail", "--add-metadata")
		} else {
			if h := qualityHeight(qualityIdx); h > 0 {
				args = append(args, "-f", fmt.Sprintf("bv*[height<=%d][ext=mp4]+ba[ext=m4a]/bv*[height<=%d]+ba/b[height<=%d]", h, h, h))
			} else {
				args = append(args, "-f", "bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b")
			}
			args = append(args, "--merge-output-format", "mp4", "--add-metadata")
		}
		args = append(args, target)

		count := ""
		if total > 1 {
			count = fmt.Sprintf("%d / %d", index, total)
		}
		sendProgress(uiUpdate{stage: "영상 정보 확인", pct: -1, count: count, detail: target})
		logLine(fmt.Sprintf("[%d/%d] 영상 정보 확인", index, total))

		finalPaths, err := runOneDownload(ctx, ytdlp, args, pathLogPath, index, total)
		os.Remove(pathLogPath)
		if err != nil {
			if ctx.Err() != nil {
				return success, failed, ctx.Err()
			}
			failed++
			lastErr = err
			logLine(fmt.Sprintf("[%d/%d] 실패: %s", index, total, friendlyError(err.Error())))
			continue
		}
		for _, p := range finalPaths {
			logLine(fmt.Sprintf("[%d/%d] 저장: %s", index, total, filepath.Base(p)))
		}
		if formatIdx == 0 {
			if len(finalPaths) == 0 {
				err = fmt.Errorf("다운로드한 파일의 저장 경로를 확인하지 못했습니다")
			}
			for fi, p := range finalPaths {
				if err = ensureEditingCompatible(ctx, ffmpeg, ffprobe, p, index, total, fi+1, len(finalPaths)); err != nil {
					break
				}
			}
			if err != nil {
				if ctx.Err() != nil {
					return success, failed, ctx.Err()
				}
				failed++
				lastErr = err
				logLine(fmt.Sprintf("[%d/%d] 편집 호환 변환 실패: %s", index, total, friendlyError(err.Error())))
				continue
			}
		}
		success++
		logLine(fmt.Sprintf("[%d/%d] 완료", index, total))
	}
	return success, failed, lastErr
}

func runOneDownload(ctx context.Context, ytdlp string, args []string, pathLogPath string, index, total int) ([]string, error) {
	cmd := exec.CommandContext(ctx, ytdlp, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	cmd.Env = append(os.Environ(), "PYTHONUTF8=1", "PYTHONIOENCODING=utf-8")
	pr, pw := io.Pipe()
	cmd.Stdout = pw
	cmd.Stderr = pw
	if err := cmd.Start(); err != nil {
		return nil, err
	}

	scanDone := make(chan struct{})
	var lastError string
	go func() {
		defer close(scanDone)
		scanner := bufio.NewScanner(pr)
		scanner.Buffer(make([]byte, 4096), 1024*1024)
		var cur itemInfo
		var tracker *byteTracker
		lastBucket := -1
		countText := func() string {
			switch {
			case cur.Count > 1 && total > 1:
				return fmt.Sprintf("%d / %d · 재생목록 %d / %d", index, total, cur.Index, cur.Count)
			case cur.Count > 1:
				return fmt.Sprintf("재생목록 %d / %d", cur.Index, cur.Count)
			case total > 1:
				return fmt.Sprintf("%d / %d", index, total)
			}
			return ""
		}
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())
			if line == "" {
				continue
			}
			if it, ok := parseItemLine(line); ok {
				cur = it
				tracker = newByteTracker(it.Parts)
				lastBucket = -1
				logLine(fmt.Sprintf("[%d/%d] 제목: %s", index, total, it.Title))
				sendProgress(uiUpdate{stage: "다운로드 중", pct: 0, count: countText(), detail: it.Title})
				continue
			}
			if p, ok := parseProgressLine(line); ok {
				if isSideFile(p.Filename) {
					continue // 자막·썸네일은 진행률 계산에서 제외
				}
				if tracker == nil {
					tracker = newByteTracker(nil)
				}
				frac := tracker.update(p)
				sendProgress(uiUpdate{stage: "다운로드 중", pct: frac * 100, count: countText(), right: speedText(p)})
				if b := int(frac * 4); b > lastBucket && b < 4 && b > 0 {
					lastBucket = b
					logLine(fmt.Sprintf("[%d/%d] 다운로드 %d%%", index, total, b*25))
				}
				continue
			}
			if st := postStage(line); st != "" {
				sendProgress(uiUpdate{stage: st, pct: -1, count: countText()})
				continue
			}
			lower := strings.ToLower(line)
			if strings.Contains(lower, "has already been downloaded") {
				sendProgress(uiUpdate{stage: "이미 받은 파일", pct: 100, count: countText()})
			}
			if strings.Contains(lower, "certificate_verify_failed") || strings.Contains(lower, "self signed certificate") ||
				strings.Contains(lower, "error:") || strings.Contains(lower, "private video") ||
				strings.Contains(lower, "video unavailable") || strings.Contains(lower, "sign in") {
				lastError = line
			}
		}
	}()
	waitErr := cmd.Wait()
	pw.Close()
	<-scanDone
	pr.Close()
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}
	if waitErr != nil {
		if lastError != "" {
			return nil, fmt.Errorf("%s", lastError)
		}
		return nil, waitErr
	}
	return readDownloadedPaths(pathLogPath)
}

func readDownloadedPaths(pathLogPath string) ([]string, error) {
	data, err := os.ReadFile(pathLogPath)
	if err != nil {
		return nil, fmt.Errorf("다운로드 경로 기록 읽기 실패: %w", err)
	}
	seen := map[string]bool{}
	var paths []string
	for _, line := range nonEmptyLines(strings.TrimPrefix(string(data), "\uFEFF")) {
		p := filepath.Clean(strings.TrimSpace(line))
		key := strings.ToLower(p)
		if seen[key] {
			continue
		}
		if !fileExists(p) {
			return nil, fmt.Errorf("다운로드 파일을 찾지 못했습니다: %s", p)
		}
		seen[key] = true
		paths = append(paths, p)
	}
	if len(paths) == 0 {
		return nil, fmt.Errorf("yt-dlp가 저장 경로를 기록하지 않았습니다")
	}
	return paths, nil
}

// ensureEditingCompatible: 이미 H.264/AAC MP4면 그대로 두고, AV1·VP9·Opus·10비트 영상만
// 편집 프로그램 호환 H.264(8bit yuv420p) + AAC MP4로 변환한다.
func ensureEditingCompatible(ctx context.Context, ffmpeg, ffprobe, path string, index, total, fileIndex, fileTotal int) error {
	count := ""
	if fileTotal > 1 {
		count = fmt.Sprintf("파일 %d / %d", fileIndex, fileTotal)
	} else if total > 1 {
		count = fmt.Sprintf("%d / %d", index, total)
	}
	sendProgress(uiUpdate{stage: "코덱 확인", pct: -1, count: count})
	videoCodec, pixelFormat, err := probeVideo(ctx, ffprobe, path)
	if err != nil {
		return fmt.Errorf("영상 코덱 확인 실패: %w", err)
	}
	audioCodec, hasAudio, err := probeAudio(ctx, ffprobe, path)
	if err != nil {
		return fmt.Errorf("음성 코덱 확인 실패: %w", err)
	}
	videoOK := strings.EqualFold(videoCodec, "h264") && (strings.EqualFold(pixelFormat, "yuv420p") || strings.EqualFold(pixelFormat, "yuvj420p"))
	audioOK := !hasAudio || strings.EqualFold(audioCodec, "aac")
	if videoOK && audioOK {
		logLine(fmt.Sprintf("[%d/%d] 편집 호환 확인: H.264/AAC", index, total))
		sendProgress(uiUpdate{stage: "편집 호환 확인 완료", pct: 100, count: count})
		return nil
	}

	logLine(fmt.Sprintf("[%d/%d] 코덱 변환: %s/%s → H.264/AAC", index, total, videoCodec, audioCodec))
	sendProgress(uiUpdate{stage: "편집용 변환 중", pct: 0, count: count, right: "H.264 / AAC"})

	tempPath := path + ".workkit-compatible.tmp.mp4"
	backupPath := path + ".workkit-original.bak"
	os.Remove(tempPath)
	os.Remove(backupPath)

	args := []string{"-progress", "pipe:1", "-nostats", "-y", "-hide_banner", "-i", path, "-map", "0:v:0", "-map", "0:a?", "-map_metadata", "0", "-map_chapters", "0"}
	if videoOK {
		args = append(args, "-c:v", "copy")
	} else {
		args = append(args, "-c:v", "libx264", "-preset", "fast", "-crf", "20", "-pix_fmt", "yuv420p")
	}
	if hasAudio {
		if audioOK {
			args = append(args, "-c:a", "copy")
		} else {
			args = append(args, "-c:a", "aac", "-b:a", "192k")
		}
	}
	args = append(args, "-movflags", "+faststart", tempPath)

	duration, _ := probeDuration(ctx, ffprobe, path)
	start := time.Now()
	if runErr := runFFmpegWithProgress(ctx, ffmpeg, args, duration, func(fraction float64) {
		right := "H.264 / AAC"
		if el := time.Since(start).Seconds(); fraction > 0.02 && fraction < 1 && el > 2 {
			right += " · 남은 시간 " + humanETA(el/fraction-el)
		}
		pct := fraction * 100
		if duration <= 0 {
			pct = -1
		}
		sendProgress(uiUpdate{stage: "편집용 변환 중", pct: pct, count: count, right: right})
	}); runErr != nil {
		os.Remove(tempPath)
		return runErr
	}
	if ctx.Err() != nil {
		os.Remove(tempPath)
		return ctx.Err()
	}
	if err := replaceDownloadedFile(path, tempPath, backupPath); err != nil {
		os.Remove(tempPath)
		return err
	}
	logLine(fmt.Sprintf("[%d/%d] 편집 호환 변환 완료", index, total))
	return nil
}

func ffCmd(ctx context.Context, bin string, args ...string) *exec.Cmd {
	cmd := exec.CommandContext(ctx, bin, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	return cmd
}

func probeVideo(ctx context.Context, ffprobe, path string) (string, string, error) {
	out, err := ffCmd(ctx, ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_name,pix_fmt", "-of", "default=noprint_wrappers=1:nokey=1", path).CombinedOutput()
	if err != nil {
		return "", "", detailedCommandError("FFprobe", err, out)
	}
	lines := nonEmptyLines(string(out))
	if len(lines) < 2 {
		return "", "", fmt.Errorf("영상 스트림 정보가 없습니다")
	}
	return lines[0], lines[1], nil
}

func probeAudio(ctx context.Context, ffprobe, path string) (string, bool, error) {
	out, err := ffCmd(ctx, ffprobe, "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_name", "-of", "default=noprint_wrappers=1:nokey=1", path).CombinedOutput()
	if err != nil {
		return "", false, detailedCommandError("FFprobe", err, out)
	}
	lines := nonEmptyLines(string(out))
	if len(lines) == 0 {
		return "", false, nil
	}
	return lines[0], true, nil
}

func probeDuration(ctx context.Context, ffprobe, path string) (float64, error) {
	out, err := ffCmd(ctx, ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", path).CombinedOutput()
	if err != nil {
		return 0, detailedCommandError("FFprobe", err, out)
	}
	d, err := strconv.ParseFloat(strings.TrimSpace(string(out)), 64)
	if err != nil || d <= 0 {
		return 0, fmt.Errorf("영상 길이 확인 실패")
	}
	return d, nil
}

func runFFmpegWithProgress(ctx context.Context, ffmpeg string, args []string, duration float64, onProgress func(float64)) error {
	cmd := ffCmd(ctx, ffmpeg, args...)
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return fmt.Errorf("FFmpeg 진행률 연결 실패: %w", err)
	}
	var stderr strings.Builder
	cmd.Stderr = &stderr
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("FFmpeg 실행 실패: %w", err)
	}
	scanner := bufio.NewScanner(stdout)
	scanner.Buffer(make([]byte, 4096), 1024*1024)
	last := time.Time{}
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if strings.HasPrefix(line, "out_time_us=") && duration > 0 && time.Since(last) > 150*time.Millisecond {
			if us, e := strconv.ParseInt(strings.TrimPrefix(line, "out_time_us="), 10, 64); e == nil && us >= 0 {
				onProgress(math.Min(float64(us)/(duration*1e6), 1))
				last = time.Now()
			}
		}
	}
	waitErr := cmd.Wait()
	if ctx.Err() != nil {
		return ctx.Err()
	}
	if waitErr != nil {
		return detailedCommandError("FFmpeg 변환", waitErr, []byte(stderr.String()))
	}
	onProgress(1)
	return nil
}

func detailedCommandError(label string, err error, output []byte) error {
	msg := strings.TrimSpace(string(output))
	if len(msg) > 1200 {
		msg = msg[len(msg)-1200:]
	}
	if msg == "" {
		return fmt.Errorf("%s 실패: %w", label, err)
	}
	return fmt.Errorf("%s 실패: %w (%s)", label, err, msg)
}

func nonEmptyLines(value string) []string {
	var lines []string
	for _, line := range strings.FieldsFunc(value, func(r rune) bool { return r == '\r' || r == '\n' }) {
		if line = strings.TrimSpace(line); line != "" {
			lines = append(lines, line)
		}
	}
	return lines
}

func replaceDownloadedFile(original, converted, backup string) error {
	if err := os.Rename(original, backup); err != nil {
		return fmt.Errorf("원본 파일 임시 보관 실패: %w", err)
	}
	if err := os.Rename(converted, original); err != nil {
		_ = os.Rename(backup, original)
		return fmt.Errorf("변환 파일 교체 실패: %w", err)
	}
	if err := os.Remove(backup); err != nil {
		return fmt.Errorf("임시 원본 정리 실패: %w", err)
	}
	return nil
}

// ============================================================
// 구성요소(yt-dlp / FFmpeg / Deno) 준비
// ============================================================

func toolDir() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base = os.TempDir()
	}
	dir := filepath.Join(base, "WORKKIT", "YouTubeDownloader", "bin")
	// 이전 버전이 받아둔 도구가 있으면 그대로 옮겨 재사용
	if old := filepath.Join(base, "HJWYouTubeDownloader", "bin"); !fileExists(filepath.Join(dir, "yt-dlp.exe")) && fileExists(filepath.Join(old, "yt-dlp.exe")) {
		os.MkdirAll(filepath.Dir(dir), 0755)
		if os.Rename(old, dir) == nil {
			os.Remove(filepath.Dir(old))
		}
	}
	return dir
}

func ensureTools(ctx context.Context, force, insecure bool) error {
	dir := toolDir()
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	ytdlp := filepath.Join(dir, "yt-dlp.exe")
	ffmpeg := filepath.Join(dir, "ffmpeg.exe")
	ffprobe := filepath.Join(dir, "ffprobe.exe")
	deno := filepath.Join(dir, "deno.exe")

	if force || !fileExists(ytdlp) {
		logLine("[도구] yt-dlp 받는 중")
		if err := downloadFile(ctx, "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe", ytdlp, "yt-dlp", insecure); err != nil {
			return err
		}
	}
	if force || !fileExists(ffmpeg) || !fileExists(ffprobe) {
		logLine("[도구] FFmpeg 받는 중")
		zipPath := filepath.Join(dir, "ffmpeg.zip")
		os.Remove(zipPath)
		if err := downloadFile(ctx, "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip", zipPath, "FFmpeg", insecure); err != nil {
			return err
		}
		sendProgress(uiUpdate{stage: "FFmpeg 압축 해제", pct: -1, count: "-"})
		if err := extractNamedExecutables(zipPath, dir, map[string]string{"ffmpeg.exe": "ffmpeg.exe", "ffprobe.exe": "ffprobe.exe"}); err != nil {
			return err
		}
		os.Remove(zipPath)
	}
	if force || !fileExists(deno) {
		logLine("[도구] Deno 받는 중")
		zipPath := filepath.Join(dir, "deno.zip")
		os.Remove(zipPath)
		if err := downloadFile(ctx, "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip", zipPath, "Deno", insecure); err != nil {
			return err
		}
		if err := extractNamedExecutables(zipPath, dir, map[string]string{"deno.exe": "deno.exe"}); err != nil {
			return err
		}
		os.Remove(zipPath)
	}
	logLine("[도구] 구성요소 준비 완료")
	return nil
}

func downloadFile(ctx context.Context, src, dst, label string, insecure bool) error {
	tmp := dst + ".part"
	os.Remove(tmp)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, src, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "WORKKIT-YouTube-Downloader/3.4")
	transport := http.DefaultTransport.(*http.Transport).Clone()
	if insecure {
		transport.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	}
	resp, err := (&http.Client{Transport: transport}).Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("%s 다운로드 HTTP 오류: %s", label, resp.Status)
	}
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	defer f.Close()

	totalBytes := float64(resp.ContentLength)
	stage := label + " 받는 중"
	buf := make([]byte, 256*1024)
	var written float64
	last, start := time.Time{}, time.Now()
	report := func() {
		pct := -1.0
		if totalBytes > 0 {
			pct = written / totalBytes * 100
		}
		right := humanBytes(written)
		if totalBytes > 0 {
			right += " / " + humanBytes(totalBytes)
		}
		if el := time.Since(start).Seconds(); el > 0.5 {
			right += " · " + humanBytes(written/el) + "/s"
		}
		sendProgress(uiUpdate{stage: stage, pct: pct, count: "-", detail: "처음 한 번만 필요한 구성요소입니다.", right: right})
	}
	report()
	for {
		n, readErr := resp.Body.Read(buf)
		if n > 0 {
			if _, err := f.Write(buf[:n]); err != nil {
				return err
			}
			written += float64(n)
			if time.Since(last) > 120*time.Millisecond {
				report()
				last = time.Now()
			}
		}
		if readErr == io.EOF {
			break
		}
		if readErr != nil {
			return readErr
		}
	}
	report()
	if err := f.Close(); err != nil {
		return err
	}
	os.Remove(dst)
	if err := os.Rename(tmp, dst); err != nil {
		return err
	}
	logLine("[도구] " + label + " 완료")
	return nil
}

func extractNamedExecutables(zipPath, dstDir string, wanted map[string]string) error {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return fmt.Errorf("압축 파일 열기 실패: %w", err)
	}
	defer zr.Close()
	found := map[string]bool{}
	for _, zf := range zr.File {
		base := strings.ToLower(filepath.Base(zf.Name))
		outName, ok := wanted[base]
		if !ok {
			continue
		}
		rc, err := zf.Open()
		if err != nil {
			return err
		}
		outPath := filepath.Join(dstDir, outName)
		tmp := outPath + ".part"
		out, err := os.Create(tmp)
		if err != nil {
			rc.Close()
			return err
		}
		_, copyErr := io.Copy(out, rc)
		closeErr := out.Close()
		rc.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
		os.Remove(outPath)
		if err := os.Rename(tmp, outPath); err != nil {
			return err
		}
		found[base] = true
	}
	for name := range wanted {
		if !found[strings.ToLower(name)] {
			return fmt.Errorf("압축 파일에서 %s을(를) 찾지 못했습니다.", name)
		}
	}
	return nil
}

func fileExists(path string) bool {
	st, err := os.Stat(path)
	return err == nil && !st.IsDir() && st.Size() > 0
}

func friendlyError(s string) string {
	lower := strings.ToLower(s)
	switch {
	case strings.Contains(lower, "certificate_verify_failed") || strings.Contains(lower, "self signed certificate"):
		return "사내 보안장비가 HTTPS 인증서를 바꿔 전달하고 있습니다. 회사 정책상 허용되는 경우 '사내망 SSL 호환'을 켜고 다시 시도하세요."
	case strings.Contains(lower, "sign in") || strings.Contains(lower, "cookies"):
		return "로그인이 필요하거나 접근이 제한된 영상입니다."
	case strings.Contains(lower, "403") || strings.Contains(lower, "forbidden"):
		return "YouTube가 요청을 막았습니다(403). '도구 업데이트'를 누른 뒤 다시 시도하세요."
	case strings.Contains(lower, "private video"):
		return "비공개 영상은 받을 수 없습니다."
	case strings.Contains(lower, "video unavailable"):
		return "영상을 사용할 수 없습니다. 링크와 공개 상태를 확인하세요."
	case strings.Contains(lower, "network") || strings.Contains(lower, "connection"):
		return "네트워크 연결에 실패했습니다. 인터넷 연결을 확인하세요."
	}
	return s
}

func userHomeDir() string {
	if h, err := os.UserHomeDir(); err == nil && h != "" {
		return h
	}
	return os.Getenv("USERPROFILE")
}

// ============================================================
// 진입점
// ============================================================

func main() {
	runtime.LockOSThread()
	procSetProcessDPIAware.Call()
	initDPI()
	procCoInitializeEx.Call(0, COINIT_APARTMENTTHREADED)
	defer procCoUninitialize.Call()

	icc := INITCOMMONCONTROLSEX{DwSize: uint32(unsafe.Sizeof(INITCOMMONCONTROLSEX{})), DwICC: 0x000040FF}
	procInitCommonControlsEx.Call(uintptr(unsafe.Pointer(&icc)))

	var vi OSVERSIONINFOW
	vi.Size = uint32(unsafe.Sizeof(vi))
	procRtlGetVersion.Call(uintptr(unsafe.Pointer(&vi)))
	isWin11 = vi.Major >= 10 && vi.Build >= 22000

	loadEmbeddedFonts()
	brushInput = createBrush(clrInput)
	hInstance, _, _ := procGetModuleHandleW.Call(0)
	cursorArrow, _, _ = procLoadCursorW.Call(0, IDC_ARROW)
	cursorHand, _, _ = procLoadCursorW.Call(0, IDC_HAND)
	icon, _, _ := procLoadIconW.Call(hInstance, 1)
	className := utf16Ptr("WorkkitYouTubeDownloader")
	wc := WNDCLASSEX{
		CbSize:        uint32(unsafe.Sizeof(WNDCLASSEX{})),
		LpfnWndProc:   syscall.NewCallback(wndProc),
		HInstance:     hInstance,
		HIcon:         icon,
		HIconSm:       icon,
		HCursor:       cursorArrow,
		LpszClassName: className,
	}
	if atom, _, err := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); atom == 0 {
		messageBox(0, "프로그램 창을 초기화하지 못했습니다: "+err.Error(), appTitle, MB_OK|MB_ICONERROR)
		return
	}
	registerProgressClass(hInstance)
	computeLayout()

	hwnd, _, err := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(utf16Ptr(appTitle))),
		WS_POPUP|WS_CLIPCHILDREN|WS_SYSMENU|WS_MINIMIZEBOX, 0, 0, uintptr(L.w), uintptr(L.h), 0, 0, hInstance, 0)
	if hwnd == 0 {
		messageBox(0, "프로그램 창을 만들지 못했습니다: "+err.Error(), appTitle, MB_OK|MB_ICONERROR)
		return
	}
	applyWindowShape(hwnd)
	dark := int32(1)
	procDwmSetWindowAttribute.Call(hwnd, 20 /*DWMWA_USE_IMMERSIVE_DARK_MODE*/, uintptr(unsafe.Pointer(&dark)), 4)
	centerWindow(hwnd)
	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)
	procSetFocus.Call(ui.url)

	var msg MSG
	for {
		ret, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(ret) <= 0 {
			break
		}
		// Tab 키로 입력칸·버튼 사이를 이동
		if r, _, _ := procIsDialogMessageW.Call(hwnd, uintptr(unsafe.Pointer(&msg))); r != 0 {
			continue
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}
}

func centerWindow(hwnd uintptr) {
	var wa RECT
	procSystemParametersInfoW.Call(SPI_GETWORKAREA, 0, uintptr(unsafe.Pointer(&wa)), 0)
	x := wa.Left + (wa.Right-wa.Left-L.w)/2
	y := wa.Top + (wa.Bottom-wa.Top-L.h)/2
	if y < wa.Top {
		y = wa.Top
	}
	procMoveWindow.Call(hwnd, uintptr(x), uintptr(y), uintptr(L.w), uintptr(L.h), 1)
}
