//go:build windows

package main

import (
	"bufio"
	_ "embed"

	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"
)

//go:embed convert.ps1
var engineScript []byte

const fileTimeout = 4 * time.Minute // 파일 하나가 이보다 오래 걸리면 건너뜀

// 변환 작업. 결과는 events 채널로 UI에 전달된다.
type runner struct {
	mu        sync.Mutex
	cmd       *exec.Cmd
	cancelled bool
	events    chan event
}

func (r *runner) cancel() {
	r.mu.Lock()
	r.cancelled = true
	if r.cmd != nil && r.cmd.Process != nil {
		r.cmd.Process.Kill()
	}
	r.mu.Unlock()
}

func (r *runner) isCancelled() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.cancelled
}

// idx: items 안 번호, paths: 같은 순서의 파일 경로
func (r *runner) run(mode Mode, idx []int, paths []string) {
	defer func() { r.events <- event{Kind: 'F'} }()

	dir, err := os.MkdirTemp("", "workkit-docpdf-")
	if err != nil {
		for _, i := range idx {
			r.events <- event{Kind: 'E', I: i, Code: "OTHER", Text: "임시 폴더를 만들 수 없습니다"}
		}
		return
	}
	defer os.RemoveAll(dir)
	script := filepath.Join(dir, "convert.ps1")
	if err := os.WriteFile(script, engineScript, 0o600); err != nil {
		for _, i := range idx {
			r.events <- event{Kind: 'E', I: i, Code: "OTHER", Text: "임시 파일을 만들 수 없습니다"}
		}
		return
	}
	ps := "powershell.exe"
	if root := os.Getenv("SystemRoot"); root != "" {
		if p := filepath.Join(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe"); fileExists(p) {
			ps = p
		}
	}

	for len(idx) > 0 && !r.isCancelled() {
		list := filepath.Join(dir, "list.txt")
		if err := os.WriteFile(list, []byte(strings.Join(paths, "\r\n")), 0o600); err != nil {
			break
		}
		cmd := exec.Command(ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-STA", "-File", script, "-Mode", mode.arg(), "-ListFile", list)
		cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
		out, err := cmd.StdoutPipe()
		if err == nil {
			err = cmd.Start()
		}
		if err != nil {
			for _, i := range idx {
				r.events <- event{Kind: 'E', I: i, Code: "OTHER", Text: "PowerShell을 실행할 수 없습니다"}
			}
			return
		}
		r.mu.Lock()
		r.cmd = cmd
		if r.cancelled {
			cmd.Process.Kill()
		}
		r.mu.Unlock()

		var (
			stMu     sync.Mutex
			current  = -1 // 진행 중인 로컬 번호
			started  time.Time
			finished = map[int]bool{}
			timedOut = false
		)
		stop := make(chan struct{})
		go func() { // 감시: 파일 하나가 너무 오래 걸리면 엔진을 끈다
			t := time.NewTicker(time.Second)
			defer t.Stop()
			for {
				select {
				case <-stop:
					return
				case <-t.C:
					stMu.Lock()
					if current >= 0 && !finished[current] && time.Since(started) > fileTimeout {
						timedOut = true
						cmd.Process.Kill()
					}
					stMu.Unlock()
				}
			}
		}()

		sc := bufio.NewScanner(out)
		sc.Buffer(make([]byte, 64*1024), 1024*1024)
		for sc.Scan() {
			ev, ok := parseLine(sc.Text())
			if !ok || ev.I >= len(idx) {
				continue
			}
			stMu.Lock()
			switch ev.Kind {
			case 'S':
				current, started = ev.I, time.Now()
			case 'O', 'E':
				finished[ev.I] = true
			}
			stMu.Unlock()
			ev.I = idx[ev.I]
			if ev.Kind == 'E' {
				ev.Text = errorMessage(ev.Code, ev.Text)
			}
			r.events <- ev
		}
		cmd.Wait()
		close(stop)
		r.mu.Lock()
		r.cmd = nil
		r.mu.Unlock()

		// 끝나지 않은 항목 정리
		stMu.Lock()
		next := -1
		for k := range idx {
			if !finished[k] {
				next = k
				break
			}
		}
		to := timedOut
		cur := current
		stMu.Unlock()
		if next < 0 {
			return
		}
		if r.isCancelled() {
			for k := next; k < len(idx); k++ {
				if !finished[k] {
					r.events <- event{Kind: 'E', I: idx[k], Code: "CANCEL", Text: errorMessage("CANCEL", "")}
				}
			}
			return
		}
		if to && cur >= 0 {
			// 멈춘 파일만 실패로 두고 나머지는 이어서
			r.events <- event{Kind: 'E', I: idx[cur], Code: "TIMEOUT", Text: errorMessage("TIMEOUT", "")}
			var ni []int
			var np []string
			for k := range idx {
				if !finished[k] && k != cur {
					ni = append(ni, idx[k])
					np = append(np, paths[k])
				}
			}
			idx, paths = ni, np
			continue
		}
		// 엔진이 예기치 않게 끝남
		for k := next; k < len(idx); k++ {
			if !finished[k] {
				r.events <- event{Kind: 'E', I: idx[k], Code: "CRASH", Text: errorMessage("CRASH", "")}
			}
		}
		return
	}
}

func fileExists(p string) bool { st, err := os.Stat(p); return err == nil && !st.IsDir() }
