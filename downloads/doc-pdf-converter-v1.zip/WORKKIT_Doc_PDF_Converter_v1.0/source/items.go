package main

import (
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type Mode int

const (
	ModeToPDF Mode = iota
	ModeToWord
	ModeToHwp
)

func (m Mode) arg() string    { return [...]string{"topdf", "toword", "tohwp"}[m] }
func (m Mode) outExt() string { return [...]string{".pdf", ".docx", ".hwp"}[m] }

var docExts = map[string]bool{".hwp": true, ".hwpx": true, ".doc": true, ".docx": true, ".rtf": true, ".odt": true}

// 이 프로그램이 다룰 수 있는 파일인지 (어느 방식이든)
func supported(path string) bool {
	e := strings.ToLower(filepath.Ext(path))
	return e == ".pdf" || docExts[e]
}

func eligible(m Mode, path string) bool {
	e := strings.ToLower(filepath.Ext(path))
	if m == ModeToPDF {
		return docExts[e]
	}
	return e == ".pdf"
}

func needsHwp(m Mode, path string) bool {
	e := strings.ToLower(filepath.Ext(path))
	return m == ModeToHwp || (m == ModeToPDF && (e == ".hwp" || e == ".hwpx"))
}
func needsWord(m Mode, path string) bool {
	e := strings.ToLower(filepath.Ext(path))
	return m != ModeToPDF || (e != ".hwp" && e != ".hwpx")
}

type Status int

const (
	StWait Status = iota
	StRun
	StOK
	StFail
)

type Item struct {
	Path   string
	Name   string
	Status Status
	Result string // 결과 파일 경로 또는 오류 메시지
}

// 경로 목록을 기존 목록에 더한다. 폴더는 바로 안의 지원 파일만, 중복은 무시.
// 반환: 추가된 수, 지원하지 않아 뺀 수
func addPaths(items []*Item, paths []string) ([]*Item, int, int) {
	seen := map[string]bool{}
	for _, it := range items {
		seen[strings.ToLower(it.Path)] = true
	}
	added, skipped := 0, 0
	add := func(p string) {
		if !supported(p) {
			skipped++
			return
		}
		k := strings.ToLower(p)
		if seen[k] {
			return
		}
		seen[k] = true
		items = append(items, &Item{Path: p, Name: filepath.Base(p)})
		added++
	}
	for _, p := range paths {
		st, err := os.Stat(p)
		if err != nil {
			continue
		}
		if !st.IsDir() {
			add(p)
			continue
		}
		ents, err := os.ReadDir(p)
		if err != nil {
			continue
		}
		var names []string
		for _, e := range ents {
			if !e.IsDir() && supported(e.Name()) && !strings.HasPrefix(e.Name(), "~$") {
				names = append(names, e.Name())
			}
		}
		sort.Slice(names, func(i, j int) bool { return naturalLess(names[i], names[j]) })
		for _, n := range names {
			add(filepath.Join(p, n))
		}
	}
	return items, added, skipped
}

// 탐색기와 비슷한 이름순 (숫자는 크기순)
func naturalLess(a, b string) bool {
	a, b = strings.ToLower(a), strings.ToLower(b)
	for a != "" && b != "" {
		ad, bd := isDigit(a[0]), isDigit(b[0])
		if ad && bd {
			na, ra := splitNum(a)
			nb, rb := splitNum(b)
			ta, tb := strings.TrimLeft(na, "0"), strings.TrimLeft(nb, "0")
			if len(ta) != len(tb) {
				return len(ta) < len(tb)
			}
			if ta != tb {
				return ta < tb
			}
			a, b = ra, rb
			continue
		}
		if a[0] != b[0] {
			return a[0] < b[0]
		}
		a, b = a[1:], b[1:]
	}
	return len(a) < len(b)
}
func isDigit(c byte) bool { return c >= '0' && c <= '9' }
func splitNum(s string) (string, string) {
	i := 0
	for i < len(s) && isDigit(s[i]) {
		i++
	}
	return s[:i], s[i:]
}

var errText = map[string]string{
	"NOWORD":  "Microsoft Word가 없어 변환할 수 없습니다",
	"NOHWP":   "한글(한컴오피스)이 없어 변환할 수 없습니다",
	"OPEN":    "파일을 열 수 없습니다 (암호·손상 여부 확인)",
	"SAVE":    "결과 파일을 저장하지 못했습니다",
	"MISSING": "원본 파일을 찾을 수 없습니다",
	"TIMEOUT": "응답이 없어 건너뛰었습니다",
	"CANCEL":  "취소했습니다",
	"CRASH":   "변환 엔진이 멈췄습니다",
}

func errorMessage(code, msg string) string {
	if t, ok := errText[code]; ok {
		return t
	}
	if msg == "" {
		return "변환하지 못했습니다"
	}
	return "변환 실패: " + msg
}
