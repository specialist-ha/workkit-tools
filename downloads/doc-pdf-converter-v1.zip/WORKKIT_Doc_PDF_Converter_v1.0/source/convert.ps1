param([string]$Mode, [string]$ListFile)
# WORKKIT Doc PDF Converter engine.
# Uses Microsoft Word and Hancom Hwp already installed on this PC (COM automation).
# Output protocol (UTF-8, one line each):
#   S <i>                 started item i
#   O <i> TAB <path>      item i converted to <path>
#   E <i> TAB <code> TAB <message>
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)

function Say([string]$s) { [Console]::Out.WriteLine($s); [Console]::Out.Flush() }
function Clean([string]$s) { if (-not $s) { return '' }; return ($s -replace '[\r\n\t]+', ' ').Trim() }

function Get-Unique([string]$p) {
    if (-not [IO.File]::Exists($p)) { return $p }
    $d = [IO.Path]::GetDirectoryName($p); $n = [IO.Path]::GetFileNameWithoutExtension($p); $e = [IO.Path]::GetExtension($p)
    for ($i = 2; ; $i++) {
        $c = [IO.Path]::Combine($d, "$n ($i)$e")
        if (-not [IO.File]::Exists($c)) { return $c }
    }
}

$script:word = $null
$script:hwp = $null

function Get-Word {
    if ($null -eq $script:word) {
        try { $script:word = New-Object -ComObject Word.Application } catch { throw 'NOWORD' }
        $script:word.Visible = $false
        $script:word.DisplayAlerts = 0
        try { $script:word.AutomationSecurity = 3 } catch {}   # macros off
    }
    return $script:word
}

function Get-Hwp {
    if ($null -eq $script:hwp) {
        try { $script:hwp = New-Object -ComObject HWPFrame.HwpObject } catch { throw 'NOHWP' }
        # Optional security module; when it is not installed Hwp asks once ("Allow all").
        try { [void]$script:hwp.RegisterModule('FilePathCheckDLL', 'FilePathCheckerModule') } catch {}
    }
    return $script:hwp
}

$NoPass = 'workkit-no-password'

function Convert-WordToPdf([string]$src, [string]$dst) {
    $w = Get-Word
    try { $doc = $w.Documents.Open($src, $false, $true, $false, $NoPass) } catch { throw 'OPEN' }
    try { $doc.ExportAsFixedFormat($dst, 17) } finally { $doc.Close(0) }
}

function Convert-PdfToWord([string]$src, [string]$dst) {
    $w = Get-Word
    try { $doc = $w.Documents.Open($src, $false, $true, $false, $NoPass) } catch { throw 'OPEN' }
    try { $doc.SaveAs2($dst, 16) } finally { $doc.Close(0) }
}

function Convert-WithHwp([string]$src, [string]$dst, [string]$format) {
    $h = Get-Hwp
    $ok = $false
    try { $ok = $h.Open($src, '', 'forceopen:true;suspendpassword:true;versionwarning:false') } catch { $ok = $false }
    if (-not $ok) { try { [void]$h.Clear(1) } catch {}; throw 'OPEN' }
    try {
        if (-not $h.SaveAs($dst, $format, '')) { throw 'SAVE' }
    } finally { try { [void]$h.Clear(1) } catch {} }
}

$files = [IO.File]::ReadAllLines($ListFile, [Text.Encoding]::UTF8)
try {
    for ($i = 0; $i -lt $files.Length; $i++) {
        $src = $files[$i]
        if (-not $src) { continue }
        Say "S $i"
        $tmp = $null
        try {
            if (-not [IO.File]::Exists($src)) { throw 'MISSING' }
            $dir = [IO.Path]::GetDirectoryName($src)
            $base = [IO.Path]::GetFileNameWithoutExtension($src)
            $ext = [IO.Path]::GetExtension($src).ToLowerInvariant()
            switch ($Mode) {
                'topdf' {
                    $dst = Get-Unique ([IO.Path]::Combine($dir, "$base.pdf"))
                    if ($ext -eq '.hwp' -or $ext -eq '.hwpx') { Convert-WithHwp $src $dst 'PDF' } else { Convert-WordToPdf $src $dst }
                }
                'toword' {
                    $dst = Get-Unique ([IO.Path]::Combine($dir, "$base.docx"))
                    Convert-PdfToWord $src $dst
                }
                'tohwp' {
                    $dst = Get-Unique ([IO.Path]::Combine($dir, "$base.hwp"))
                    $null = Get-Hwp   # fail early when Hwp is missing
                    $tmp = [IO.Path]::Combine([IO.Path]::GetTempPath(), 'workkit-' + [guid]::NewGuid().ToString('N') + '.docx')
                    Convert-PdfToWord $src $tmp
                    Convert-WithHwp $tmp $dst 'HWP'
                }
                default { throw "unknown mode $Mode" }
            }
            if (-not [IO.File]::Exists($dst)) { throw 'SAVE' }
            Say ("O $i`t" + $dst)
        } catch {
            $m = [string]$_.Exception.Message
            $code = 'OTHER'
            if ($m -in @('NOWORD', 'NOHWP', 'OPEN', 'SAVE', 'MISSING')) { $code = $m; $m = '' }
            Say ("E $i`t$code`t" + (Clean $m))
        } finally {
            if ($tmp -and [IO.File]::Exists($tmp)) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
        }
    }
} finally {
    if ($null -ne $script:word) { try { $script:word.Quit(0) } catch {}; try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:word) } catch {} }
    if ($null -ne $script:hwp) { try { $script:hwp.Quit() } catch {}; try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:hwp) } catch {} }
}
