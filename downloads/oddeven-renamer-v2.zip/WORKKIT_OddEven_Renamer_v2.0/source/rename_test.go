package main

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"
)

func mk(t *testing.T, names ...string) string {
	d := t.TempDir()
	for _, n := range names {
		os.WriteFile(filepath.Join(d, n), []byte(n), 0644)
	}
	os.Mkdir(filepath.Join(d, "하위폴더"), 0755)
	return d
}

func ls(d string) []string {
	e, _ := os.ReadDir(d)
	var r []string
	for _, x := range e {
		if !x.IsDir() {
			r = append(r, x.Name())
		}
	}
	sort.Strings(r)
	return r
}

var n = 0

func tmp() string { n++; return fmt.Sprintf(".workkit-oe-%d.tmp", n) }

func TestNatural(t *testing.T) {
	in := []string{"영상10.mp4", "영상2.mp4", "영상1.mp4", "B.txt", "a.txt"}
	sort.SliceStable(in, func(i, j int) bool { return naturalLess(in[i], in[j]) })
	if strings.Join(in, ",") != "a.txt,B.txt,영상1.mp4,영상2.mp4,영상10.mp4" {
		t.Fatal(in)
	}
}

func TestApplyRemoveUndo(t *testing.T) {
	d := mk(t, "c 2.mp4", "c 10.mp4", "desktop.ini", "05 기존.mp4")
	names, _ := listFiles(d, nil)
	if len(names) != 3 {
		t.Fatal(names)
	}
	p, err := buildPlan(d, names, OpApply, Odd)
	if err != nil {
		t.Fatal(err)
	}
	// 05 기존.mp4 → 01 기존.mp4, c 2 → 03, c 10 → 05
	_, undo, err := applyPlan(p, tmp)
	if err != nil {
		t.Fatal(err)
	}
	got := strings.Join(ls(d), "|")
	if got != "01 기존.mp4|03 c 2.mp4|05 c 10.mp4|desktop.ini" {
		t.Fatal(got)
	}
	// 짝수로 다시 붙이면 기존 번호를 교체
	names, _ = listFiles(d, nil)
	p, _ = buildPlan(d, names, OpApply, Even)
	applyPlan(p, tmp)
	if g := strings.Join(ls(d), "|"); g != "02 기존.mp4|04 c 2.mp4|06 c 10.mp4|desktop.ini" {
		t.Fatal(g)
	}
	// 홀수 지우기 → 짝수라 변화 없음
	names, _ = listFiles(d, nil)
	p, _ = buildPlan(d, names, OpRemove, Odd)
	if p.Changes != 0 {
		t.Fatal("should be 0")
	}
	p, _ = buildPlan(d, names, OpRemove, Even)
	applyPlan(p, tmp)
	if g := strings.Join(ls(d), "|"); g != "c 10.mp4|c 2.mp4|desktop.ini|기존.mp4" {
		t.Fatal(g)
	}
	_ = undo
}

func TestUndo(t *testing.T) {
	d := mk(t, "a.mp4", "b.mp4")
	names, _ := listFiles(d, nil)
	p, _ := buildPlan(d, names, OpApply, Odd)
	_, undo, _ := applyPlan(p, tmp)
	up, err := undoPlan(d, undo)
	if err != nil {
		t.Fatal(err)
	}
	applyPlan(up, tmp)
	if g := strings.Join(ls(d), "|"); g != "a.mp4|b.mp4" {
		t.Fatal(g)
	}
}

func TestConflictAndLimit(t *testing.T) {
	d := mk(t, "01 a.mp4", "a.mp4")
	names, _ := listFiles(d, nil)
	if _, err := buildPlan(d, names, OpRemove, Odd); err == nil {
		t.Fatal("expected conflict")
	}
	var many []string
	for i := 0; i < 50; i++ {
		many = append(many, fmt.Sprintf("f%d", i))
	}
	if _, err := buildPlan(d, many, OpApply, Even); err == nil {
		t.Fatal("expected limit")
	}
	if _, err := buildPlan(t.TempDir(), many, OpApply, Odd); err != nil {
		t.Fatal(err)
	}
}

func TestRollback(t *testing.T) {
	d := mk(t, "a.mp4", "b.mp4")
	names, _ := listFiles(d, nil)
	p, _ := buildPlan(d, names, OpApply, Odd)
	p.Items[1].New = "없는폴더/x.mp4" // 두 번째 최종 이동 실패 유도
	if _, _, err := applyPlan(p, tmp); err == nil {
		t.Fatal("expected error")
	}
	if g := strings.Join(ls(d), "|"); g != "a.mp4|b.mp4" {
		t.Fatal("rollback failed: " + g)
	}
}
