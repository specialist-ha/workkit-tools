﻿$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogFile = Join-Path $Root 'error.log'
$EngineDir = Join-Path $Root 'engine'
$CacheDir = Join-Path $Root 'cache'

function Write-Log {
    param([string]$Text)
    try {
        $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        Add-Content -LiteralPath $LogFile -Value "[$stamp] $Text" -Encoding UTF8
    } catch {}
}

function Show-ErrorBox {
    param([string]$Message)
    Write-Log $Message
    [System.Windows.Forms.MessageBox]::Show(
        "$Message`r`n`r`n자세한 내용: $LogFile",
        'HEIC 일괄 변환기',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Test-Magick {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path)) {
        return $false
    }
    try {
        $result = & $Path -version 2>&1 | Out-String
        return ($LASTEXITCODE -eq 0 -and $result -match 'ImageMagick')
    } catch {
        Write-Log "ImageMagick test failed: $($_.Exception.Message)"
        return $false
    }
}

function Find-Magick {
    if (Test-Path -LiteralPath $EngineDir) {
        $local = Get-ChildItem -LiteralPath $EngineDir -Filter 'magick.exe' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($local -and (Test-Magick $local.FullName)) {
            return $local.FullName
        }
    }

    $command = Get-Command 'magick.exe' -ErrorAction SilentlyContinue
    if ($command -and (Test-Magick $command.Source)) {
        return $command.Source
    }

    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ([string]::IsNullOrWhiteSpace($base) -or -not (Test-Path -LiteralPath $base)) { continue }
        $found = Get-ChildItem -LiteralPath $base -Filter 'magick.exe' -File -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.DirectoryName -match 'ImageMagick' } |
            Select-Object -First 1
        if ($found -and (Test-Magick $found.FullName)) {
            return $found.FullName
        }
    }

    return $null
}

function Download-File {
    param([string]$Url, [string]$Destination)
    Write-Log "Downloading: $Url"
    if (Test-Path -LiteralPath $Destination) {
        Remove-Item -LiteralPath $Destination -Force
    }
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destination
    if (-not (Test-Path -LiteralPath $Destination)) {
        throw "다운로드 파일이 생성되지 않았습니다: $Destination"
    }
}

function Get-PortableImageMagickUrl {
    $page = Invoke-WebRequest -UseBasicParsing -Uri 'https://imagemagick.org/download/'
    $pattern = 'https://github\.com/ImageMagick/ImageMagick/releases/download/[^"''<>\s]+/ImageMagick-[^"''<>\s]+-portable-Q16-x64\.7z'
    $match = [regex]::Match($page.Content, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($match.Success) {
        return $match.Value
    }

    $pattern2 = 'https://github\.com/ImageMagick/ImageMagick/releases/download/[^"''<>\s]+/ImageMagick-[^"''<>\s]+-portable-Q8-x64\.7z'
    $match2 = [regex]::Match($page.Content, $pattern2, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($match2.Success) {
        return $match2.Value
    }

    throw 'ImageMagick 공식 페이지에서 Windows 포터블 파일 주소를 찾지 못했습니다.'
}

function Show-SetupForm {
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'HEIC 일괄 변환기 - 최초 실행 준비'
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.ClientSize = New-Object System.Drawing.Size(520, 145)

    $label = New-Object System.Windows.Forms.Label
    $label.Location = New-Object System.Drawing.Point(20, 18)
    $label.Size = New-Object System.Drawing.Size(480, 55)
    $label.Text = "HEIC 변환 엔진을 준비하고 있습니다.`r`n최초 실행에만 인터넷 연결이 필요합니다."
    $form.Controls.Add($label)

    $bar = New-Object System.Windows.Forms.ProgressBar
    $bar.Location = New-Object System.Drawing.Point(20, 88)
    $bar.Size = New-Object System.Drawing.Size(480, 24)
    $bar.Style = 'Marquee'
    $bar.MarqueeAnimationSpeed = 25
    $form.Controls.Add($bar)

    $form.Show()
    [System.Windows.Forms.Application]::DoEvents()
    return @{ Form = $form; Label = $label }
}

function Install-PortableMagick {
    if (-not (Test-Path -LiteralPath $CacheDir)) {
        New-Item -ItemType Directory -Path $CacheDir -Force | Out-Null
    }

    $setup = Show-SetupForm
    try {
        $setup.Label.Text = 'ImageMagick 공식 배포 파일을 확인하고 있습니다...'
        [System.Windows.Forms.Application]::DoEvents()
        $magickUrl = Get-PortableImageMagickUrl

        $sevenZip = Join-Path $CacheDir '7zr.exe'
        $archive = Join-Path $CacheDir 'imagemagick-portable.7z'

        if (-not (Test-Path -LiteralPath $sevenZip)) {
            $setup.Label.Text = '압축 해제 도구를 내려받고 있습니다...'
            [System.Windows.Forms.Application]::DoEvents()
            Download-File 'https://www.7-zip.org/a/7zr.exe' $sevenZip
        }

        $setup.Label.Text = 'HEIC 변환 엔진을 내려받고 있습니다...'
        [System.Windows.Forms.Application]::DoEvents()
        Download-File $magickUrl $archive

        $setup.Label.Text = '변환 엔진을 프로그램 폴더에 설치하고 있습니다...'
        [System.Windows.Forms.Application]::DoEvents()
        if (Test-Path -LiteralPath $EngineDir) {
            Remove-Item -LiteralPath $EngineDir -Recurse -Force
        }
        New-Item -ItemType Directory -Path $EngineDir -Force | Out-Null

        $extractOutput = & $sevenZip 'x' $archive "-o$EngineDir" '-y' 2>&1 | Out-String
        Write-Log $extractOutput
        if ($LASTEXITCODE -ne 0) {
            throw "ImageMagick 압축 해제에 실패했습니다. 종료 코드: $LASTEXITCODE"
        }

        $magick = Find-Magick
        if (-not $magick) {
            $setup.Label.Text = 'Windows 실행 구성요소를 확인하고 있습니다...'
            [System.Windows.Forms.Application]::DoEvents()

            $vc = Join-Path $CacheDir 'vc_redist.x64.exe'
            try {
                Download-File 'https://aka.ms/vs/17/release/vc_redist.x64.exe' $vc
                $process = Start-Process -FilePath $vc -ArgumentList '/install /quiet /norestart' -Wait -PassThru
                Write-Log "VC++ runtime installer exit code: $($process.ExitCode)"
            } catch {
                Write-Log "VC++ runtime install failed: $($_.Exception.Message)"
            }
            $magick = Find-Magick
        }

        if (-not $magick) {
            throw '변환 엔진을 설치했지만 magick.exe를 실행하지 못했습니다.'
        }

        try { Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue } catch {}
        return $magick
    } finally {
        try { $setup.Form.Close(); $setup.Form.Dispose() } catch {}
    }
}

function Test-HeicSupport {
    param([string]$MagickPath)
    try {
        $formats = & $MagickPath identify -list format 2>&1 | Out-String
        Write-Log 'ImageMagick format check completed.'
        return ($formats -match '(?im)^\s*HEIC\*?\s' -or $formats -match '(?im)^\s*HEIF\*?\s')
    } catch {
        Write-Log "HEIC support check failed: $($_.Exception.Message)"
        return $false
    }
}

function Get-UniquePath {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $Path }
    $directory = [System.IO.Path]::GetDirectoryName($Path)
    $name = [System.IO.Path]::GetFileNameWithoutExtension($Path)
    $extension = [System.IO.Path]::GetExtension($Path)
    $index = 1
    do {
        $candidate = Join-Path $directory ("{0}_{1}{2}" -f $name, $index, $extension)
        $index++
    } while (Test-Path -LiteralPath $candidate)
    return $candidate
}

function Add-AppLog {
    param([System.Windows.Forms.TextBox]$Box, [string]$Text)
    $Box.AppendText($Text + [Environment]::NewLine)
    $Box.SelectionStart = $Box.TextLength
    $Box.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

try {
    Write-Log 'Application start.'
    $MagickPath = Find-Magick
    if (-not $MagickPath) {
        $MagickPath = Install-PortableMagick
    }

    if (-not (Test-Magick $MagickPath)) {
        throw 'ImageMagick 실행 확인에 실패했습니다.'
    }

    if (-not (Test-HeicSupport $MagickPath)) {
        throw '설치된 ImageMagick에서 HEIC/HEIF 읽기 기능을 확인하지 못했습니다.'
    }

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'HEIC 일괄 변환기'
    $form.StartPosition = 'CenterScreen'
    $form.Size = New-Object System.Drawing.Size(760, 650)
    $form.MinimumSize = New-Object System.Drawing.Size(720, 610)

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'HEIC 일괄 변환기'
    $title.Font = New-Object System.Drawing.Font('맑은 고딕', 16, [System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(20, 16)
    $title.AutoSize = $true
    $form.Controls.Add($title)

    $subtitle = New-Object System.Windows.Forms.Label
    $subtitle.Text = '선택한 폴더의 HEIC/HEIF 파일을 JPG 또는 PNG로 변환합니다.'
    $subtitle.Location = New-Object System.Drawing.Point(22, 52)
    $subtitle.AutoSize = $true
    $form.Controls.Add($subtitle)

    $inputLabel = New-Object System.Windows.Forms.Label
    $inputLabel.Text = '원본 폴더'
    $inputLabel.Location = New-Object System.Drawing.Point(22, 94)
    $inputLabel.AutoSize = $true
    $form.Controls.Add($inputLabel)

    $inputBox = New-Object System.Windows.Forms.TextBox
    $inputBox.Location = New-Object System.Drawing.Point(105, 90)
    $inputBox.Size = New-Object System.Drawing.Size(525, 25)
    $form.Controls.Add($inputBox)

    $inputButton = New-Object System.Windows.Forms.Button
    $inputButton.Text = '찾아보기'
    $inputButton.Location = New-Object System.Drawing.Point(640, 88)
    $inputButton.Size = New-Object System.Drawing.Size(88, 28)
    $form.Controls.Add($inputButton)

    $outputLabel = New-Object System.Windows.Forms.Label
    $outputLabel.Text = '저장 폴더'
    $outputLabel.Location = New-Object System.Drawing.Point(22, 133)
    $outputLabel.AutoSize = $true
    $form.Controls.Add($outputLabel)

    $outputBox = New-Object System.Windows.Forms.TextBox
    $outputBox.Location = New-Object System.Drawing.Point(105, 129)
    $outputBox.Size = New-Object System.Drawing.Size(525, 25)
    $form.Controls.Add($outputBox)

    $outputButton = New-Object System.Windows.Forms.Button
    $outputButton.Text = '찾아보기'
    $outputButton.Location = New-Object System.Drawing.Point(640, 127)
    $outputButton.Size = New-Object System.Drawing.Size(88, 28)
    $form.Controls.Add($outputButton)

    $formatLabel = New-Object System.Windows.Forms.Label
    $formatLabel.Text = '출력 형식'
    $formatLabel.Location = New-Object System.Drawing.Point(22, 180)
    $formatLabel.AutoSize = $true
    $form.Controls.Add($formatLabel)

    $formatBox = New-Object System.Windows.Forms.ComboBox
    $formatBox.Location = New-Object System.Drawing.Point(105, 176)
    $formatBox.Size = New-Object System.Drawing.Size(110, 26)
    $formatBox.DropDownStyle = 'DropDownList'
    [void]$formatBox.Items.Add('JPG')
    [void]$formatBox.Items.Add('PNG')
    $formatBox.SelectedIndex = 0
    $form.Controls.Add($formatBox)

    $qualityLabel = New-Object System.Windows.Forms.Label
    $qualityLabel.Text = 'JPG 품질'
    $qualityLabel.Location = New-Object System.Drawing.Point(250, 180)
    $qualityLabel.AutoSize = $true
    $form.Controls.Add($qualityLabel)

    $qualityBox = New-Object System.Windows.Forms.NumericUpDown
    $qualityBox.Location = New-Object System.Drawing.Point(325, 176)
    $qualityBox.Size = New-Object System.Drawing.Size(75, 26)
    $qualityBox.Minimum = 60
    $qualityBox.Maximum = 100
    $qualityBox.Value = 92
    $form.Controls.Add($qualityBox)

    $recurseBox = New-Object System.Windows.Forms.CheckBox
    $recurseBox.Text = '하위 폴더 포함'
    $recurseBox.Location = New-Object System.Drawing.Point(22, 220)
    $recurseBox.AutoSize = $true
    $recurseBox.Checked = $true
    $form.Controls.Add($recurseBox)

    $structureBox = New-Object System.Windows.Forms.CheckBox
    $structureBox.Text = '원본 폴더 구조 유지'
    $structureBox.Location = New-Object System.Drawing.Point(165, 220)
    $structureBox.AutoSize = $true
    $structureBox.Checked = $true
    $form.Controls.Add($structureBox)

    $overwriteBox = New-Object System.Windows.Forms.CheckBox
    $overwriteBox.Text = '기존 결과 파일 덮어쓰기'
    $overwriteBox.Location = New-Object System.Drawing.Point(350, 220)
    $overwriteBox.AutoSize = $true
    $overwriteBox.Checked = $false
    $form.Controls.Add($overwriteBox)

    $statusLabel = New-Object System.Windows.Forms.Label
    $statusLabel.Text = '대기 중'
    $statusLabel.Location = New-Object System.Drawing.Point(22, 265)
    $statusLabel.AutoSize = $true
    $form.Controls.Add($statusLabel)

    $progress = New-Object System.Windows.Forms.ProgressBar
    $progress.Location = New-Object System.Drawing.Point(22, 292)
    $progress.Size = New-Object System.Drawing.Size(706, 24)
    $form.Controls.Add($progress)

    $logBox = New-Object System.Windows.Forms.TextBox
    $logBox.Location = New-Object System.Drawing.Point(22, 332)
    $logBox.Size = New-Object System.Drawing.Size(706, 205)
    $logBox.Multiline = $true
    $logBox.ScrollBars = 'Vertical'
    $logBox.ReadOnly = $true
    $logBox.Font = New-Object System.Drawing.Font('Consolas', 9)
    $logBox.Anchor = 'Top,Bottom,Left,Right'
    $form.Controls.Add($logBox)

    $openButton = New-Object System.Windows.Forms.Button
    $openButton.Text = '저장 폴더 열기'
    $openButton.Location = New-Object System.Drawing.Point(492, 555)
    $openButton.Size = New-Object System.Drawing.Size(112, 36)
    $openButton.Anchor = 'Bottom,Right'
    $form.Controls.Add($openButton)

    $startButton = New-Object System.Windows.Forms.Button
    $startButton.Text = '변환 시작'
    $startButton.Location = New-Object System.Drawing.Point(616, 555)
    $startButton.Size = New-Object System.Drawing.Size(112, 36)
    $startButton.Anchor = 'Bottom,Right'
    $form.Controls.Add($startButton)

    $folderDialog = New-Object System.Windows.Forms.FolderBrowserDialog

    $inputButton.Add_Click({
        $folderDialog.Description = 'HEIC 파일이 있는 원본 폴더를 선택하세요.'
        if ($folderDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $inputBox.Text = $folderDialog.SelectedPath
            if ([string]::IsNullOrWhiteSpace($outputBox.Text)) {
                $outputBox.Text = Join-Path $folderDialog.SelectedPath 'converted'
            }
        }
    })

    $outputButton.Add_Click({
        $folderDialog.Description = '변환 파일을 저장할 폴더를 선택하세요.'
        if ($folderDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $outputBox.Text = $folderDialog.SelectedPath
        }
    })

    $formatBox.Add_SelectedIndexChanged({
        $qualityBox.Enabled = ($formatBox.SelectedItem -eq 'JPG')
    })

    $openButton.Add_Click({
        if ([string]::IsNullOrWhiteSpace($outputBox.Text)) {
            [System.Windows.Forms.MessageBox]::Show('저장 폴더를 먼저 지정하세요.', 'HEIC 일괄 변환기') | Out-Null
            return
        }
        if (-not (Test-Path -LiteralPath $outputBox.Text)) {
            New-Item -ItemType Directory -Path $outputBox.Text -Force | Out-Null
        }
        Start-Process explorer.exe -ArgumentList ('"{0}"' -f $outputBox.Text)
    })

    $startButton.Add_Click({
        try {
            $inputDir = $inputBox.Text.Trim()
            $outputDir = $outputBox.Text.Trim()

            if ([string]::IsNullOrWhiteSpace($inputDir) -or -not (Test-Path -LiteralPath $inputDir -PathType Container)) {
                [System.Windows.Forms.MessageBox]::Show('올바른 원본 폴더를 지정하세요.', 'HEIC 일괄 변환기') | Out-Null
                return
            }
            if ([string]::IsNullOrWhiteSpace($outputDir)) {
                $outputDir = Join-Path $inputDir 'converted'
                $outputBox.Text = $outputDir
            }
            New-Item -ItemType Directory -Path $outputDir -Force | Out-Null

            $inputFull = [System.IO.Path]::GetFullPath($inputDir).TrimEnd('\')
            $outputFull = [System.IO.Path]::GetFullPath($outputDir).TrimEnd('\')
            $outputIsSubfolder = (-not $outputFull.Equals($inputFull, [System.StringComparison]::OrdinalIgnoreCase)) -and
                $outputFull.StartsWith($inputFull + '\', [System.StringComparison]::OrdinalIgnoreCase)
            $searchOption = if ($recurseBox.Checked) { [System.IO.SearchOption]::AllDirectories } else { [System.IO.SearchOption]::TopDirectoryOnly }

            $statusLabel.Text = 'HEIC 파일 검색 중...'
            $startButton.Enabled = $false
            $logBox.Clear()
            [System.Windows.Forms.Application]::DoEvents()

            $files = [System.IO.Directory]::EnumerateFiles($inputFull, '*', $searchOption) |
                Where-Object {
                    $ext = [System.IO.Path]::GetExtension($_).ToLowerInvariant()
                    ($ext -eq '.heic' -or $ext -eq '.heif') -and
                    -not ($outputIsSubfolder -and
                          $_.StartsWith($outputFull + '\', [System.StringComparison]::OrdinalIgnoreCase))
                } |
                Sort-Object

            $files = @($files)
            if ($files.Count -eq 0) {
                $statusLabel.Text = 'HEIC/HEIF 파일 없음'
                [System.Windows.Forms.MessageBox]::Show('선택한 폴더에서 HEIC 또는 HEIF 파일을 찾지 못했습니다.', 'HEIC 일괄 변환기') | Out-Null
                return
            }

            $progress.Minimum = 0
            $progress.Maximum = $files.Count
            $progress.Value = 0
            $success = 0
            $failed = 0
            $extension = if ($formatBox.SelectedItem -eq 'PNG') { '.png' } else { '.jpg' }

            for ($i = 0; $i -lt $files.Count; $i++) {
                $sourcePath = $files[$i]
                $sourceInfo = Get-Item -LiteralPath $sourcePath

                if ($structureBox.Checked) {
                    $relativeParent = $sourceInfo.DirectoryName.Substring($inputFull.Length).TrimStart('\')
                    $targetDir = if ([string]::IsNullOrWhiteSpace($relativeParent)) { $outputFull } else { Join-Path $outputFull $relativeParent }
                } else {
                    $targetDir = $outputFull
                }
                New-Item -ItemType Directory -Path $targetDir -Force | Out-Null

                $targetPath = Join-Path $targetDir ($sourceInfo.BaseName + $extension)
                if (-not $overwriteBox.Checked) {
                    $targetPath = Get-UniquePath $targetPath
                }

                $statusLabel.Text = "변환 중: $($i + 1) / $($files.Count)"
                [System.Windows.Forms.Application]::DoEvents()

                try {
                    $inputFrame = $sourcePath + '[0]'
                    if ($formatBox.SelectedItem -eq 'PNG') {
                        $arguments = @($inputFrame, '-auto-orient', '-colorspace', 'sRGB', $targetPath)
                    } else {
                        $arguments = @($inputFrame, '-auto-orient', '-colorspace', 'sRGB', '-quality', $qualityBox.Value.ToString(), $targetPath)
                    }

                    $commandOutput = & $MagickPath @arguments 2>&1 | Out-String
                    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $targetPath)) {
                        throw "ImageMagick 종료 코드 $LASTEXITCODE. $commandOutput"
                    }
                    $success++
                    Add-AppLog $logBox ("[성공] {0} -> {1}" -f $sourceInfo.Name, [System.IO.Path]::GetFileName($targetPath))
                } catch {
                    $failed++
                    $message = "[실패] $sourcePath | $($_.Exception.Message)"
                    Add-AppLog $logBox $message
                    Write-Log $message
                }

                $progress.Value = $i + 1
                [System.Windows.Forms.Application]::DoEvents()
            }

            $statusLabel.Text = "완료: 성공 $success개 / 실패 $failed개"
            [System.Windows.Forms.MessageBox]::Show(
                "변환이 완료되었습니다.`r`n`r`n성공: $success개`r`n실패: $failed개",
                'HEIC 일괄 변환기',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        } catch {
            $message = $_.Exception.ToString()
            Add-AppLog $logBox ("[오류] " + $_.Exception.Message)
            Show-ErrorBox $message
        } finally {
            $startButton.Enabled = $true
        }
    })

    [void]$form.ShowDialog()
    exit 0
} catch {
    $detail = $_.Exception.ToString()
    Show-ErrorBox $detail
    exit 1
}
