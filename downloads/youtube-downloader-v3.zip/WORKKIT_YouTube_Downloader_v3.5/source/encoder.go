package main

// H.264 인코더 선택 — 그래픽카드(GPU) 인코더가 있으면 그것을 쓰고, 없으면 CPU(libx264)로.
// GPU 인코더는 CPU보다 보통 5~20배 빠르다.

import (
	"fmt"
	"sync"
)

type encoder struct {
	Name  string   // ffmpeg 인코더 이름
	Label string   // 화면 표시용
	Args  []string // -c:v 이후 품질 옵션
}

var encoders = []encoder{
	{"h264_nvenc", "NVIDIA GPU", []string{"-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr", "-cq", "21", "-b:v", "0", "-pix_fmt", "yuv420p"}},
	{"h264_qsv", "Intel GPU", []string{"-c:v", "h264_qsv", "-preset", "faster", "-global_quality", "22", "-pix_fmt", "nv12"}},
	{"h264_amf", "AMD GPU", []string{"-c:v", "h264_amf", "-quality", "speed", "-rc", "cqp", "-qp_i", "20", "-qp_p", "22", "-pix_fmt", "nv12"}},
}

// CPU 인코더: fast → veryfast 로 바꿔 약 2배 빠르게 (화질 차이는 거의 없음)
var cpuEncoder = encoder{"libx264", "CPU", []string{"-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p"}}

// probeEncoderArgs: 짧은 검은 화면을 실제로 인코딩해 보는 테스트 명령
func probeEncoderArgs(e encoder) []string {
	args := []string{"-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=black:s=640x360:r=30:d=0.5"}
	args = append(args, e.Args...)
	return append(args, "-frames:v", "10", "-f", "null", "-")
}

var (
	encOnce   sync.Mutex
	encCached *encoder
)

// pickEncoder: 처음 한 번만 검사하고 결과를 기억한다. run은 ffmpeg 실행 함수(성공 시 nil).
func pickEncoder(run func(args []string) error) encoder {
	encOnce.Lock()
	defer encOnce.Unlock()
	if encCached != nil {
		return *encCached
	}
	chosen := cpuEncoder
	for _, e := range encoders {
		if run(probeEncoderArgs(e)) == nil {
			chosen = e
			break
		}
	}
	encCached = &chosen
	return chosen
}

// forgetGPU: GPU 인코딩이 실제 파일에서 실패하면 이후엔 CPU만 쓴다.
func forgetGPU() {
	encOnce.Lock()
	c := cpuEncoder
	encCached = &c
	encOnce.Unlock()
}

// videoFormatArgs: yt-dlp 형식 선택.
// 같은 해상도라면 H.264(avc1)와 AAC를 우선 골라서 변환 자체가 필요 없게 한다.
// (YouTube는 1080p까지 H.264를 제공하고, 1440p·2160p는 VP9/AV1만 있어 변환이 필요하다)
func videoFormatArgs(height int) []string {
	sort := "res,vcodec:h264,acodec:aac"
	if height > 0 {
		sort = fmt.Sprintf("res:%d,vcodec:h264,acodec:aac", height)
	}
	f := "bv*+ba/b"
	if height > 0 {
		f = fmt.Sprintf("bv*[height<=%d]+ba/b[height<=%d]/bv*+ba/b", height, height)
	}
	return []string{"-f", f, "-S", sort}
}
