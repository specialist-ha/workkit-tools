package main

import (
	"errors"
	"strings"
	"testing"
)

func TestPickEncoder(t *testing.T) {
	encCached = nil
	e := pickEncoder(func(a []string) error {
		if strings.Contains(strings.Join(a, " "), "h264_qsv") {
			return nil
		}
		return errors.New("no")
	})
	if e.Name != "h264_qsv" {
		t.Fatal(e.Name)
	}
	forgetGPU()
	if pickEncoder(func([]string) error { return nil }).Name != "libx264" {
		t.Fatal("forget")
	}
	encCached = nil
	if pickEncoder(func([]string) error { return errors.New("x") }).Name != "libx264" {
		t.Fatal("cpu fallback")
	}
	if a := strings.Join(videoFormatArgs(1080), " "); !strings.Contains(a, "res:1080,vcodec:h264") {
		t.Fatal(a)
	}
}
