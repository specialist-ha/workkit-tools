package main

// 홀짝 번호 매기기 — 핵심 로직 (플랫폼 독립, Linux에서 단위 테스트)

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"
)

type Op int

const (
	OpApply  Op = iota // 번호 붙이기
	OpRemove           // 번호 지우기
)

type Parity int

const (
	Odd  Parity = 1
	Even Parity = 0
)

type PlanItem struct {
	Old, New string
	Change   bool
	Status   string
}

type Plan struct {
	Folder  string
	Items   []PlanItem
	Changes int
}

var numbered = regexp.MustCompile(`^(\d{2}) (.+)$`)

// 번호 매기기에서 제외할 파일 (시스템 파일 · 작업 중 임시 파일)
var alwaysSkip = map[string]bool{"desktop.ini": true, "thumbs.db": true, ".ds_store": true}

func maxCount(p Parity) int {
	if p == Odd {
		return 50 // 01 ~ 99
	}
	return 49 // 02 ~ 98
}

// naturalLess: Windows 탐색기와 같은 "자연 정렬" (2 < 10, 대소문자 무시)
func naturalLess(a, b string) bool {
	ra, rb := []rune(strings.ToLower(a)), []rune(strings.ToLower(b))
	i, j := 0, 0
	for i < len(ra) && j < len(rb) {
		ca, cb := ra[i], rb[j]
		if unicode.IsDigit(ca) && unicode.IsDigit(cb) {
			si := i
			for i < len(ra) && unicode.IsDigit(ra[i]) {
				i++
			}
			sj := j
			for j < len(rb) && unicode.IsDigit(rb[j]) {
				j++
			}
			na := strings.TrimLeft(string(ra[si:i]), "0")
			nb := strings.TrimLeft(string(rb[sj:j]), "0")
			if len(na) != len(nb) {
				return len(na) < len(nb)
			}
			if na != nb {
				return na < nb
			}
			if (i - si) != (j - sj) { // 같은 값이면 앞자리 0이 많은 쪽을 먼저
				return (i - si) > (j - sj)
			}
			continue
		}
		if ca != cb {
			return ca < cb
		}
		i++
		j++
	}
	if len(ra)-i != len(rb)-j {
		return len(ra)-i < len(rb)-j
	}
	return a < b
}

// listFiles: 폴더 바로 아래의 일반 파일만 (하위 폴더·숨김·시스템 파일 제외)
func listFiles(folder string, skip func(name string, info os.FileInfo) bool) ([]string, error) {
	entries, err := os.ReadDir(folder)
	if err != nil {
		return nil, err
	}
	var names []string
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		name := e.Name()
		if alwaysSkip[strings.ToLower(name)] || strings.HasPrefix(name, ".workkit-oe-") {
			continue
		}
		info, err := e.Info()
		if err != nil || !info.Mode().IsRegular() {
			continue
		}
		if skip != nil && skip(name, info) {
			continue
		}
		names = append(names, name)
	}
	sort.SliceStable(names, func(i, j int) bool { return naturalLess(names[i], names[j]) })
	return names, nil
}

func buildPlan(folder string, names []string, op Op, parity Parity) (*Plan, error) {
	if op == OpApply && len(names) > maxCount(parity) {
		kind := map[Parity]string{Odd: "홀수", Even: "짝수"}[parity]
		return nil, fmt.Errorf("두 자리 %s 번호는 한 번에 최대 %d개까지 붙일 수 있습니다. (현재 %d개)", kind, maxCount(parity), len(names))
	}
	p := &Plan{Folder: folder}
	for i, old := range names {
		it := PlanItem{Old: old, New: old}
		if op == OpApply {
			base := old
			if m := numbered.FindStringSubmatch(old); m != nil {
				base = m[2]
			}
			n := 2*i + 1
			if parity == Even {
				n = 2*i + 2
			}
			it.New = fmt.Sprintf("%02d %s", n, base)
			it.Change = it.New != old
			it.Status = map[bool]string{true: "번호 붙이기", false: "이미 같음"}[it.Change]
		} else {
			if m := numbered.FindStringSubmatch(old); m != nil {
				var n int
				fmt.Sscanf(m[1], "%d", &n)
				if Parity(n%2) == parity {
					it.New, it.Change, it.Status = m[2], true, "번호 지우기"
				} else {
					it.Status = "다른 홀짝"
				}
			} else {
				it.Status = "번호 없음"
			}
		}
		if it.Change {
			p.Changes++
		}
		p.Items = append(p.Items, it)
	}
	return p, checkConflicts(p)
}

func checkConflicts(p *Plan) error {
	sources := map[string]bool{}
	for _, it := range p.Items {
		if it.Change {
			sources[strings.ToLower(it.Old)] = true
		}
	}
	targets := map[string]string{}
	for _, it := range p.Items {
		if !it.Change {
			continue
		}
		key := strings.ToLower(it.New)
		if prev, ok := targets[key]; ok {
			return fmt.Errorf("바뀔 이름이 서로 겹칩니다.\n\n%s\n%s\n→ %s", prev, it.Old, it.New)
		}
		targets[key] = it.Old
		if _, err := os.Stat(filepath.Join(p.Folder, it.New)); err == nil && !sources[key] {
			return fmt.Errorf("같은 이름의 파일이 이미 있습니다.\n\n%s", it.New)
		}
	}
	return nil
}

type renameStep struct{ orig, temp, final string }

// applyPlan: 임시 이름을 거쳐 두 단계로 바꾸고, 실패하면 가능한 만큼 원래 이름으로 되돌린다.
// 반환값 undo는 되돌리기에 쓸 수 있는 (바뀐 이름 → 원래 이름) 목록.
func applyPlan(p *Plan, newTemp func() string) (done int, undo [][2]string, err error) {
	var steps []*renameStep
	for _, it := range p.Items {
		if it.Change {
			steps = append(steps, &renameStep{
				orig:  filepath.Join(p.Folder, it.Old),
				temp:  filepath.Join(p.Folder, newTemp()),
				final: filepath.Join(p.Folder, it.New),
			})
		}
	}
	stage := make([]int, len(steps)) // 0 원래, 1 임시, 2 최종
	fail := func(e error) (int, [][2]string, error) {
		for i := len(steps) - 1; i >= 0; i-- {
			if stage[i] == 2 && os.Rename(steps[i].final, steps[i].temp) == nil {
				stage[i] = 1
			}
		}
		for i := len(steps) - 1; i >= 0; i-- {
			if stage[i] == 1 && os.Rename(steps[i].temp, steps[i].orig) == nil {
				stage[i] = 0
			}
		}
		return 0, nil, fmt.Errorf("이름을 바꾸다 문제가 생겨 원래 이름으로 되돌렸습니다.\n\n%v", e)
	}
	for i, s := range steps {
		if err := os.Rename(s.orig, s.temp); err != nil {
			return fail(err)
		}
		stage[i] = 1
	}
	for i, s := range steps {
		if err := os.Rename(s.temp, s.final); err != nil {
			return fail(err)
		}
		stage[i] = 2
	}
	for _, s := range steps {
		undo = append(undo, [2]string{filepath.Base(s.final), filepath.Base(s.orig)})
	}
	return len(steps), undo, nil
}

// undoPlan: 직전 작업을 되돌리는 계획을 만든다.
func undoPlan(folder string, undo [][2]string) (*Plan, error) {
	p := &Plan{Folder: folder}
	for _, u := range undo {
		if _, err := os.Stat(filepath.Join(folder, u[0])); err != nil {
			return nil, fmt.Errorf("파일이 옮겨지거나 이름이 바뀌어 되돌릴 수 없습니다.\n\n%s", u[0])
		}
		p.Items = append(p.Items, PlanItem{Old: u[0], New: u[1], Change: true, Status: "되돌리기"})
		p.Changes++
	}
	return p, checkConflicts(p)
}
