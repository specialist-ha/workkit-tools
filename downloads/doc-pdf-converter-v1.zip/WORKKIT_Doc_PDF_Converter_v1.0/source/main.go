//go:build windows

package main

import (
	_ "embed"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

const (
	appName    = "문서 PDF 변환기"
	appBrand   = "WORKKIT"
	appTitle   = "WORKKIT 문서 PDF 변환기"
	appVersion = "v1.0"
	buildDate  = "2026-10-27"
)

//go:embed fonts/Pretendard-Regular.otf
var fontRegular []byte

//go:embed fonts/Pretendard-SemiBold.otf
var fontSemiBold []byte

//go:embed fonts/Pretendard-Bold.otf
var fontBold []byte

// ============================================================
// Win32
// ============================================================

const (
	WM_CREATE                = 0x0001
	WM_DESTROY               = 0x0002
	WM_PAINT                 = 0x000F
	WM_CLOSE                 = 0x0010
	WM_ERASEBKGND            = 0x0014
	WM_SETCURSOR             = 0x0020
	WM_SETFONT               = 0x0030
	WM_DRAWITEM              = 0x002B
	WM_NCHITTEST             = 0x0084
	WM_COMMAND               = 0x0111
	WM_TIMER                 = 0x0113
	WM_CTLCOLOREDIT          = 0x0133
	WM_CTLCOLORSTATIC        = 0x0138
	WM_MOUSEMOVE             = 0x0200
	WM_LBUTTONDOWN           = 0x0201
	WM_LBUTTONUP             = 0x0202
	WM_MOUSEWHEEL            = 0x020A
	WM_MOUSELEAVE            = 0x02A3
	WM_DROPFILES             = 0x0233
	WM_ACTIVATEAPP           = 0x001C
	EN_SETFOCUS              = 0x0100
	EN_KILLFOCUS             = 0x0200
	EN_CHANGE                = 0x0300
	WS_POPUP                 = 0x80000000
	WS_SYSMENU               = 0x00080000
	WS_MINIMIZEBOX           = 0x00020000
	WS_VISIBLE               = 0x10000000
	WS_CHILD                 = 0x40000000
	WS_TABSTOP               = 0x00010000
	WS_CLIPCHILDREN          = 0x02000000
	ES_LEFT                  = 0x0000
	ES_AUTOHSCROLL           = 0x0080
	BS_OWNERDRAW             = 0x0000000B
	SW_SHOW                  = 5
	SW_SHOWNORMAL            = 1
	SW_MINIMIZE              = 6
	IDC_ARROW                = 32512
	IDC_HAND                 = 32649
	MB_OK                    = 0x00000000
	MB_ICONERROR             = 0x00000010
	MB_ICONQUESTION          = 0x00000020
	MB_YESNO                 = 0x00000004
	IDYES                    = 6
	BN_CLICKED               = 0
	ODS_SELECTED             = 0x0001
	ODS_DISABLED             = 0x0004
	ODS_FOCUS                = 0x0010
	ODS_NOFOCUSRECT          = 0x0200
	TME_LEAVE                = 0x00000002
	HTCAPTION                = 2
	GWLP_WNDPROC             = -4
	SPI_GETWORKAREA          = 0x0030
	LOGPIXELSY               = 90
	DT_LEFT                  = 0x00000000
	DT_CENTER                = 0x00000001
	DT_RIGHT                 = 0x00000002
	DT_VCENTER               = 0x00000004
	DT_WORDBREAK             = 0x00000010
	DT_SINGLELINE            = 0x00000020
	DT_NOPREFIX              = 0x00000800
	DT_END_ELLIPSIS          = 0x00008000
	PS_SOLID                 = 0
	NULL_BRUSH               = 5
	TRANSPARENT_BK           = 1
	BIF_RETURNONLYFSDIRS     = 0x00000001
	BIF_NEWDIALOGSTYLE       = 0x00000040
	COINIT_APARTMENTTHREADED = 0x2
	FILE_ATTRIBUTE_HIDDEN    = 0x2
	FILE_ATTRIBUTE_SYSTEM    = 0x4
	WM_LBUTTONDBLCLK         = 0x0203
	WM_RBUTTONUP             = 0x0205
	CS_DBLCLKS               = 0x0008
	OFN_HIDEREADONLY         = 0x00000004
	OFN_ALLOWMULTISELECT     = 0x00000200
	OFN_PATHMUSTEXIST        = 0x00000800
	OFN_FILEMUSTEXIST        = 0x00001000
	OFN_EXPLORER             = 0x00080000
	HKEY_CLASSES_ROOT        = 0x80000000
	KEY_READ                 = 0x20019
	TIMER_POLL               = 2
)

const (
	ID_TOPDF = 1001 + iota
	ID_TOWORD
	ID_TOHWP
	ID_ADD
	ID_CLEAR
	ID_LIST
	ID_OPEN
	ID_RUN
	ID_MINBTN
	ID_CLOSEBTN
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	comctl32 = syscall.NewLazyDLL("comctl32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")
	ntdll    = syscall.NewLazyDLL("ntdll.dll")
	comdlg32 = syscall.NewLazyDLL("comdlg32.dll")
	advapi32 = syscall.NewLazyDLL("advapi32.dll")

	procGetOpenFileNameW = comdlg32.NewProc("GetOpenFileNameW")
	procRegOpenKeyExW    = advapi32.NewProc("RegOpenKeyExW")
	procRegCloseKey      = advapi32.NewProc("RegCloseKey")

	procRegisterClassExW      = user32.NewProc("RegisterClassExW")
	procCreateWindowExW       = user32.NewProc("CreateWindowExW")
	procDefWindowProcW        = user32.NewProc("DefWindowProcW")
	procShowWindow            = user32.NewProc("ShowWindow")
	procUpdateWindow          = user32.NewProc("UpdateWindow")
	procGetMessageW           = user32.NewProc("GetMessageW")
	procIsDialogMessageW      = user32.NewProc("IsDialogMessageW")
	procTranslateMessage      = user32.NewProc("TranslateMessage")
	procDispatchMessageW      = user32.NewProc("DispatchMessageW")
	procPostQuitMessage       = user32.NewProc("PostQuitMessage")
	procDestroyWindow         = user32.NewProc("DestroyWindow")
	procSetWindowTextW        = user32.NewProc("SetWindowTextW")
	procGetWindowTextW        = user32.NewProc("GetWindowTextW")
	procGetWindowTextLengthW  = user32.NewProc("GetWindowTextLengthW")
	procEnableWindow          = user32.NewProc("EnableWindow")
	procIsWindowEnabled       = user32.NewProc("IsWindowEnabled")
	procSendMessageW          = user32.NewProc("SendMessageW")
	procSetTimer              = user32.NewProc("SetTimer")
	procKillTimer             = user32.NewProc("KillTimer")
	procMessageBoxW           = user32.NewProc("MessageBoxW")
	procLoadCursorW           = user32.NewProc("LoadCursorW")
	procSetCursor             = user32.NewProc("SetCursor")
	procLoadIconW             = user32.NewProc("LoadIconW")
	procSetProcessDPIAware    = user32.NewProc("SetProcessDPIAware")
	procInvalidateRect        = user32.NewProc("InvalidateRect")
	procGetClientRect         = user32.NewProc("GetClientRect")
	procBeginPaint            = user32.NewProc("BeginPaint")
	procEndPaint              = user32.NewProc("EndPaint")
	procFillRect              = user32.NewProc("FillRect")
	procDrawTextW             = user32.NewProc("DrawTextW")
	procSetWindowLongPtrW     = user32.NewProc("SetWindowLongPtrW")
	procCallWindowProcW       = user32.NewProc("CallWindowProcW")
	procTrackMouseEvent       = user32.NewProc("TrackMouseEvent")
	procSetWindowRgn          = user32.NewProc("SetWindowRgn")
	procMoveWindow            = user32.NewProc("MoveWindow")
	procScreenToClient        = user32.NewProc("ScreenToClient")
	procGetDC                 = user32.NewProc("GetDC")
	procReleaseDC             = user32.NewProc("ReleaseDC")
	procSystemParametersInfoW = user32.NewProc("SystemParametersInfoW")
	procSetCapture            = user32.NewProc("SetCapture")
	procReleaseCapture        = user32.NewProc("ReleaseCapture")

	procGetModuleHandleW   = kernel32.NewProc("GetModuleHandleW")
	procGetFileAttributesW = kernel32.NewProc("GetFileAttributesW")

	procSHBrowseForFolderW   = shell32.NewProc("SHBrowseForFolderW")
	procSHGetPathFromIDListW = shell32.NewProc("SHGetPathFromIDListW")
	procShellExecuteW        = shell32.NewProc("ShellExecuteW")
	procDragAcceptFiles      = shell32.NewProc("DragAcceptFiles")
	procDragQueryFileW       = shell32.NewProc("DragQueryFileW")
	procDragFinish           = shell32.NewProc("DragFinish")

	procCoInitializeEx = ole32.NewProc("CoInitializeEx")
	procCoUninitialize = ole32.NewProc("CoUninitialize")
	procCoTaskMemFree  = ole32.NewProc("CoTaskMemFree")

	procInitCommonControlsEx = comctl32.NewProc("InitCommonControlsEx")

	procCreateFontW            = gdi32.NewProc("CreateFontW")
	procAddFontMemResourceEx   = gdi32.NewProc("AddFontMemResourceEx")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procSetBkColor             = gdi32.NewProc("SetBkColor")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procRoundRect              = gdi32.NewProc("RoundRect")
	procCreatePen              = gdi32.NewProc("CreatePen")
	procCreateRoundRectRgn     = gdi32.NewProc("CreateRoundRectRgn")
	procGetStockObject         = gdi32.NewProc("GetStockObject")
	procGetDeviceCaps          = gdi32.NewProc("GetDeviceCaps")
	procMoveToEx               = gdi32.NewProc("MoveToEx")
	procLineTo                 = gdi32.NewProc("LineTo")

	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
	procRtlGetVersion         = ntdll.NewProc("RtlGetVersion")
)

type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}
type MSG struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      POINT
}
type INITCOMMONCONTROLSEX struct{ DwSize, DwICC uint32 }
type BROWSEINFO struct {
	HwndOwner      uintptr
	PidlRoot       uintptr
	PszDisplayName *uint16
	LpszTitle      *uint16
	UlFlags        uint32
	Lpfn           uintptr
	LParam         uintptr
	IImage         int32
}
type OPENFILENAME struct {
	LStructSize       uint32
	HwndOwner         uintptr
	HInstance         uintptr
	LpstrFilter       *uint16
	LpstrCustomFilter *uint16
	NMaxCustFilter    uint32
	NFilterIndex      uint32
	LpstrFile         *uint16
	NMaxFile          uint32
	LpstrFileTitle    *uint16
	NMaxFileTitle     uint32
	LpstrInitialDir   *uint16
	LpstrTitle        *uint16
	Flags             uint32
	NFileOffset       uint16
	NFileExtension    uint16
	LpstrDefExt       *uint16
	LCustData         uintptr
	LpfnHook          uintptr
	LpTemplateName    *uint16
	PvReserved        uintptr
	DwReserved        uint32
	FlagsEx           uint32
}
type RECT struct{ Left, Top, Right, Bottom int32 }
type POINT struct{ X, Y int32 }
type PAINTSTRUCT struct {
	Hdc         uintptr
	FErase      int32
	RcPaint     RECT
	FRestore    int32
	FIncUpdate  int32
	RgbReserved [32]byte
}
type DRAWITEMSTRUCT struct {
	CtlType, CtlID, ItemID, ItemAction, ItemState uint32
	HwndItem, Hdc                                 uintptr
	RcItem                                        RECT
	ItemData                                      uintptr
}
type TRACKMOUSEEVENT struct {
	CbSize, DwFlags uint32
	HwndTrack       uintptr
	DwHoverTime     uint32
}
type OSVERSIONINFOW struct {
	Size, Major, Minor, Build, Platform uint32
	CSD                                 [128]uint16
}

// ============================================================
// 색상 (WORKKIT 다크)
// ============================================================

func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

var (
	clrBg       = rgb(19, 19, 19)
	clrTitleBar = rgb(24, 24, 24)
	clrPanel    = rgb(28, 28, 28)
	clrRowAlt   = rgb(33, 33, 33)
	clrInput    = rgb(15, 15, 15)
	clrLine     = rgb(46, 47, 47)
	clrLine2    = rgb(69, 71, 70)
	clrText     = rgb(242, 243, 242)
	clrSub      = rgb(169, 174, 171)
	clrMuted    = rgb(110, 114, 112)
	clrAccent   = rgb(9, 235, 193)
	clrAccentHi = rgb(70, 245, 212)
	clrAccentDm = rgb(6, 160, 132)
	clrAccentBg = rgb(30, 52, 47)
	clrOnAccent = rgb(6, 34, 28)
	clrDanger   = rgb(255, 122, 110)
	clrHover    = rgb(38, 38, 38)
	clrWarn     = rgb(255, 192, 97)
)

// ============================================================
// 상태

// ============================================================
// 상태
// ============================================================

type controls struct {
	main, toPdf, toWord, toHwp, add, clear, list, open, run, minBtn, closeBtn uintptr
	font, fontSemi, fontSmall, fontTiny, fontTitle                            uintptr
}

var ui controls
var items []*Item
var curMode = ModeToPDF
var running *runner
var runTotal, doneCount, okCount, failCount int
var lastOutput string
var notice string
var noticeErr bool
var hoverState = map[uintptr]bool{}
var origProc = map[uintptr]uintptr{}
var buttonKind = map[uintptr]int{}
var buttonLabel = map[uintptr]string{}
var cursorHand, cursorArrow uintptr
var fontFace, fontFaceSemi = "Malgun Gothic", "Malgun Gothic"
var isWin11 bool

const (
	kindPrimary = iota
	kindNeutral
	kindChip
	kindTitle
)

// ============================================================
// DPI / 유틸
// ============================================================

var dpiScale = 1.0

func S(v float64) int32 { return int32(math.Round(v * dpiScale)) }

func initDPI() {
	hdc, _, _ := procGetDC.Call(0)
	dpi, _, _ := procGetDeviceCaps.Call(hdc, LOGPIXELSY)
	procReleaseDC.Call(0, hdc)
	if dpi > 0 {
		dpiScale = float64(dpi) / 96
	}
}

func utf16Ptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func loword(v uintptr) uint16   { return uint16(v & 0xffff) }
func hiword(v uintptr) uint16   { return uint16((v >> 16) & 0xffff) }
func setText(h uintptr, s string) {
	procSetWindowTextW.Call(h, uintptr(unsafe.Pointer(utf16Ptr(s))))
}
func getText(h uintptr) string {
	n, _, _ := procGetWindowTextLengthW.Call(h)
	buf := make([]uint16, n+1)
	procGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}
func send(h uintptr, msg uint32, w, l uintptr) uintptr {
	r, _, _ := procSendMessageW.Call(h, uintptr(msg), w, l)
	return r
}
func messageBox(text string, flags uint32) int {
	r, _, _ := procMessageBoxW.Call(ui.main, uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(unsafe.Pointer(utf16Ptr(appTitle))), uintptr(flags))
	return int(r)
}
func createControl(class, text string, style uint32, r RECT, parent uintptr, id int) uintptr {
	h, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16Ptr(class))), uintptr(unsafe.Pointer(utf16Ptr(text))),
		uintptr(style), uintptr(r.Left), uintptr(r.Top), uintptr(r.Right-r.Left), uintptr(r.Bottom-r.Top), parent, uintptr(id), 0, 0)
	if h != 0 && ui.font != 0 {
		send(h, WM_SETFONT, ui.font, 1)
	}
	return h
}
func enable(h uintptr, yes bool) {
	v := uintptr(0)
	if yes {
		v = 1
	}
	procEnableWindow.Call(h, v)
	invalidate(h)
}
func isEnabled(h uintptr) bool { r, _, _ := procIsWindowEnabled.Call(h); return r != 0 }
func invalidate(h uintptr)     { procInvalidateRect.Call(h, 0, 0) }

// ============================================================
// GDI
// ============================================================

func createPen(w int32, c uintptr) uintptr {
	h, _, _ := procCreatePen.Call(PS_SOLID, uintptr(w), c)
	return h
}
func createBrush(c uintptr) uintptr   { h, _, _ := procCreateSolidBrush.Call(c); return h }
func selectObj(dc, o uintptr) uintptr { r, _, _ := procSelectObject.Call(dc, o); return r }
func deleteObj(o uintptr) {
	if o != 0 {
		procDeleteObject.Call(o)
	}
}
func fillRect(dc uintptr, l, t, r, b int32, c uintptr) {
	br := createBrush(c)
	rc := RECT{l, t, r, b}
	procFillRect.Call(dc, uintptr(unsafe.Pointer(&rc)), br)
	deleteObj(br)
}
func roundBox(dc uintptr, l, t, r, b, rad int32, fill, stroke uintptr) {
	br, pen := createBrush(fill), createPen(1, stroke)
	ob, op := selectObj(dc, br), selectObj(dc, pen)
	procRoundRect.Call(dc, uintptr(l), uintptr(t), uintptr(r), uintptr(b), uintptr(rad), uintptr(rad))
	selectObj(dc, ob)
	selectObj(dc, op)
	deleteObj(br)
	deleteObj(pen)
}
func strokeBox(dc uintptr, l, t, r, b, rad int32, stroke uintptr) {
	pen := createPen(1, stroke)
	nb, _, _ := procGetStockObject.Call(NULL_BRUSH)
	ob, op := selectObj(dc, nb), selectObj(dc, pen)
	procRoundRect.Call(dc, uintptr(l), uintptr(t), uintptr(r), uintptr(b), uintptr(rad), uintptr(rad))
	selectObj(dc, ob)
	selectObj(dc, op)
	deleteObj(pen)
}
func drawText(dc uintptr, s string, x, y, w, h int32, c, font uintptr, f uint32) {
	selectObj(dc, font)
	procSetBkMode.Call(dc, TRANSPARENT_BK)
	procSetTextColor.Call(dc, c)
	rc := RECT{x, y, x + w, y + h}
	procDrawTextW.Call(dc, uintptr(unsafe.Pointer(utf16Ptr(s))), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), uintptr(f|DT_NOPREFIX))
}
func drawLine(dc uintptr, x1, y1, x2, y2, w int32, c uintptr) {
	pen := createPen(w, c)
	op := selectObj(dc, pen)
	procMoveToEx.Call(dc, uintptr(x1), uintptr(y1), 0)
	procLineTo.Call(dc, uintptr(x2), uintptr(y2))
	selectObj(dc, op)
	deleteObj(pen)
}
func withBuffer(dc uintptr, w, h int32, draw func(m uintptr)) {
	m, _, _ := procCreateCompatibleDC.Call(dc)
	bmp, _, _ := procCreateCompatibleBitmap.Call(dc, uintptr(w), uintptr(h))
	old := selectObj(m, bmp)
	draw(m)
	procBitBlt.Call(dc, 0, 0, uintptr(w), uintptr(h), m, 0, 0, 0x00CC0020)
	selectObj(m, old)
	procDeleteDC.Call(m)
	deleteObj(bmp)
}

func loadEmbeddedFonts() {
	ok := true
	for _, d := range [][]byte{fontRegular, fontSemiBold, fontBold} {
		var n uint32
		if h, _, _ := procAddFontMemResourceEx.Call(uintptr(unsafe.Pointer(&d[0])), uintptr(len(d)), 0, uintptr(unsafe.Pointer(&n))); h == 0 {
			ok = false
		}
	}
	if ok {
		fontFace, fontFaceSemi = "Pretendard", "Pretendard SemiBold"
	}
}
func makeFont(px float64, weight uint32, face string) uintptr {
	h, _, _ := procCreateFontW.Call(uintptr(-S(px)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(utf16Ptr(face))))
	return h
}

// ============================================================
// 레이아웃
// ============================================================

type layout struct {
	w, h, title, pad  int32
	lblMode, rowChips RECT
	lblFiles, list    RECT
	rowBtn, footer    RECT
}

var L layout

func computeLayout() {
	W, pad := 780.0, 28.0
	cw := W - pad*2
	r := func(x, y, w, h float64) RECT { return RECT{S(x), S(y), S(x + w), S(y + h)} }
	y := 56.0 + 22
	L.w, L.title, L.pad = S(W), S(56), S(pad)
	L.lblMode = r(pad, y, cw, 20)
	y += 28
	L.rowChips = r(pad, y, cw, 36)
	y += 36 + 22
	L.lblFiles = r(pad, y, cw, 32)
	y += 32 + 10
	L.list = r(pad, y, cw, 300)
	y += 300 + 16
	L.rowBtn = r(pad, y, cw, 44)
	y += 44 + 16
	L.footer = r(pad, y, cw, 18)
	y += 18 + 18
	L.h = S(y)
}

// ============================================================
// 목록·작업
// ============================================================

func eligibleIdx() []int {
	var r []int
	for i, it := range items {
		if eligible(curMode, it.Path) {
			r = append(r, i)
		}
	}
	return r
}

func refresh() {
	n := len(eligibleIdx())
	if running != nil {
		buttonLabel[ui.run] = fmt.Sprintf("중지  ·  %d / %d", doneCount, runTotal)
		enable(ui.run, true)
	} else {
		label := "변환 시작"
		if n > 0 {
			label = fmt.Sprintf("변환 시작 · %d개", n)
		}
		buttonLabel[ui.run] = label
		enable(ui.run, n > 0)
	}
	idle := running == nil
	enable(ui.add, idle)
	enable(ui.clear, idle && len(items) > 0)
	enable(ui.toPdf, idle)
	enable(ui.toWord, idle)
	enable(ui.toHwp, idle)
	enable(ui.open, lastOutput != "" || len(items) > 0)
	invalidate(ui.run)
	invalidate(ui.list)
	invalidate(ui.main)
}

func addFiles(paths []string) {
	if running != nil {
		return
	}
	var added, skipped int
	items, added, skipped = addPaths(items, paths)
	notice, noticeErr = "", false
	if skipped > 0 {
		notice, noticeErr = fmt.Sprintf("PDF·한글·워드가 아닌 파일 %d개는 뺐습니다.", skipped), true
	} else if added == 0 && len(paths) > 0 {
		notice = "이미 목록에 있는 파일입니다."
	}
	// 새 파일 기준으로 방식을 자동 선택 (목록이 이 파일들뿐일 때)
	if added > 0 && len(items) == added {
		pdfs := 0
		for _, it := range items {
			if strings.EqualFold(filepath.Ext(it.Path), ".pdf") {
				pdfs++
			}
		}
		if pdfs == len(items) && curMode == ModeToPDF {
			curMode = ModeToWord
		} else if pdfs == 0 {
			curMode = ModeToPDF
		}
	}
	refresh()
}

func chooseFiles() {
	buf := make([]uint16, 65536)
	filter := utf16z("변환할 수 있는 파일 (PDF·한글·워드)\x00*.pdf;*.hwp;*.hwpx;*.doc;*.docx;*.rtf;*.odt\x00PDF\x00*.pdf\x00한글·워드\x00*.hwp;*.hwpx;*.doc;*.docx;*.rtf;*.odt\x00모든 파일\x00*.*\x00\x00")
	ofn := OPENFILENAME{
		HwndOwner:   ui.main,
		LpstrFilter: &filter[0],
		LpstrFile:   &buf[0],
		NMaxFile:    uint32(len(buf)),
		LpstrTitle:  utf16Ptr("변환할 파일 선택 (여러 개 가능)"),
		Flags:       OFN_ALLOWMULTISELECT | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY,
	}
	ofn.LStructSize = uint32(unsafe.Sizeof(ofn))
	if r, _, _ := procGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&ofn))); r == 0 {
		return
	}
	addFiles(splitMulti(buf))
}

// "폴더\0파일1\0파일2\0\0" 또는 "전체경로\0\0"
func splitMulti(buf []uint16) []string {
	var parts []string
	start := 0
	for i := 0; i < len(buf); i++ {
		if buf[i] == 0 {
			if i == start {
				break
			}
			parts = append(parts, syscall.UTF16ToString(buf[start:i]))
			start = i + 1
		}
	}
	if len(parts) <= 1 {
		return parts
	}
	var out []string
	for _, n := range parts[1:] {
		out = append(out, filepath.Join(parts[0], n))
	}
	return out
}

func utf16z(s string) []uint16 {
	r, _ := syscall.UTF16FromString(strings.ReplaceAll(s, "\x00", "￿"))
	for i, c := range r {
		if c == 0xFFFF {
			r[i] = 0
		}
	}
	return r
}

func hasProgID(name string) bool {
	var key uintptr
	r, _, _ := procRegOpenKeyExW.Call(HKEY_CLASSES_ROOT, uintptr(unsafe.Pointer(utf16Ptr(name+`\CLSID`))), 0, KEY_READ, uintptr(unsafe.Pointer(&key)))
	if r != 0 {
		return false
	}
	procRegCloseKey.Call(key)
	return true
}

func startRun() {
	idx := eligibleIdx()
	if len(idx) == 0 {
		return
	}
	haveWord, haveHwp := hasProgID("Word.Application"), hasProgID("HWPFrame.HwpObject")
	var ok []int
	for _, i := range idx {
		p := items[i].Path
		if (needsWord(curMode, p) && !haveWord) || (needsHwp(curMode, p) && !haveHwp) {
			continue
		}
		ok = append(ok, i)
	}
	if len(ok) < len(idx) {
		var miss []string
		for _, i := range idx {
			p := items[i].Path
			if needsWord(curMode, p) && !haveWord && !contains(miss, "Microsoft Word") {
				miss = append(miss, "Microsoft Word")
			}
			if needsHwp(curMode, p) && !haveHwp && !contains(miss, "한글(한컴오피스)") {
				miss = append(miss, "한글(한컴오피스)")
			}
		}
		need := strings.Join(miss, ", ")
		if len(ok) == 0 {
			messageBox("이 PC에서 "+need+"을(를) 찾지 못했습니다.\n\n이 변환에는 "+need+"이(가) 설치되어 있어야 합니다.", MB_OK|MB_ICONERROR)
			return
		}
		if messageBox(fmt.Sprintf("이 PC에서 %s을(를) 찾지 못했습니다.\n\n변환할 수 있는 %d개 파일만 진행할까요?", need, len(ok)), MB_YESNO|MB_ICONQUESTION) != IDYES {
			return
		}
	}
	paths := make([]string, len(ok))
	for k, i := range ok {
		items[i].Status, items[i].Result = StWait, ""
		paths[k] = items[i].Path
	}
	running = &runner{events: make(chan event, 256)}
	runTotal, doneCount, okCount, failCount = len(ok), 0, 0, 0
	notice, noticeErr = "", false
	go running.run(curMode, ok, paths)
	procSetTimer.Call(ui.main, TIMER_POLL, 100, 0)
	refresh()
}

func contains(a []string, s string) bool {
	for _, x := range a {
		if x == s {
			return true
		}
	}
	return false
}

func pollRunner() {
	if running == nil {
		return
	}
	changed := false
	for {
		select {
		case ev := <-running.events:
			changed = true
			if ev.Kind == 'F' {
				finishRun()
				return
			}
			if ev.I < 0 || ev.I >= len(items) {
				continue
			}
			it := items[ev.I]
			switch ev.Kind {
			case 'S':
				it.Status = StRun
				scrollTo(ev.I)
			case 'O':
				it.Status, it.Result = StOK, ev.Text
				lastOutput = ev.Text
				doneCount++
				okCount++
			case 'E':
				it.Status, it.Result = StFail, ev.Text
				doneCount++
				failCount++
			}
		default:
			if changed {
				refresh()
			}
			return
		}
	}
}

func finishRun() {
	procKillTimer.Call(ui.main, TIMER_POLL)
	cancelled := running.isCancelled()
	running = nil
	switch {
	case cancelled:
		notice, noticeErr = fmt.Sprintf("중지했습니다 · 완료 %d개", okCount), failCount > 0
	case failCount == 0:
		notice, noticeErr = fmt.Sprintf("완료! %d개 파일을 변환했습니다.", okCount), false
	default:
		notice, noticeErr = fmt.Sprintf("완료 %d개 · 실패 %d개 — 실패 사유는 목록에서 확인하세요.", okCount, failCount), true
	}
	refresh()
}

func scrollTo(i int) {
	var rc RECT
	procGetClientRect.Call(ui.list, uintptr(unsafe.Pointer(&rc)))
	_, v := listMetrics(rc.Bottom)
	y := int32(i) * rowH()
	if y < listScroll {
		listScroll = y
	} else if y+rowH() > listScroll+v {
		listScroll = y + rowH() - v
	}
	clampScroll(rc.Bottom)
}

func openPath(p string, sel bool) {
	if sel {
		procShellExecuteW.Call(ui.main, uintptr(unsafe.Pointer(utf16Ptr("open"))), uintptr(unsafe.Pointer(utf16Ptr("explorer.exe"))), uintptr(unsafe.Pointer(utf16Ptr(`/select,"`+p+`"`))), 0, SW_SHOWNORMAL)
		return
	}
	procShellExecuteW.Call(ui.main, uintptr(unsafe.Pointer(utf16Ptr("open"))), uintptr(unsafe.Pointer(utf16Ptr(p))), 0, 0, SW_SHOWNORMAL)
}

// ============================================================
// 메인 창 그리기
// ============================================================

func modeHint() string {
	switch curMode {
	case ModeToWord:
		return "Microsoft Word로 PDF를 읽어 DOCX로 저장합니다."
	case ModeToHwp:
		return "Word로 PDF를 읽은 뒤 한글로 HWP 저장 (둘 다 필요)"
	}
	return "한글 파일은 한글로, 워드 파일은 Microsoft Word로 변환합니다."
}

func paintMain(m uintptr, w, h int32) {
	fillRect(m, 0, 0, w, h, clrBg)
	fillRect(m, 0, 0, w, L.title, clrTitleBar)
	drawLine(m, 0, L.title-1, w, L.title-1, 1, clrLine)

	lx, ly, ls := L.pad, (L.title-S(28))/2, S(28)
	roundBox(m, lx, ly, lx+ls, ly+ls, S(9), clrBg, clrAccent)
	drawText(m, "PDF", lx, ly, ls, ls, clrText, ui.fontTiny, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	drawText(m, appName, lx+ls+S(12), 0, S(200), L.title, clrText, ui.fontTitle, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(m, appBrand, lx+ls+S(12)+S(130), 0, S(120), L.title, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	label := func(r RECT, s string) {
		drawText(m, s, r.Left, r.Top, r.Right-r.Left, r.Bottom-r.Top, clrSub, ui.fontSemi, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	}
	label(L.lblMode, "변환 방식")
	lm := L.lblMode
	drawText(m, modeHint(), lm.Left, lm.Top, lm.Right-lm.Left, lm.Bottom-lm.Top, clrMuted, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)
	lf := L.lblFiles
	label(lf, "파일")
	drawText(m, "창에 끌어놓아도 됩니다 · 더블클릭 열기 · 우클릭 빼기", lf.Left+S(44), lf.Top, S(360), lf.Bottom-lf.Top, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	f := L.footer
	drawText(m, "결과 파일은 원본과 같은 폴더에 저장됩니다. 같은 이름이 있으면 (2), (3)을 붙입니다.", f.Left, f.Top, S(560), f.Bottom-f.Top, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(m, appVersion+"  ·  "+buildDate, f.Right-S(200), f.Top, S(200), f.Bottom-f.Top, clrMuted, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)

	br := L.rowBtn
	sum, col := "", clrSub
	switch {
	case running != nil:
		sum, col = fmt.Sprintf("변환 중…  %d / %d", doneCount, runTotal), clrAccent
	case notice != "":
		sum, col = notice, clrAccent
		if noticeErr {
			col = clrWarn
		}
	case len(items) > 0:
		n := len(eligibleIdx())
		sum = fmt.Sprintf("파일 %d개  ·  변환 대상 %d개", len(items), n)
	}
	drawText(m, sum, br.Left, br.Top, S(370), br.Bottom-br.Top, col, ui.fontSemi, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)

	r := windowRadius()
	strokeBox(m, 0, 0, w, h, r, clrLine)
}

// ============================================================
// 파일 목록 (전용 윈도우 클래스)
// ============================================================

var listScroll int32
var listHover = -1
var listDrag bool
var dragOffset int32

const listClass = "WorkkitDocList"

func rowH() int32    { return S(36) }
func headerH() int32 { return S(38) }

func listMetrics(h int32) (content, view int32) {
	return int32(len(items)) * rowH(), h - headerH() - S(1)
}

func clampScroll(h int32) {
	c, v := listMetrics(h)
	if listScroll > c-v {
		listScroll = c - v
	}
	if listScroll < 0 {
		listScroll = 0
	}
}

func thumbRect(w, h int32) (RECT, bool) {
	c, v := listMetrics(h)
	if c <= v || v <= 0 {
		return RECT{}, false
	}
	track := v - S(8)
	th := int32(float64(track) * float64(v) / float64(c))
	if th < S(28) {
		th = S(28)
	}
	ty := headerH() + S(4) + int32(float64(track-th)*float64(listScroll)/float64(c-v))
	return RECT{w - S(9), ty, w - S(4), ty + th}, true
}

func rowAt(y int32) int {
	if y <= headerH() {
		return -1
	}
	i := int((y - headerH() + listScroll) / rowH())
	if i >= len(items) {
		return -1
	}
	return i
}

func listWndProc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	w, h := rc.Right, rc.Bottom
	switch msg {
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		var ps PAINTSTRUCT
		dc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		withBuffer(dc, w, h, func(m uintptr) { paintList(m, w, h) })
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case WM_MOUSEWHEEL:
		delta := int32(int16(hiword(wp)))
		listScroll -= delta * rowH() * 3 / 120
		clampScroll(h)
		invalidate(hwnd)
		return 0
	case WM_LBUTTONDOWN:
		y := int32(int16(hiword(lp)))
		x := int32(int16(loword(lp)))
		if t, ok := thumbRect(w, h); ok && x >= w-S(14) {
			if y >= t.Top && y <= t.Bottom {
				listDrag, dragOffset = true, y-t.Top
			} else {
				_, v := listMetrics(h)
				if y < t.Top {
					listScroll -= v
				} else {
					listScroll += v
				}
				clampScroll(h)
				invalidate(hwnd)
			}
			procSetCapture.Call(hwnd)
		}
		return 0
	case WM_LBUTTONDBLCLK:
		if i := rowAt(int32(int16(hiword(lp)))); i >= 0 {
			it := items[i]
			if it.Status == StOK && fileExists(it.Result) {
				openPath(it.Result, false)
			} else {
				openPath(it.Path, false)
			}
		}
		return 0
	case WM_RBUTTONUP:
		if i := rowAt(int32(int16(hiword(lp)))); i >= 0 && running == nil {
			items = append(items[:i], items[i+1:]...)
			listHover = -1
			clampScroll(h)
			refresh()
		}
		return 0
	case WM_LBUTTONUP:
		listDrag = false
		procReleaseCapture.Call()
		return 0
	case WM_MOUSEMOVE:
		y := int32(int16(hiword(lp)))
		if listDrag {
			c, v := listMetrics(h)
			t, _ := thumbRect(w, h)
			track := v - S(8) - (t.Bottom - t.Top)
			if track > 0 {
				listScroll = int32(float64(y-dragOffset-headerH()-S(4)) / float64(track) * float64(c-v))
				clampScroll(h)
				invalidate(hwnd)
			}
			return 0
		}
		idx := rowAt(y)
		if idx != listHover {
			listHover = idx
			invalidate(hwnd)
			tme := TRACKMOUSEEVENT{DwFlags: TME_LEAVE, HwndTrack: hwnd}
			tme.CbSize = uint32(unsafe.Sizeof(tme))
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		}
		return 0
	case WM_MOUSELEAVE:
		listHover = -1
		invalidate(hwnd)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wp, lp)
	return r
}

func paintList(m uintptr, w, h int32) {
	fillRect(m, 0, 0, w, h, clrBg)
	roundBox(m, 0, 0, w, h, S(14), clrPanel, clrLine)
	pad := S(18)
	statusW := S(84)
	nameW := (w - pad*2 - statusW - S(16)) * 45 / 100
	xName := pad
	xRes := pad + nameW + S(12)
	resW := w - pad - statusW - S(12) - xRes
	xStatus := w - pad - statusW

	hh := headerH()
	drawText(m, "파일", xName, 0, nameW, hh, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(m, "결과", xRes, 0, resW, hh, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(m, "상태", xStatus, 0, statusW, hh, clrMuted, ui.fontSmall, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	drawLine(m, S(1), hh, w-S(1), hh, 1, clrLine)

	if len(items) == 0 {
		drawText(m, "변환할 파일을 끌어놓으세요", pad, hh+S(84), w-pad*2, S(26), clrSub, ui.fontSemi, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
		drawText(m, "한글(HWP·HWPX) · 워드(DOCX·DOC·RTF) · PDF 파일, 또는 이 파일들이 든 폴더\n'파일 추가'로 골라도 됩니다.", pad*2, hh+S(116), w-pad*4, S(60), clrMuted, ui.fontSmall, DT_CENTER|DT_WORDBREAK)
		return
	}

	clampScroll(h)
	top := hh + S(1)
	first := int(listScroll / rowH())
	for i := first; i < len(items); i++ {
		y := top + int32(i)*rowH() - listScroll
		if y > h {
			break
		}
		it := items[i]
		el := eligible(curMode, it.Path)
		bg := clrPanel
		if i == listHover {
			bg = clrHover
		} else if i%2 == 1 {
			bg = clrRowAlt
		}
		fillRect(m, S(1), y, w-S(1), y+rowH(), bg)

		nameC := clrText
		if !el && it.Status != StOK && it.Status != StFail {
			nameC = clrMuted
		}
		drawText(m, it.Name, xName, y, nameW, rowH(), nameC, ui.font, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)

		res, resC := "", clrSub
		badge, bFill, bText := "대기", clrBg, clrSub
		switch it.Status {
		case StOK:
			res, resC = "→  "+filepath.Base(it.Result), clrText
			badge, bFill, bText = "완료", clrAccentBg, clrAccent
		case StFail:
			res, resC = it.Result, clrDanger
			badge, bFill, bText = "실패", rgb(58, 32, 30), clrDanger
		case StRun:
			res, resC = "변환 중…", clrAccent
			badge, bFill, bText = "변환 중", clrAccentBg, clrText
		default:
			if el {
				res = "→  " + strings.TrimSuffix(it.Name, filepath.Ext(it.Name)) + curMode.outExt()
			} else {
				res, resC = "이 방식에서는 변환하지 않음", clrMuted
				badge, bText = "제외", clrMuted
			}
		}
		drawText(m, res, xRes, y, resW, rowH(), resC, ui.font, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
		bh := S(22)
		by := y + (rowH()-bh)/2
		roundBox(m, xStatus, by, xStatus+statusW, by+bh, bh, bFill, bFill)
		drawText(m, badge, xStatus, by, statusW, bh, bText, ui.fontSmall, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	}
	fillRect(m, 0, h-S(1), w, h, clrBg)
	strokeBox(m, 0, 0, w, h, S(14), clrLine)
	if t, ok := thumbRect(w, h); ok {
		c := clrLine2
		if listDrag {
			c = clrSub
		}
		roundBox(m, t.Left, t.Top, t.Right, t.Bottom, S(5), c, c)
	}
}

// ============================================================
// 오너드로우 버튼
// ============================================================

func ownerButton(kind int, label string, r RECT, parent uintptr, id int) uintptr {
	h := createControl("BUTTON", label, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, r, parent, id)
	buttonKind[h], buttonLabel[h] = kind, label
	idx := int32(GWLP_WNDPROC)
	old, _, _ := procSetWindowLongPtrW.Call(h, uintptr(idx), syscall.NewCallback(hoverProc))
	origProc[h] = old
	return h
}

func hoverProc(h uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case WM_MOUSEMOVE:
		if !hoverState[h] {
			hoverState[h] = true
			invalidate(h)
			tme := TRACKMOUSEEVENT{DwFlags: TME_LEAVE, HwndTrack: h}
			tme.CbSize = uint32(unsafe.Sizeof(tme))
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		}
	case WM_MOUSELEAVE:
		hoverState[h] = false
		invalidate(h)
	case WM_SETCURSOR:
		if isEnabled(h) {
			procSetCursor.Call(cursorHand)
			return 1
		}
	}
	r, _, _ := procCallWindowProcW.Call(origProc[h], h, uintptr(msg), wp, lp)
	return r
}

func isSelected(h uintptr) bool {
	switch h {
	case ui.toPdf:
		return curMode == ModeToPDF
	case ui.toWord:
		return curMode == ModeToWord
	case ui.toHwp:
		return curMode == ModeToHwp
	}
	return false
}

func drawOwner(d *DRAWITEMSTRUCT) {
	h := d.HwndItem
	w, hh := d.RcItem.Right-d.RcItem.Left, d.RcItem.Bottom-d.RcItem.Top
	pressed := d.ItemState&ODS_SELECTED != 0
	disabled := d.ItemState&ODS_DISABLED != 0
	hovered := hoverState[h] && !disabled
	focus := d.ItemState&ODS_FOCUS != 0 && d.ItemState&ODS_NOFOCUSRECT == 0 && !disabled
	label := buttonLabel[h]
	center := uint32(DT_CENTER | DT_VCENTER | DT_SINGLELINE)
	withBuffer(d.Hdc, w, hh, func(m uintptr) {
		bg := clrBg
		if buttonKind[h] == kindTitle {
			bg = clrTitleBar
		}
		fillRect(m, 0, 0, w, hh, bg)
		rad := S(10)
		switch buttonKind[h] {
		case kindPrimary:
			fill, txt := clrAccent, clrOnAccent
			switch {
			case disabled:
				fill, txt = rgb(40, 60, 56), rgb(110, 140, 132)
			case running != nil && h == ui.run:
				fill, txt = clrPanel, clrText
				if hovered {
					fill = rgb(58, 32, 30)
				}
				roundBox(m, 0, 0, w, hh, rad, fill, clrDanger)
				drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
				return
			case pressed:
				fill = clrAccentDm
			case hovered:
				fill = clrAccentHi
			}
			roundBox(m, 0, 0, w, hh, rad, fill, fill)
			drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
		case kindNeutral:
			fill, stroke, txt := clrPanel, clrLine2, clrText
			if disabled {
				fill, stroke, txt = clrBg, clrLine, clrMuted
			} else if pressed {
				fill, stroke = clrAccentBg, clrAccent
			} else if hovered {
				fill, stroke = clrHover, rgb(96, 99, 97)
			}
			roundBox(m, 0, 0, w, hh, rad, fill, stroke)
			drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
		case kindChip:
			sel := isSelected(h)
			fill, stroke, txt, font := clrPanel, clrLine2, clrSub, ui.font
			if sel {
				fill, stroke, txt, font = clrAccentBg, clrAccent, clrText, ui.fontSemi
			} else if hovered {
				fill, txt = clrHover, clrText
			}
			if disabled && !sel {
				txt = clrMuted
			}
			roundBox(m, 0, 0, w, hh, S(8), fill, stroke)
			drawText(m, label, 0, 0, w, hh, txt, font, center)
		case kindTitle:
			if hovered {
				c := clrHover
				if h == ui.closeBtn {
					c = rgb(229, 72, 77)
				}
				roundBox(m, S(2), S(2), w-S(2), hh-S(2), S(8), c, c)
			}
			cx, cy, a := w/2, hh/2, S(5)
			if h == ui.closeBtn {
				drawLine(m, cx-a, cy-a, cx+a+1, cy+a+1, S(1)+1, clrText)
				drawLine(m, cx-a, cy+a, cx+a+1, cy-a-1, S(1)+1, clrText)
			} else {
				drawLine(m, cx-a, cy, cx+a+1, cy, S(1)+1, clrText)
			}
		}
		if focus && buttonKind[h] != kindTitle {
			strokeBox(m, 0, 0, w, hh, rad, rgb(255, 255, 255))
		}
	})
}

// ============================================================
// 창 만들기
// ============================================================

func windowRadius() int32 {
	if isWin11 {
		return 0
	}
	return S(14)
}

func createUI(hwnd uintptr) {
	ui.font = makeFont(14, 400, fontFace)
	ui.fontSemi = makeFont(14, 600, fontFaceSemi)
	ui.fontSmall = makeFont(12.5, 400, fontFace)
	ui.fontTiny = makeFont(10, 700, fontFace)
	ui.fontTitle = makeFont(16, 700, fontFace)

	bs := S(36)
	by := (L.title - bs) / 2
	ui.closeBtn = ownerButton(kindTitle, "", RECT{L.w - S(12) - bs, by, L.w - S(12), by + bs}, hwnd, ID_CLOSEBTN)
	ui.minBtn = ownerButton(kindTitle, "", RECT{L.w - S(16) - bs*2, by, L.w - S(16) - bs, by + bs}, hwnd, ID_MINBTN)

	cr := L.rowChips
	x := cr.Left
	ui.toPdf = ownerButton(kindChip, "한글·워드  →  PDF", RECT{x, cr.Top, x + S(176), cr.Bottom}, hwnd, ID_TOPDF)
	x += S(184)
	ui.toWord = ownerButton(kindChip, "PDF  →  워드", RECT{x, cr.Top, x + S(140), cr.Bottom}, hwnd, ID_TOWORD)
	x += S(148)
	ui.toHwp = ownerButton(kindChip, "PDF  →  한글", RECT{x, cr.Top, x + S(140), cr.Bottom}, hwnd, ID_TOHWP)

	lf := L.lblFiles
	ui.clear = ownerButton(kindNeutral, "목록 비우기", RECT{lf.Right - S(110), lf.Top, lf.Right, lf.Bottom}, hwnd, ID_CLEAR)
	ui.add = ownerButton(kindNeutral, "파일 추가", RECT{lf.Right - S(110) - S(8) - S(100), lf.Top, lf.Right - S(118), lf.Bottom}, hwnd, ID_ADD)

	lr := L.list
	ui.list, _, _ = procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16Ptr(listClass))), 0, WS_CHILD|WS_VISIBLE,
		uintptr(lr.Left), uintptr(lr.Top), uintptr(lr.Right-lr.Left), uintptr(lr.Bottom-lr.Top), hwnd, ID_LIST, 0, 0)

	br := L.rowBtn
	ui.run = ownerButton(kindPrimary, "변환 시작", RECT{br.Right - S(210), br.Top, br.Right, br.Bottom}, hwnd, ID_RUN)
	ui.open = ownerButton(kindNeutral, "결과 폴더 열기", RECT{br.Right - S(210) - S(8) - S(136), br.Top, br.Right - S(218), br.Bottom}, hwnd, ID_OPEN)

	procDragAcceptFiles.Call(hwnd, 1)
	refresh()
}

func applyWindowShape(hwnd uintptr) {
	if isWin11 {
		pref := int32(2)
		procDwmSetWindowAttribute.Call(hwnd, 33, uintptr(unsafe.Pointer(&pref)), 4)
		return
	}
	rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(L.w+1), uintptr(L.h+1), uintptr(S(14)), uintptr(S(14)))
	procSetWindowRgn.Call(hwnd, rgn, 1)
}

func setMode(m Mode) {
	if running != nil || m == curMode {
		return
	}
	curMode = m
	notice = ""
	for _, it := range items { // 방식이 바뀌면 지난 결과 표시는 지움
		if it.Status != StRun {
			it.Status, it.Result = StWait, ""
		}
	}
	invalidate(ui.toPdf)
	invalidate(ui.toWord)
	invalidate(ui.toHwp)
	refresh()
}

func confirmClose(hwnd uintptr) {
	if running != nil {
		if messageBox("변환 중입니다. 중지하고 닫을까요?", MB_YESNO|MB_ICONQUESTION) != IDYES {
			return
		}
		running.cancel()
	}
	procDestroyWindow.Call(hwnd)
}

func wndProc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		ui.main = hwnd
		createUI(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		var ps PAINTSTRUCT
		dc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		withBuffer(dc, rc.Right, rc.Bottom, func(m uintptr) { paintMain(m, rc.Right, rc.Bottom) })
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case WM_NCHITTEST:
		pt := POINT{int32(int16(loword(lp))), int32(int16(hiword(lp)))}
		procScreenToClient.Call(hwnd, uintptr(unsafe.Pointer(&pt)))
		if pt.Y >= 0 && pt.Y < L.title && pt.X < L.w-S(100) {
			return HTCAPTION
		}
	case WM_DRAWITEM:
		drawOwner((*DRAWITEMSTRUCT)(unsafe.Pointer(lp)))
		return 1
	case WM_DROPFILES:
		n, _, _ := procDragQueryFileW.Call(wp, 0xFFFFFFFF, 0, 0)
		var paths []string
		buf := make([]uint16, 32768)
		for i := uintptr(0); i < n; i++ {
			procDragQueryFileW.Call(wp, i, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
			paths = append(paths, syscall.UTF16ToString(buf))
		}
		procDragFinish.Call(wp)
		addFiles(paths)
		return 0
	case WM_TIMER:
		if wp == TIMER_POLL {
			pollRunner()
		}
		return 0
	case WM_CLOSE:
		confirmClose(hwnd)
		return 0
	case WM_COMMAND:
		id, code := int(loword(wp)), int(hiword(wp))
		if code != BN_CLICKED {
			return 0
		}
		switch id {
		case ID_TOPDF:
			setMode(ModeToPDF)
		case ID_TOWORD:
			setMode(ModeToWord)
		case ID_TOHWP:
			setMode(ModeToHwp)
		case ID_ADD:
			chooseFiles()
		case ID_CLEAR:
			if running == nil {
				items, notice, listScroll = nil, "", 0
				refresh()
			}
		case ID_OPEN:
			if lastOutput != "" && fileExists(lastOutput) {
				openPath(lastOutput, true)
			} else if len(items) > 0 {
				openPath(filepath.Dir(items[0].Path), false)
			}
		case ID_RUN:
			if running != nil {
				if messageBox("변환을 중지할까요? 지금 변환 중인 파일까지는 취소됩니다.", MB_YESNO|MB_ICONQUESTION) == IDYES && running != nil {
					running.cancel()
				}
			} else {
				startRun()
			}
		case ID_MINBTN:
			procShowWindow.Call(hwnd, SW_MINIMIZE)
		case ID_CLOSEBTN:
			confirmClose(hwnd)
		}
		return 0
	case WM_DESTROY:
		if running != nil {
			running.cancel()
		}
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wp, lp)
	return r
}

func main() {
	runtime.LockOSThread()
	procSetProcessDPIAware.Call()
	initDPI()
	procCoInitializeEx.Call(0, COINIT_APARTMENTTHREADED)
	defer procCoUninitialize.Call()
	icc := INITCOMMONCONTROLSEX{DwSize: 8, DwICC: 0x000040FF}
	procInitCommonControlsEx.Call(uintptr(unsafe.Pointer(&icc)))

	var vi OSVERSIONINFOW
	vi.Size = uint32(unsafe.Sizeof(vi))
	procRtlGetVersion.Call(uintptr(unsafe.Pointer(&vi)))
	isWin11 = vi.Major >= 10 && vi.Build >= 22000

	loadEmbeddedFonts()
	hInst, _, _ := procGetModuleHandleW.Call(0)
	cursorArrow, _, _ = procLoadCursorW.Call(0, IDC_ARROW)
	cursorHand, _, _ = procLoadCursorW.Call(0, IDC_HAND)
	icon, _, _ := procLoadIconW.Call(hInst, 1)

	lc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), Style: CS_DBLCLKS, LpfnWndProc: syscall.NewCallback(listWndProc), HInstance: hInst, HCursor: cursorArrow, LpszClassName: utf16Ptr(listClass)}
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&lc)))
	cls := utf16Ptr("WorkkitDocPdfConverter")
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(wndProc), HInstance: hInst, HIcon: icon, HIconSm: icon, HCursor: cursorArrow, LpszClassName: cls}
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	computeLayout()
	hwnd, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(utf16Ptr(appTitle))),
		WS_POPUP|WS_CLIPCHILDREN|WS_SYSMENU|WS_MINIMIZEBOX, 0, 0, uintptr(L.w), uintptr(L.h), 0, 0, hInst, 0)
	applyWindowShape(hwnd)
	var wa RECT
	procSystemParametersInfoW.Call(SPI_GETWORKAREA, 0, uintptr(unsafe.Pointer(&wa)), 0)
	y := wa.Top + (wa.Bottom-wa.Top-L.h)/2
	if y < wa.Top {
		y = wa.Top
	}
	procMoveWindow.Call(hwnd, uintptr(wa.Left+(wa.Right-wa.Left-L.w)/2), uintptr(y), uintptr(L.w), uintptr(L.h), 1)
	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)

	// 파일을 exe 아이콘에 끌어놓아 실행한 경우
	if len(os.Args) > 1 {
		addFiles(os.Args[1:])
	}

	var msg MSG
	for {
		r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if r, _, _ := procIsDialogMessageW.Call(hwnd, uintptr(unsafe.Pointer(&msg))); r != 0 {
			continue
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}
}
