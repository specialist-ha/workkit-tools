package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestParseLine(t *testing.T) {
	cases := []struct {
		in   string
		ok   bool
		want event
	}{
		{"S 0", true, event{Kind: 'S', I: 0}},
		{"\ufeffS 3\r\n", true, event{Kind: 'S', I: 3}},
		{"O 2\tC:\\문서\\보고서.pdf", true, event{Kind: 'O', I: 2, Text: "C:\\문서\\보고서.pdf"}},
		{"E 1\tNOHWP\t", true, event{Kind: 'E', I: 1, Code: "NOHWP"}},
		{"E 4\tOTHER\t명령 실패", true, event{Kind: 'E', I: 4, Code: "OTHER", Text: "명령 실패"}},
		{"O 2\t", false, event{}},
		{"hello", false, event{}},
		{"X 1", false, event{}},
		{"S -1", false, event{}},
	}
	for _, c := range cases {
		got, ok := parseLine(c.in)
		if ok != c.ok || (ok && got != c.want) {
			t.Errorf("parseLine(%q) = %+v,%v want %+v,%v", c.in, got, ok, c.want, c.ok)
		}
	}
}

func TestEligible(t *testing.T) {
	if !eligible(ModeToPDF, "a.HWP") || !eligible(ModeToPDF, "b.docx") || eligible(ModeToPDF, "c.pdf") {
		t.Fatal("topdf")
	}
	if !eligible(ModeToWord, "x.PDF") || eligible(ModeToHwp, "x.hwp") {
		t.Fatal("from pdf")
	}
	if !needsHwp(ModeToPDF, "a.hwpx") || needsWord(ModeToPDF, "a.hwpx") || !needsWord(ModeToHwp, "a.pdf") || !needsHwp(ModeToHwp, "a.pdf") {
		t.Fatal("needs")
	}
}

func TestAddPaths(t *testing.T) {
	d := t.TempDir()
	for _, n := range []string{"10.pdf", "2.hwp", "note.txt", "~$temp.docx", "1.docx"} {
		os.WriteFile(filepath.Join(d, n), []byte("x"), 0o644)
	}
	items, added, skipped := addPaths(nil, []string{d, filepath.Join(d, "note.txt")})
	if added != 3 || skipped != 1 {
		t.Fatalf("added %d skipped %d", added, skipped)
	}
	want := []string{"1.docx", "2.hwp", "10.pdf"}
	for i, w := range want {
		if items[i].Name != w {
			t.Fatalf("order %d: %s", i, items[i].Name)
		}
	}
	items, added, _ = addPaths(items, []string{filepath.Join(d, "2.hwp")})
	if added != 0 || len(items) != 3 {
		t.Fatal("dup")
	}
}

func TestErrorMessage(t *testing.T) {
	if errorMessage("OTHER", "") == "" || errorMessage("OTHER", "x") != "변환 실패: x" || errorMessage("NOWORD", "") != errText["NOWORD"] {
		t.Fatal("msg")
	}
}
