﻿WORKKIT YouTube 다운로더 v3.4 (2026-10-26)

[사용 방법]
1. WORKKIT_YouTube_Downloader.exe를 실행합니다.
2. YouTube 링크를 넣습니다. 여러 개는 줄을 바꿔 입력합니다.
3. 저장 위치, 형식(영상/음원), 화질을 고릅니다.
4. '다운로드 시작'을 누릅니다.

- 처음 실행할 때 필요한 구성요소(yt-dlp, FFmpeg, Deno)를 한 번 내려받습니다.
- 편집 프로그램과 맞지 않는 영상(AV1·VP9·Opus·10비트)은 H.264/AAC MP4로 자동 변환합니다.
- 'YouTube가 요청을 막았습니다(403)' 오류가 나면 '도구 업데이트'를 누른 뒤 다시 시도하세요.
- 사내망에서 인증서 오류가 날 때만, 회사 정책상 허용되는 범위에서 '사내망 SSL 호환'을 켜세요.
- Windows 보호 창이 뜨면 '추가 정보 → 실행'을 누르세요.
- 권한이 있는 영상에만 사용하세요.

[v3.4 변경 사항]
- 진행률을 실제 받은 용량 기준으로 계산합니다. 영상·음성을 따로 받아도 0→100%가 한 번만, 소수점 한 자리까지 표시됩니다.
- 단계별(구성요소 받기 · 다운로드 · 합치기 · 편집용 변환) 진행률과 속도, 남은 시간을 표시합니다.
- 프로그램 이름을 'WORKKIT YouTube 다운로더'로 변경했습니다.
- Pretendard 글꼴을 프로그램에 내장했습니다. (별도 설치 불필요)
- WORKKIT 다크 테마로 화면을 새로 디자인했습니다. 형식·화질은 버튼으로 고르고, 작업 기록은 필요할 때만 펼칩니다.
- 고해상도(125%·150%) 화면 배율에 맞춰 선명하게 표시됩니다.
- 이전 버전에서 받아둔 구성요소는 자동으로 옮겨 다시 받지 않습니다.

[검증]
실행 파일 SHA-256: d936a112c85f597461b9946950b7d5f87372930b1ee557cfece82800f17e6f5a
빌드: GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-s -w -H windowsgui"
소스 빌드 시 source/fonts/ 에 Pretendard v1.3.9의 Regular·SemiBold·Bold OTF를 넣고, winres/app.rc를 rsrc_windows_amd64.syso로 컴파일하세요.

[글꼴]
Pretendard (SIL Open Font License 1.1) — licenses/Pretendard-OFL.txt
