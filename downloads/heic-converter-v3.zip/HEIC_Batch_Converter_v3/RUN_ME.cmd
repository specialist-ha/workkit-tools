@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
    echo Windows PowerShell was not found.
    echo Open README.txt for details.
    pause
    exit /b 1
)

"%PS%" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0HEICConverter.ps1"
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
    echo.
    echo The converter could not start.
    echo Open error.log in this folder.
    pause
)

endlocal & exit /b %EXITCODE%
