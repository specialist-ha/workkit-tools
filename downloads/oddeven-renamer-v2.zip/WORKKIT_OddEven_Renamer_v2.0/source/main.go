//go:build windows

package main

import (
	_ "embed"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

const (
	appName    = "홀짝 번호 매기기"
	appBrand   = "WORKKIT"
	appTitle   = "WORKKIT 홀짝 번호 매기기"
	appVersion = "v2.0"
	buildDate  = "2026-10-26"
)

//go:embed fonts/Pretendard-Regular.otf
var fontRegular []byte

//go:embed fonts/Pretendard-SemiBold.otf
var fontSemiBold []byte

//go:embed fonts/Pretendard-Bold.otf
var fontBold []byte

// ============================================================
// Win32
// ============================================================

const (
	WM_CREATE                = 0x0001
	WM_DESTROY               = 0x0002
	WM_PAINT                 = 0x000F
	WM_CLOSE                 = 0x0010
	WM_ERASEBKGND            = 0x0014
	WM_SETCURSOR             = 0x0020
	WM_SETFONT               = 0x0030
	WM_DRAWITEM              = 0x002B
	WM_NCHITTEST             = 0x0084
	WM_COMMAND               = 0x0111
	WM_TIMER                 = 0x0113
	WM_CTLCOLOREDIT          = 0x0133
	WM_CTLCOLORSTATIC        = 0x0138
	WM_MOUSEMOVE             = 0x0200
	WM_LBUTTONDOWN           = 0x0201
	WM_LBUTTONUP             = 0x0202
	WM_MOUSEWHEEL            = 0x020A
	WM_MOUSELEAVE            = 0x02A3
	WM_DROPFILES             = 0x0233
	WM_ACTIVATEAPP           = 0x001C
	EN_SETFOCUS              = 0x0100
	EN_KILLFOCUS             = 0x0200
	EN_CHANGE                = 0x0300
	WS_POPUP                 = 0x80000000
	WS_SYSMENU               = 0x00080000
	WS_MINIMIZEBOX           = 0x00020000
	WS_VISIBLE               = 0x10000000
	WS_CHILD                 = 0x40000000
	WS_TABSTOP               = 0x00010000
	WS_CLIPCHILDREN          = 0x02000000
	ES_LEFT                  = 0x0000
	ES_AUTOHSCROLL           = 0x0080
	BS_OWNERDRAW             = 0x0000000B
	SW_SHOW                  = 5
	SW_SHOWNORMAL            = 1
	SW_MINIMIZE              = 6
	IDC_ARROW                = 32512
	IDC_HAND                 = 32649
	MB_OK                    = 0x00000000
	MB_ICONERROR             = 0x00000010
	MB_ICONQUESTION          = 0x00000020
	MB_YESNO                 = 0x00000004
	IDYES                    = 6
	BN_CLICKED               = 0
	ODS_SELECTED             = 0x0001
	ODS_DISABLED             = 0x0004
	ODS_FOCUS                = 0x0010
	ODS_NOFOCUSRECT          = 0x0200
	TME_LEAVE                = 0x00000002
	HTCAPTION                = 2
	GWLP_WNDPROC             = -4
	SPI_GETWORKAREA          = 0x0030
	LOGPIXELSY               = 90
	DT_LEFT                  = 0x00000000
	DT_CENTER                = 0x00000001
	DT_RIGHT                 = 0x00000002
	DT_VCENTER               = 0x00000004
	DT_WORDBREAK             = 0x00000010
	DT_SINGLELINE            = 0x00000020
	DT_NOPREFIX              = 0x00000800
	DT_END_ELLIPSIS          = 0x00008000
	PS_SOLID                 = 0
	NULL_BRUSH               = 5
	TRANSPARENT_BK           = 1
	BIF_RETURNONLYFSDIRS     = 0x00000001
	BIF_NEWDIALOGSTYLE       = 0x00000040
	COINIT_APARTMENTTHREADED = 0x2
	FILE_ATTRIBUTE_HIDDEN    = 0x2
	FILE_ATTRIBUTE_SYSTEM    = 0x4
)

const (
	ID_FOLDER = 1001 + iota
	ID_BROWSE
	ID_OPEN
	ID_APPLY
	ID_REMOVE
	ID_ODD
	ID_EVEN
	ID_RUN
	ID_UNDO
	ID_LIST
	ID_MINBTN
	ID_CLOSEBTN
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	comctl32 = syscall.NewLazyDLL("comctl32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")
	ntdll    = syscall.NewLazyDLL("ntdll.dll")

	procRegisterClassExW      = user32.NewProc("RegisterClassExW")
	procCreateWindowExW       = user32.NewProc("CreateWindowExW")
	procDefWindowProcW        = user32.NewProc("DefWindowProcW")
	procShowWindow            = user32.NewProc("ShowWindow")
	procUpdateWindow          = user32.NewProc("UpdateWindow")
	procGetMessageW           = user32.NewProc("GetMessageW")
	procIsDialogMessageW      = user32.NewProc("IsDialogMessageW")
	procTranslateMessage      = user32.NewProc("TranslateMessage")
	procDispatchMessageW      = user32.NewProc("DispatchMessageW")
	procPostQuitMessage       = user32.NewProc("PostQuitMessage")
	procDestroyWindow         = user32.NewProc("DestroyWindow")
	procSetWindowTextW        = user32.NewProc("SetWindowTextW")
	procGetWindowTextW        = user32.NewProc("GetWindowTextW")
	procGetWindowTextLengthW  = user32.NewProc("GetWindowTextLengthW")
	procEnableWindow          = user32.NewProc("EnableWindow")
	procIsWindowEnabled       = user32.NewProc("IsWindowEnabled")
	procSendMessageW          = user32.NewProc("SendMessageW")
	procSetTimer              = user32.NewProc("SetTimer")
	procKillTimer             = user32.NewProc("KillTimer")
	procMessageBoxW           = user32.NewProc("MessageBoxW")
	procLoadCursorW           = user32.NewProc("LoadCursorW")
	procSetCursor             = user32.NewProc("SetCursor")
	procLoadIconW             = user32.NewProc("LoadIconW")
	procSetProcessDPIAware    = user32.NewProc("SetProcessDPIAware")
	procInvalidateRect        = user32.NewProc("InvalidateRect")
	procGetClientRect         = user32.NewProc("GetClientRect")
	procBeginPaint            = user32.NewProc("BeginPaint")
	procEndPaint              = user32.NewProc("EndPaint")
	procFillRect              = user32.NewProc("FillRect")
	procDrawTextW             = user32.NewProc("DrawTextW")
	procSetWindowLongPtrW     = user32.NewProc("SetWindowLongPtrW")
	procCallWindowProcW       = user32.NewProc("CallWindowProcW")
	procTrackMouseEvent       = user32.NewProc("TrackMouseEvent")
	procSetWindowRgn          = user32.NewProc("SetWindowRgn")
	procMoveWindow            = user32.NewProc("MoveWindow")
	procScreenToClient        = user32.NewProc("ScreenToClient")
	procGetDC                 = user32.NewProc("GetDC")
	procReleaseDC             = user32.NewProc("ReleaseDC")
	procSystemParametersInfoW = user32.NewProc("SystemParametersInfoW")
	procSetCapture            = user32.NewProc("SetCapture")
	procReleaseCapture        = user32.NewProc("ReleaseCapture")

	procGetModuleHandleW   = kernel32.NewProc("GetModuleHandleW")
	procGetFileAttributesW = kernel32.NewProc("GetFileAttributesW")

	procSHBrowseForFolderW   = shell32.NewProc("SHBrowseForFolderW")
	procSHGetPathFromIDListW = shell32.NewProc("SHGetPathFromIDListW")
	procShellExecuteW        = shell32.NewProc("ShellExecuteW")
	procDragAcceptFiles      = shell32.NewProc("DragAcceptFiles")
	procDragQueryFileW       = shell32.NewProc("DragQueryFileW")
	procDragFinish           = shell32.NewProc("DragFinish")

	procCoInitializeEx = ole32.NewProc("CoInitializeEx")
	procCoUninitialize = ole32.NewProc("CoUninitialize")
	procCoTaskMemFree  = ole32.NewProc("CoTaskMemFree")

	procInitCommonControlsEx = comctl32.NewProc("InitCommonControlsEx")

	procCreateFontW            = gdi32.NewProc("CreateFontW")
	procAddFontMemResourceEx   = gdi32.NewProc("AddFontMemResourceEx")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procSetBkColor             = gdi32.NewProc("SetBkColor")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procRoundRect              = gdi32.NewProc("RoundRect")
	procCreatePen              = gdi32.NewProc("CreatePen")
	procCreateRoundRectRgn     = gdi32.NewProc("CreateRoundRectRgn")
	procGetStockObject         = gdi32.NewProc("GetStockObject")
	procGetDeviceCaps          = gdi32.NewProc("GetDeviceCaps")
	procMoveToEx               = gdi32.NewProc("MoveToEx")
	procLineTo                 = gdi32.NewProc("LineTo")

	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
	procRtlGetVersion         = ntdll.NewProc("RtlGetVersion")
)

type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}
type MSG struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      POINT
}
type INITCOMMONCONTROLSEX struct{ DwSize, DwICC uint32 }
type BROWSEINFO struct {
	HwndOwner      uintptr
	PidlRoot       uintptr
	PszDisplayName *uint16
	LpszTitle      *uint16
	UlFlags        uint32
	Lpfn           uintptr
	LParam         uintptr
	IImage         int32
}
type RECT struct{ Left, Top, Right, Bottom int32 }
type POINT struct{ X, Y int32 }
type PAINTSTRUCT struct {
	Hdc         uintptr
	FErase      int32
	RcPaint     RECT
	FRestore    int32
	FIncUpdate  int32
	RgbReserved [32]byte
}
type DRAWITEMSTRUCT struct {
	CtlType, CtlID, ItemID, ItemAction, ItemState uint32
	HwndItem, Hdc                                 uintptr
	RcItem                                        RECT
	ItemData                                      uintptr
}
type TRACKMOUSEEVENT struct {
	CbSize, DwFlags uint32
	HwndTrack       uintptr
	DwHoverTime     uint32
}
type OSVERSIONINFOW struct {
	Size, Major, Minor, Build, Platform uint32
	CSD                                 [128]uint16
}

// ============================================================
// 색상 (WORKKIT 다크)
// ============================================================

func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

var (
	clrBg       = rgb(19, 19, 19)
	clrTitleBar = rgb(24, 24, 24)
	clrPanel    = rgb(28, 28, 28)
	clrRowAlt   = rgb(33, 33, 33)
	clrInput    = rgb(15, 15, 15)
	clrLine     = rgb(46, 47, 47)
	clrLine2    = rgb(69, 71, 70)
	clrText     = rgb(242, 243, 242)
	clrSub      = rgb(169, 174, 171)
	clrMuted    = rgb(110, 114, 112)
	clrAccent   = rgb(9, 235, 193)
	clrAccentHi = rgb(70, 245, 212)
	clrAccentDm = rgb(6, 160, 132)
	clrAccentBg = rgb(30, 52, 47)
	clrOnAccent = rgb(6, 34, 28)
	clrDanger   = rgb(255, 122, 110)
	clrHover    = rgb(38, 38, 38)
)

// ============================================================
// 상태
// ============================================================

type controls struct {
	main, folder, browse, open, apply, remove, odd, even uintptr
	run, undo, list, minBtn, closeBtn                    uintptr
	font, fontSemi, fontSmall, fontTitle, fontBig        uintptr
}

var ui controls
var brushInput uintptr
var curOp = OpApply
var curParity = Odd
var plan *Plan
var planErr string
var notice string // 작업 결과 안내 (초록)
var lastUndo [][2]string
var lastUndoFolder string
var hoverState = map[uintptr]bool{}
var origProc = map[uintptr]uintptr{}
var buttonKind = map[uintptr]int{}
var buttonLabel = map[uintptr]string{}
var focusedEdit uintptr
var cursorHand, cursorArrow uintptr
var fontFace, fontFaceSemi = "Malgun Gothic", "Malgun Gothic"
var isWin11 bool
var selfName string

const (
	kindPrimary = iota
	kindNeutral
	kindChip
	kindTitle
)

// ============================================================
// DPI / 유틸
// ============================================================

var dpiScale = 1.0

func S(v float64) int32 { return int32(math.Round(v * dpiScale)) }

func initDPI() {
	hdc, _, _ := procGetDC.Call(0)
	dpi, _, _ := procGetDeviceCaps.Call(hdc, LOGPIXELSY)
	procReleaseDC.Call(0, hdc)
	if dpi > 0 {
		dpiScale = float64(dpi) / 96
	}
}

func utf16Ptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func loword(v uintptr) uint16   { return uint16(v & 0xffff) }
func hiword(v uintptr) uint16   { return uint16((v >> 16) & 0xffff) }
func setText(h uintptr, s string) {
	procSetWindowTextW.Call(h, uintptr(unsafe.Pointer(utf16Ptr(s))))
}
func getText(h uintptr) string {
	n, _, _ := procGetWindowTextLengthW.Call(h)
	buf := make([]uint16, n+1)
	procGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}
func send(h uintptr, msg uint32, w, l uintptr) uintptr {
	r, _, _ := procSendMessageW.Call(h, uintptr(msg), w, l)
	return r
}
func messageBox(text string, flags uint32) int {
	r, _, _ := procMessageBoxW.Call(ui.main, uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(unsafe.Pointer(utf16Ptr(appTitle))), uintptr(flags))
	return int(r)
}
func createControl(class, text string, style uint32, r RECT, parent uintptr, id int) uintptr {
	h, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16Ptr(class))), uintptr(unsafe.Pointer(utf16Ptr(text))),
		uintptr(style), uintptr(r.Left), uintptr(r.Top), uintptr(r.Right-r.Left), uintptr(r.Bottom-r.Top), parent, uintptr(id), 0, 0)
	if h != 0 && ui.font != 0 {
		send(h, WM_SETFONT, ui.font, 1)
	}
	return h
}
func enable(h uintptr, yes bool) {
	v := uintptr(0)
	if yes {
		v = 1
	}
	procEnableWindow.Call(h, v)
	invalidate(h)
}
func isEnabled(h uintptr) bool { r, _, _ := procIsWindowEnabled.Call(h); return r != 0 }
func invalidate(h uintptr)     { procInvalidateRect.Call(h, 0, 0) }

// ============================================================
// GDI
// ============================================================

func createPen(w int32, c uintptr) uintptr {
	h, _, _ := procCreatePen.Call(PS_SOLID, uintptr(w), c)
	return h
}
func createBrush(c uintptr) uintptr   { h, _, _ := procCreateSolidBrush.Call(c); return h }
func selectObj(dc, o uintptr) uintptr { r, _, _ := procSelectObject.Call(dc, o); return r }
func deleteObj(o uintptr) {
	if o != 0 {
		procDeleteObject.Call(o)
	}
}
func fillRect(dc uintptr, l, t, r, b int32, c uintptr) {
	br := createBrush(c)
	rc := RECT{l, t, r, b}
	procFillRect.Call(dc, uintptr(unsafe.Pointer(&rc)), br)
	deleteObj(br)
}
func roundBox(dc uintptr, l, t, r, b, rad int32, fill, stroke uintptr) {
	br, pen := createBrush(fill), createPen(1, stroke)
	ob, op := selectObj(dc, br), selectObj(dc, pen)
	procRoundRect.Call(dc, uintptr(l), uintptr(t), uintptr(r), uintptr(b), uintptr(rad), uintptr(rad))
	selectObj(dc, ob)
	selectObj(dc, op)
	deleteObj(br)
	deleteObj(pen)
}
func strokeBox(dc uintptr, l, t, r, b, rad int32, stroke uintptr) {
	pen := createPen(1, stroke)
	nb, _, _ := procGetStockObject.Call(NULL_BRUSH)
	ob, op := selectObj(dc, nb), selectObj(dc, pen)
	procRoundRect.Call(dc, uintptr(l), uintptr(t), uintptr(r), uintptr(b), uintptr(rad), uintptr(rad))
	selectObj(dc, ob)
	selectObj(dc, op)
	deleteObj(pen)
}
func drawText(dc uintptr, s string, x, y, w, h int32, c, font uintptr, f uint32) {
	selectObj(dc, font)
	procSetBkMode.Call(dc, TRANSPARENT_BK)
	procSetTextColor.Call(dc, c)
	rc := RECT{x, y, x + w, y + h}
	procDrawTextW.Call(dc, uintptr(unsafe.Pointer(utf16Ptr(s))), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), uintptr(f|DT_NOPREFIX))
}
func drawLine(dc uintptr, x1, y1, x2, y2, w int32, c uintptr) {
	pen := createPen(w, c)
	op := selectObj(dc, pen)
	procMoveToEx.Call(dc, uintptr(x1), uintptr(y1), 0)
	procLineTo.Call(dc, uintptr(x2), uintptr(y2))
	selectObj(dc, op)
	deleteObj(pen)
}
func withBuffer(dc uintptr, w, h int32, draw func(m uintptr)) {
	m, _, _ := procCreateCompatibleDC.Call(dc)
	bmp, _, _ := procCreateCompatibleBitmap.Call(dc, uintptr(w), uintptr(h))
	old := selectObj(m, bmp)
	draw(m)
	procBitBlt.Call(dc, 0, 0, uintptr(w), uintptr(h), m, 0, 0, 0x00CC0020)
	selectObj(m, old)
	procDeleteDC.Call(m)
	deleteObj(bmp)
}

func loadEmbeddedFonts() {
	ok := true
	for _, d := range [][]byte{fontRegular, fontSemiBold, fontBold} {
		var n uint32
		if h, _, _ := procAddFontMemResourceEx.Call(uintptr(unsafe.Pointer(&d[0])), uintptr(len(d)), 0, uintptr(unsafe.Pointer(&n))); h == 0 {
			ok = false
		}
	}
	if ok {
		fontFace, fontFaceSemi = "Pretendard", "Pretendard SemiBold"
	}
}
func makeFont(px float64, weight uint32, face string) uintptr {
	h, _, _ := procCreateFontW.Call(uintptr(-S(px)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(utf16Ptr(face))))
	return h
}

// ============================================================
// 레이아웃
// ============================================================

type layout struct {
	w, h, title, pad           int32
	lblFolder, boxFolder       RECT
	lblOp, lblParity, rowChips RECT
	list, rowBtn, footer       RECT
}

var L layout

func computeLayout() {
	W, pad := 780.0, 28.0
	cw := W - pad*2
	r := func(x, y, w, h float64) RECT { return RECT{S(x), S(y), S(x + w), S(y + h)} }
	y := 56.0 + 22
	L.w, L.title, L.pad = S(W), S(56), S(pad)
	L.lblFolder = r(pad, y, cw, 20)
	y += 28
	L.boxFolder = r(pad, y, cw-2*92-16, 40)
	y += 40 + 20
	L.lblOp = r(pad, y, 240, 20)
	L.lblParity = r(pad+272, y, 300, 20)
	y += 28
	L.rowChips = r(pad, y, cw, 36)
	y += 36 + 20
	L.list = r(pad, y, cw, 300)
	y += 300 + 16
	L.rowBtn = r(pad, y, cw, 44)
	y += 44 + 16
	L.footer = r(pad, y, cw, 18)
	y += 18 + 18
	L.h = S(y)
}

// ============================================================
// 계획 갱신
// ============================================================

func skipFile(name string, _ os.FileInfo) bool {
	if strings.EqualFold(name, selfName) {
		return true
	}
	p := filepath.Join(getText(ui.folder), name)
	a, _, _ := procGetFileAttributesW.Call(uintptr(unsafe.Pointer(utf16Ptr(p))))
	return a != 0xFFFFFFFF && a&(FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_SYSTEM) != 0
}

func refreshPlan() {
	plan, planErr = nil, ""
	folder := strings.TrimSpace(getText(ui.folder))
	if folder != "" {
		if st, err := os.Stat(folder); err != nil || !st.IsDir() {
			planErr = "폴더를 찾을 수 없습니다."
		} else if names, err := listFiles(folder, skipFile); err != nil {
			planErr = "폴더를 읽을 수 없습니다: " + err.Error()
		} else if p, err := buildPlan(folder, names, curOp, curParity); err != nil {
			planErr = err.Error()
			plan = nil
		} else {
			plan = p
		}
	}
	listScroll = 0
	label := "이름 바꾸기"
	if plan != nil && plan.Changes > 0 {
		label = fmt.Sprintf("이름 바꾸기 · %d개", plan.Changes)
	}
	buttonLabel[ui.run] = label
	enable(ui.run, plan != nil && plan.Changes > 0)
	enable(ui.undo, len(lastUndo) > 0 && strings.EqualFold(lastUndoFolder, folder))
	enable(ui.open, folder != "")
	invalidate(ui.list)
	invalidate(ui.main)
}

func runPlan() {
	if plan == nil || plan.Changes == 0 {
		return
	}
	verb := map[Op]string{OpApply: "번호를 붙입니다", OpRemove: "번호를 지웁니다"}[curOp]
	if messageBox(fmt.Sprintf("%d개 파일에 %s. 계속할까요?", plan.Changes, verb), MB_YESNO|MB_ICONQUESTION) != IDYES {
		return
	}
	execute(plan, fmt.Sprintf("%d개 파일의 이름을 바꿨습니다.", plan.Changes))
}

func undoLast() {
	folder := strings.TrimSpace(getText(ui.folder))
	p, err := undoPlan(folder, lastUndo)
	if err != nil {
		messageBox(err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	if messageBox(fmt.Sprintf("방금 바꾼 %d개 파일을 원래 이름으로 되돌릴까요?", p.Changes), MB_YESNO|MB_ICONQUESTION) != IDYES {
		return
	}
	n := len(lastUndo)
	lastUndo = nil
	execute(p, fmt.Sprintf("%d개 파일을 원래 이름으로 되돌렸습니다.", n))
	lastUndo = nil
	refreshPlan()
}

var tempSeq int

func execute(p *Plan, okText string) {
	_, undo, err := applyPlan(p, func() string {
		tempSeq++
		return fmt.Sprintf(".workkit-oe-%d-%d.tmp", os.Getpid(), tempSeq)
	})
	if err != nil {
		messageBox(err.Error(), MB_OK|MB_ICONERROR)
		refreshPlan()
		return
	}
	lastUndo, lastUndoFolder = undo, p.Folder
	refreshPlan()
	notice = okText
	invalidate(ui.list)
}

// ============================================================
// 메인 창 그리기
// ============================================================

func paintMain(m uintptr, w, h int32) {
	fillRect(m, 0, 0, w, h, clrBg)
	fillRect(m, 0, 0, w, L.title, clrTitleBar)
	drawLine(m, 0, L.title-1, w, L.title-1, 1, clrLine)

	// 로고: 01 / 02
	lx, ly, ls := L.pad, (L.title-S(28))/2, S(28)
	roundBox(m, lx, ly, lx+ls, ly+ls, S(9), clrBg, clrAccent)
	drawText(m, "01", lx, ly, ls, ls, clrText, ui.fontSmall, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	drawText(m, appName, lx+ls+S(12), 0, S(200), L.title, clrText, ui.fontTitle, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(m, appBrand, lx+ls+S(12)+S(128), 0, S(120), L.title, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	label := func(r RECT, s string) {
		drawText(m, s, r.Left, r.Top, r.Right-r.Left, r.Bottom-r.Top, clrSub, ui.fontSemi, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	}
	label(L.lblFolder, "작업 폴더")
	drawText(m, "폴더를 창에 끌어놓아도 됩니다", L.lblFolder.Left, L.lblFolder.Top, L.lblFolder.Right-L.lblFolder.Left, S(20), clrMuted, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)
	fb := L.boxFolder
	stroke := clrLine2
	if focusedEdit == ui.folder {
		stroke = clrAccent
	}
	roundBox(m, fb.Left, fb.Top, fb.Right, fb.Bottom, S(10), clrInput, stroke)
	if getText(ui.folder) == "" && focusedEdit != ui.folder {
		drawText(m, "번호를 붙일 파일이 있는 폴더", fb.Left+S(13), fb.Top, fb.Right-fb.Left, fb.Bottom-fb.Top, clrMuted, ui.font, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	}
	label(L.lblOp, "작업")
	label(L.lblParity, "번호")

	f := L.footer
	drawText(m, "하위 폴더와 숨김 파일은 건드리지 않습니다. 파일 이름순(탐색기 순서)으로 번호를 붙입니다.", f.Left, f.Top, S(560), f.Bottom-f.Top, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(m, appVersion+"  ·  "+buildDate, f.Right-S(200), f.Top, S(200), f.Bottom-f.Top, clrMuted, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)

	// 요약 (버튼 행 왼쪽)
	br := L.rowBtn
	sum, col := "", clrSub
	switch {
	case notice != "":
		sum, col = notice, clrAccent
	case plan != nil:
		sum = fmt.Sprintf("파일 %d개  ·  바뀔 파일 %d개", len(plan.Items), plan.Changes)
	}
	drawText(m, sum, br.Left, br.Top, S(380), br.Bottom-br.Top, col, ui.fontSemi, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)

	r := windowRadius()
	strokeBox(m, 0, 0, w, h, r, clrLine)
}

// ============================================================
// 미리보기 목록 (전용 윈도우 클래스)
// ============================================================

var listScroll int32
var listHover = -1
var listDrag bool
var dragOffset int32

const listClass = "WorkkitPlanList"

func rowH() int32    { return S(34) }
func headerH() int32 { return S(38) }

func listMetrics(h int32) (content, view int32) {
	n := int32(0)
	if plan != nil {
		n = int32(len(plan.Items))
	}
	return n * rowH(), h - headerH() - S(1)
}

func clampScroll(h int32) {
	c, v := listMetrics(h)
	if listScroll > c-v {
		listScroll = c - v
	}
	if listScroll < 0 {
		listScroll = 0
	}
}

func thumbRect(w, h int32) (RECT, bool) {
	c, v := listMetrics(h)
	if c <= v || v <= 0 {
		return RECT{}, false
	}
	track := v - S(8)
	th := int32(float64(track) * float64(v) / float64(c))
	if th < S(28) {
		th = S(28)
	}
	ty := headerH() + S(4) + int32(float64(track-th)*float64(listScroll)/float64(c-v))
	return RECT{w - S(9), ty, w - S(4), ty + th}, true
}

func listWndProc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	w, h := rc.Right, rc.Bottom
	switch msg {
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		var ps PAINTSTRUCT
		dc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		withBuffer(dc, w, h, func(m uintptr) { paintList(m, w, h) })
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case WM_MOUSEWHEEL:
		delta := int32(int16(hiword(wp)))
		listScroll -= delta * rowH() * 3 / 120
		clampScroll(h)
		invalidate(hwnd)
		return 0
	case WM_LBUTTONDOWN:
		y := int32(int16(hiword(lp)))
		x := int32(int16(loword(lp)))
		if t, ok := thumbRect(w, h); ok && x >= w-S(14) {
			if y >= t.Top && y <= t.Bottom {
				listDrag, dragOffset = true, y-t.Top
			} else {
				_, v := listMetrics(h)
				if y < t.Top {
					listScroll -= v
				} else {
					listScroll += v
				}
				clampScroll(h)
				invalidate(hwnd)
			}
			procSetCapture.Call(hwnd)
		}
		return 0
	case WM_LBUTTONUP:
		listDrag = false
		procReleaseCapture.Call()
		return 0
	case WM_MOUSEMOVE:
		y := int32(int16(hiword(lp)))
		if listDrag {
			c, v := listMetrics(h)
			t, _ := thumbRect(w, h)
			track := v - S(8) - (t.Bottom - t.Top)
			if track > 0 {
				listScroll = int32(float64(y-dragOffset-headerH()-S(4)) / float64(track) * float64(c-v))
				clampScroll(h)
				invalidate(hwnd)
			}
			return 0
		}
		idx := -1
		if y > headerH() {
			idx = int((y - headerH() + listScroll) / rowH())
		}
		if idx != listHover {
			listHover = idx
			invalidate(hwnd)
			tme := TRACKMOUSEEVENT{DwFlags: TME_LEAVE, HwndTrack: hwnd}
			tme.CbSize = uint32(unsafe.Sizeof(tme))
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		}
		return 0
	case WM_MOUSELEAVE:
		listHover = -1
		invalidate(hwnd)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wp, lp)
	return r
}

func paintList(m uintptr, w, h int32) {
	fillRect(m, 0, 0, w, h, clrBg)
	roundBox(m, 0, 0, w, h, S(14), clrPanel, clrLine)
	pad := S(18)
	statusW := S(96)
	arrowW := S(28)
	colW := (w - pad*2 - statusW - arrowW - S(12)) / 2
	xOld, xArrow := pad, pad+colW
	xNew := xArrow + arrowW
	xStatus := w - pad - statusW

	hh := headerH()
	drawText(m, "현재 이름", xOld, 0, colW, hh, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(m, "바뀔 이름", xNew, 0, colW, hh, clrMuted, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(m, "처리", xStatus, 0, statusW, hh, clrMuted, ui.fontSmall, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	drawLine(m, S(1), hh, w-S(1), hh, 1, clrLine)

	center := func(title, sub string, col uintptr) {
		drawText(m, title, pad, hh+S(80), w-pad*2, S(26), col, ui.fontSemi, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
		drawText(m, sub, pad*2, hh+S(110), w-pad*4, S(60), clrMuted, ui.fontSmall, DT_CENTER|DT_WORDBREAK)
	}
	switch {
	case planErr != "":
		center("진행할 수 없습니다", planErr, clrDanger)
		return
	case plan == nil:
		center("폴더를 선택하세요", "'변경'을 누르거나 폴더를 이 창에 끌어놓으면 바뀔 이름을 미리 보여줍니다.", clrSub)
		return
	case len(plan.Items) == 0:
		center("파일이 없습니다", "이 폴더에는 번호를 붙일 파일이 없습니다.", clrSub)
		return
	}

	clampScroll(h)
	top := hh + S(1)
	first := int(listScroll / rowH())
	for i := first; i < len(plan.Items); i++ {
		y := top + int32(i)*rowH() - listScroll
		if y > h {
			break
		}
		it := plan.Items[i]
		bg := clrPanel
		if i == listHover {
			bg = clrHover
		} else if i%2 == 1 {
			bg = clrRowAlt
		}
		fillRect(m, S(1), y, w-S(1), y+rowH(), bg)
		oldC, newC := clrSub, clrText
		if !it.Change {
			oldC, newC = clrMuted, clrMuted
		}
		drawText(m, it.Old, xOld, y, colW, rowH(), oldC, ui.font, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
		if it.Change {
			drawText(m, "→", xArrow, y, arrowW, rowH(), clrAccent, ui.font, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
		}
		drawText(m, it.New, xNew, y, colW, rowH(), newC, ui.font, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)
		// 상태 배지
		bh := S(22)
		by := y + (rowH()-bh)/2
		fill, txt := clrBg, clrMuted
		if it.Change {
			fill, txt = clrAccentBg, clrAccent
		}
		roundBox(m, xStatus, by, xStatus+statusW, by+bh, bh, fill, fill)
		drawText(m, it.Status, xStatus, by, statusW, bh, txt, ui.fontSmall, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	}
	// 둥근 모서리 다시 그리기 (행이 모서리를 덮지 않도록)
	fillRect(m, 0, h-S(1), w, h, clrBg)
	strokeBox(m, 0, 0, w, h, S(14), clrLine)
	if t, ok := thumbRect(w, h); ok {
		c := clrLine2
		if listDrag {
			c = clrSub
		}
		roundBox(m, t.Left, t.Top, t.Right, t.Bottom, S(5), c, c)
	}
}

// ============================================================
// 오너드로우 버튼
// ============================================================

func ownerButton(kind int, label string, r RECT, parent uintptr, id int) uintptr {
	h := createControl("BUTTON", label, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, r, parent, id)
	buttonKind[h], buttonLabel[h] = kind, label
	idx := int32(GWLP_WNDPROC)
	old, _, _ := procSetWindowLongPtrW.Call(h, uintptr(idx), syscall.NewCallback(hoverProc))
	origProc[h] = old
	return h
}

func hoverProc(h uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case WM_MOUSEMOVE:
		if !hoverState[h] {
			hoverState[h] = true
			invalidate(h)
			tme := TRACKMOUSEEVENT{DwFlags: TME_LEAVE, HwndTrack: h}
			tme.CbSize = uint32(unsafe.Sizeof(tme))
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		}
	case WM_MOUSELEAVE:
		hoverState[h] = false
		invalidate(h)
	case WM_SETCURSOR:
		if isEnabled(h) {
			procSetCursor.Call(cursorHand)
			return 1
		}
	}
	r, _, _ := procCallWindowProcW.Call(origProc[h], h, uintptr(msg), wp, lp)
	return r
}

func isSelected(h uintptr) bool {
	switch h {
	case ui.apply:
		return curOp == OpApply
	case ui.remove:
		return curOp == OpRemove
	case ui.odd:
		return curParity == Odd
	case ui.even:
		return curParity == Even
	}
	return false
}

func drawOwner(d *DRAWITEMSTRUCT) {
	h := d.HwndItem
	w, hh := d.RcItem.Right-d.RcItem.Left, d.RcItem.Bottom-d.RcItem.Top
	pressed := d.ItemState&ODS_SELECTED != 0
	disabled := d.ItemState&ODS_DISABLED != 0
	hovered := hoverState[h] && !disabled
	focus := d.ItemState&ODS_FOCUS != 0 && d.ItemState&ODS_NOFOCUSRECT == 0 && !disabled
	label := buttonLabel[h]
	center := uint32(DT_CENTER | DT_VCENTER | DT_SINGLELINE)
	withBuffer(d.Hdc, w, hh, func(m uintptr) {
		bg := clrBg
		if buttonKind[h] == kindTitle {
			bg = clrTitleBar
		}
		fillRect(m, 0, 0, w, hh, bg)
		rad := S(10)
		switch buttonKind[h] {
		case kindPrimary:
			fill, txt := clrAccent, clrOnAccent
			switch {
			case disabled:
				fill, txt = rgb(40, 60, 56), rgb(110, 140, 132)
			case pressed:
				fill = clrAccentDm
			case hovered:
				fill = clrAccentHi
			}
			roundBox(m, 0, 0, w, hh, rad, fill, fill)
			drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
		case kindNeutral:
			fill, stroke, txt := clrPanel, clrLine2, clrText
			if disabled {
				fill, stroke, txt = clrBg, clrLine, clrMuted
			} else if pressed {
				fill, stroke = clrAccentBg, clrAccent
			} else if hovered {
				fill, stroke = clrHover, rgb(96, 99, 97)
			}
			roundBox(m, 0, 0, w, hh, rad, fill, stroke)
			drawText(m, label, 0, 0, w, hh, txt, ui.fontSemi, center)
		case kindChip:
			sel := isSelected(h)
			fill, stroke, txt, font := clrPanel, clrLine2, clrSub, ui.font
			if sel {
				fill, stroke, txt, font = clrAccentBg, clrAccent, clrText, ui.fontSemi
			} else if hovered {
				fill, txt = clrHover, clrText
			}
			roundBox(m, 0, 0, w, hh, S(8), fill, stroke)
			drawText(m, label, 0, 0, w, hh, txt, font, center)
		case kindTitle:
			if hovered {
				c := clrHover
				if h == ui.closeBtn {
					c = rgb(229, 72, 77)
				}
				roundBox(m, S(2), S(2), w-S(2), hh-S(2), S(8), c, c)
			}
			cx, cy, a := w/2, hh/2, S(5)
			if h == ui.closeBtn {
				drawLine(m, cx-a, cy-a, cx+a+1, cy+a+1, S(1)+1, clrText)
				drawLine(m, cx-a, cy+a, cx+a+1, cy-a-1, S(1)+1, clrText)
			} else {
				drawLine(m, cx-a, cy, cx+a+1, cy, S(1)+1, clrText)
			}
		}
		if focus && buttonKind[h] != kindTitle {
			strokeBox(m, 0, 0, w, hh, rad, rgb(255, 255, 255))
		}
	})
}

// ============================================================
// 창 만들기
// ============================================================

func windowRadius() int32 {
	if isWin11 {
		return 0
	}
	return S(14)
}

func createUI(hwnd uintptr) {
	ui.font = makeFont(14, 400, fontFace)
	ui.fontSemi = makeFont(14, 600, fontFaceSemi)
	ui.fontSmall = makeFont(12.5, 400, fontFace)
	ui.fontTitle = makeFont(16, 700, fontFace)

	bs := S(36)
	by := (L.title - bs) / 2
	ui.closeBtn = ownerButton(kindTitle, "", RECT{L.w - S(12) - bs, by, L.w - S(12), by + bs}, hwnd, ID_CLOSEBTN)
	ui.minBtn = ownerButton(kindTitle, "", RECT{L.w - S(16) - bs*2, by, L.w - S(16) - bs, by + bs}, hwnd, ID_MINBTN)

	fb := L.boxFolder
	eh := S(20)
	ui.folder = createControl("EDIT", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_LEFT|ES_AUTOHSCROLL,
		RECT{fb.Left + S(12), fb.Top + (fb.Bottom-fb.Top-eh)/2, fb.Right - S(12), fb.Top + (fb.Bottom-fb.Top-eh)/2 + eh}, hwnd, ID_FOLDER)
	x := fb.Right + S(8)
	ui.browse = ownerButton(kindNeutral, "변경", RECT{x, fb.Top, x + S(92), fb.Bottom}, hwnd, ID_BROWSE)
	x += S(100)
	ui.open = ownerButton(kindNeutral, "폴더 열기", RECT{x, fb.Top, x + S(92), fb.Bottom}, hwnd, ID_OPEN)

	cr := L.rowChips
	x = cr.Left
	ui.apply = ownerButton(kindChip, "번호 붙이기", RECT{x, cr.Top, x + S(124), cr.Bottom}, hwnd, ID_APPLY)
	ui.remove = ownerButton(kindChip, "번호 지우기", RECT{x + S(130), cr.Top, x + S(254), cr.Bottom}, hwnd, ID_REMOVE)
	x = L.lblParity.Left
	ui.odd = ownerButton(kindChip, "홀수  01 · 03 · 05", RECT{x, cr.Top, x + S(172), cr.Bottom}, hwnd, ID_ODD)
	ui.even = ownerButton(kindChip, "짝수  02 · 04 · 06", RECT{x + S(178), cr.Top, x + S(350), cr.Bottom}, hwnd, ID_EVEN)

	lr := L.list
	ui.list, _, _ = procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16Ptr(listClass))), 0, WS_CHILD|WS_VISIBLE,
		uintptr(lr.Left), uintptr(lr.Top), uintptr(lr.Right-lr.Left), uintptr(lr.Bottom-lr.Top), hwnd, ID_LIST, 0, 0)

	br := L.rowBtn
	ui.run = ownerButton(kindPrimary, "이름 바꾸기", RECT{br.Right - S(210), br.Top, br.Right, br.Bottom}, hwnd, ID_RUN)
	ui.undo = ownerButton(kindNeutral, "되돌리기", RECT{br.Right - S(210) - S(8) - S(110), br.Top, br.Right - S(218), br.Bottom}, hwnd, ID_UNDO)

	procDragAcceptFiles.Call(hwnd, 1)
	refreshPlan()
}

func applyWindowShape(hwnd uintptr) {
	if isWin11 {
		pref := int32(2)
		procDwmSetWindowAttribute.Call(hwnd, 33, uintptr(unsafe.Pointer(&pref)), 4)
		return
	}
	rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(L.w+1), uintptr(L.h+1), uintptr(S(14)), uintptr(S(14)))
	procSetWindowRgn.Call(hwnd, rgn, 1)
}

func chooseFolder() {
	disp := make([]uint16, 260)
	bi := BROWSEINFO{HwndOwner: ui.main, PszDisplayName: &disp[0], LpszTitle: utf16Ptr("번호를 붙일 파일이 있는 폴더를 선택하세요."), UlFlags: BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE}
	pidl, _, _ := procSHBrowseForFolderW.Call(uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return
	}
	defer procCoTaskMemFree.Call(pidl)
	buf := make([]uint16, 32768)
	if ok, _, _ := procSHGetPathFromIDListW.Call(pidl, uintptr(unsafe.Pointer(&buf[0]))); ok != 0 {
		setFolder(syscall.UTF16ToString(buf))
	}
}

func setFolder(p string) {
	notice = ""
	setText(ui.folder, p)
	refreshPlan()
}

func wndProc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		ui.main = hwnd
		createUI(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		var ps PAINTSTRUCT
		dc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		withBuffer(dc, rc.Right, rc.Bottom, func(m uintptr) { paintMain(m, rc.Right, rc.Bottom) })
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case WM_NCHITTEST:
		pt := POINT{int32(int16(loword(lp))), int32(int16(hiword(lp)))}
		procScreenToClient.Call(hwnd, uintptr(unsafe.Pointer(&pt)))
		if pt.Y >= 0 && pt.Y < L.title && pt.X < L.w-S(100) {
			return HTCAPTION
		}
	case WM_DRAWITEM:
		drawOwner((*DRAWITEMSTRUCT)(unsafe.Pointer(lp)))
		return 1
	case WM_DROPFILES:
		buf := make([]uint16, 32768)
		procDragQueryFileW.Call(wp, 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		procDragFinish.Call(wp)
		p := syscall.UTF16ToString(buf)
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			p = filepath.Dir(p)
		}
		setFolder(p)
		return 0
	case WM_ACTIVATEAPP:
		if wp != 0 && ui.list != 0 && notice == "" {
			refreshPlan() // 다른 창에서 파일을 바꾸고 돌아오면 자동 갱신
		}
	case WM_TIMER:
		procKillTimer.Call(hwnd, 1)
		refreshPlan()
		return 0
	case WM_COMMAND:
		id, code := int(loword(wp)), int(hiword(wp))
		if id == ID_FOLDER {
			switch code {
			case EN_SETFOCUS:
				focusedEdit = lp
				invalidate(hwnd)
			case EN_KILLFOCUS:
				focusedEdit = 0
				invalidate(hwnd)
			case EN_CHANGE:
				notice = ""
				procSetTimer.Call(hwnd, 1, 350, 0) // 입력이 멈추면 갱신
			}
			return 0
		}
		if code != BN_CLICKED {
			return 0
		}
		switch id {
		case ID_BROWSE:
			chooseFolder()
		case ID_OPEN:
			if f := strings.TrimSpace(getText(ui.folder)); f != "" {
				procShellExecuteW.Call(hwnd, uintptr(unsafe.Pointer(utf16Ptr("open"))), uintptr(unsafe.Pointer(utf16Ptr(f))), 0, 0, SW_SHOWNORMAL)
			}
		case ID_APPLY, ID_REMOVE:
			curOp = map[int]Op{ID_APPLY: OpApply, ID_REMOVE: OpRemove}[id]
			notice = ""
			invalidate(ui.apply)
			invalidate(ui.remove)
			refreshPlan()
		case ID_ODD, ID_EVEN:
			curParity = map[int]Parity{ID_ODD: Odd, ID_EVEN: Even}[id]
			notice = ""
			invalidate(ui.odd)
			invalidate(ui.even)
			refreshPlan()
		case ID_RUN:
			runPlan()
		case ID_UNDO:
			undoLast()
		case ID_MINBTN:
			procShowWindow.Call(hwnd, SW_MINIMIZE)
		case ID_CLOSEBTN:
			procDestroyWindow.Call(hwnd)
		}
		return 0
	case WM_CTLCOLOREDIT, WM_CTLCOLORSTATIC:
		procSetBkColor.Call(wp, clrInput)
		procSetTextColor.Call(wp, clrText)
		return brushInput
	case WM_DESTROY:
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wp, lp)
	return r
}

func main() {
	runtime.LockOSThread()
	procSetProcessDPIAware.Call()
	initDPI()
	procCoInitializeEx.Call(0, COINIT_APARTMENTTHREADED)
	defer procCoUninitialize.Call()
	icc := INITCOMMONCONTROLSEX{DwSize: 8, DwICC: 0x000040FF}
	procInitCommonControlsEx.Call(uintptr(unsafe.Pointer(&icc)))

	var vi OSVERSIONINFOW
	vi.Size = uint32(unsafe.Sizeof(vi))
	procRtlGetVersion.Call(uintptr(unsafe.Pointer(&vi)))
	isWin11 = vi.Major >= 10 && vi.Build >= 22000
	if exe, err := os.Executable(); err == nil {
		selfName = filepath.Base(exe)
	}

	loadEmbeddedFonts()
	brushInput = createBrush(clrInput)
	hInst, _, _ := procGetModuleHandleW.Call(0)
	cursorArrow, _, _ = procLoadCursorW.Call(0, IDC_ARROW)
	cursorHand, _, _ = procLoadCursorW.Call(0, IDC_HAND)
	icon, _, _ := procLoadIconW.Call(hInst, 1)

	lc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(listWndProc), HInstance: hInst, HCursor: cursorArrow, LpszClassName: utf16Ptr(listClass)}
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&lc)))
	cls := utf16Ptr("WorkkitOddEvenRenamer")
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(wndProc), HInstance: hInst, HIcon: icon, HIconSm: icon, HCursor: cursorArrow, LpszClassName: cls}
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	computeLayout()
	hwnd, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(utf16Ptr(appTitle))),
		WS_POPUP|WS_CLIPCHILDREN|WS_SYSMENU|WS_MINIMIZEBOX, 0, 0, uintptr(L.w), uintptr(L.h), 0, 0, hInst, 0)
	applyWindowShape(hwnd)
	var wa RECT
	procSystemParametersInfoW.Call(SPI_GETWORKAREA, 0, uintptr(unsafe.Pointer(&wa)), 0)
	y := wa.Top + (wa.Bottom-wa.Top-L.h)/2
	if y < wa.Top {
		y = wa.Top
	}
	procMoveWindow.Call(hwnd, uintptr(wa.Left+(wa.Right-wa.Left-L.w)/2), uintptr(y), uintptr(L.w), uintptr(L.h), 1)
	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)

	// 폴더를 exe 아이콘에 끌어놓아 실행한 경우
	if len(os.Args) > 1 {
		p := os.Args[1]
		if st, err := os.Stat(p); err == nil {
			if !st.IsDir() {
				p = filepath.Dir(p)
			}
			setFolder(p)
		}
	}

	var msg MSG
	for {
		r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if r, _, _ := procIsDialogMessageW.Call(hwnd, uintptr(unsafe.Pointer(&msg))); r != 0 {
			continue
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}
}
