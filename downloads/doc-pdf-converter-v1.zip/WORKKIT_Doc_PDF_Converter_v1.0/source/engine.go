package main

import (
	"strconv"
	"strings"
)

// 엔진(PowerShell)이 보내는 한 줄을 해석한다.
type event struct {
	Kind byte // 'S' 시작, 'O' 성공, 'E' 실패, 'F' 전체 끝
	I    int  // 목록 안 번호 (엔진에 넘긴 순서)
	Text string
	Code string
}

func parseLine(line string) (event, bool) {
	line = strings.TrimRight(line, "\r\n")
	line = strings.TrimPrefix(line, "\ufeff")
	if len(line) < 3 || line[1] != ' ' {
		return event{}, false
	}
	kind := line[0]
	rest := line[2:]
	parts := strings.Split(rest, "\t")
	i, err := strconv.Atoi(strings.TrimSpace(parts[0]))
	if err != nil || i < 0 {
		return event{}, false
	}
	ev := event{Kind: kind, I: i}
	switch kind {
	case 'S':
	case 'O':
		if len(parts) < 2 || parts[1] == "" {
			return event{}, false
		}
		ev.Text = parts[1]
	case 'E':
		if len(parts) >= 2 {
			ev.Code = parts[1]
		}
		if len(parts) >= 3 {
			ev.Text = parts[2]
		}
	default:
		return event{}, false
	}
	return ev, true
}
