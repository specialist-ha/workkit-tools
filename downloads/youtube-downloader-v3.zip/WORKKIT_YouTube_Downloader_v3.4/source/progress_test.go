package main

import (
	"math"
	"testing"
)

func near(a, b float64) bool { return math.Abs(a-b) < 1e-6 }

func TestTwoPartsMonotonic(t *testing.T) {
	it, ok := parseItemLine("WK_ITEM:NA|NA|800|200|NA|제목 | 파이프")
	if !ok || it.Index != 1 || it.Count != 1 || len(it.Parts) != 2 || it.Title != "제목 | 파이프" {
		t.Fatalf("item parse: %+v %v", it, ok)
	}
	tr := newByteTracker(it.Parts)
	steps := []struct {
		line string
		want float64
	}{
		{"WK_PROG:downloading|400|800|1000|3|a.f137.mp4", 0.4},
		{"WK_PROG:finished|800|800|1000|0|a.f137.mp4", 0.8},
		{"WK_PROG:downloading|100|200|1000|1|a.f140.m4a", 0.9},
		{"WK_PROG:finished|200|200|NA|NA|a.f140.m4a", 1.0},
	}
	prev := 0.0
	for _, s := range steps {
		p, ok := parseProgressLine(s.line)
		if !ok {
			t.Fatal("prog parse")
		}
		got := tr.update(p)
		if !near(got, s.want) {
			t.Errorf("%s: got %.4f want %.4f", s.line, got, s.want)
		}
		if got < prev {
			t.Errorf("went backwards")
		}
		prev = got
	}
}

func TestSingleUnknownSize(t *testing.T) {
	it, _ := parseItemLine("WK_ITEM:3|12|NA|NA|NA|노래")
	if it.Index != 3 || it.Count != 12 || len(it.Parts) != 1 {
		t.Fatalf("%+v", it)
	}
	tr := newByteTracker(it.Parts)
	p, _ := parseProgressLine("WK_PROG:downloading|250|1000|0|-1|x.webm")
	if g := tr.update(p); !near(g, .25) {
		t.Errorf("got %v", g)
	}
	// 추정 총량이 커져도 뒤로 가지 않음
	p, _ = parseProgressLine("WK_PROG:downloading|260|2000|0|-1|x.webm")
	if g := tr.update(p); !near(g, .25) {
		t.Errorf("monotonic got %v", g)
	}
}

func TestStages(t *testing.T) {
	if postStage("[Merger] Merging formats into \"a.mp4\"") == "" || postStage("[download] 10%") != "" {
		t.Fatal("stage")
	}
	if s := speedText(progressLine{Speed: 1.5 * 1024 * 1024, ETA: 65}); s != "1.5 MB/s · 남은 시간 1분 5초" {
		t.Fatal(s)
	}
}
