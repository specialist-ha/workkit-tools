module workkit-oddeven-renamer

go 1.22
