//go:build windows

package main

import (
	"archive/zip"
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

const (
	appTitle  = "하정욱 YouTube 다운로더"
	buildDate = "2026-09-18"

	WM_CREATE          = 0x0001
	WM_DESTROY         = 0x0002
	WM_MOVE            = 0x0003
	WM_SIZE            = 0x0005
	WM_PAINT           = 0x000F
	WM_CLOSE           = 0x0010
	WM_ERASEBKGND      = 0x0014
	WM_SETCURSOR       = 0x0020
	WM_COMMAND         = 0x0111
	WM_TIMER           = 0x0113
	WM_CTLCOLOREDIT    = 0x0133
	WM_CTLCOLORLISTBOX = 0x0134
	WM_CTLCOLORBTN     = 0x0135
	WM_CTLCOLORSTATIC  = 0x0138
	WM_SETFONT         = 0x0030
	WM_USER            = 0x0400
	WM_DRAWITEM        = 0x002B
	WM_NCHITTEST       = 0x0084
	WM_LBUTTONDOWN     = 0x0201
	WM_LBUTTONUP       = 0x0202
	WM_MOUSEMOVE       = 0x0200
	WM_MOUSELEAVE      = 0x02A3
	WM_NCLBUTTONDOWN   = 0x00A1
	WM_SYSCOMMAND      = 0x0112

	WS_OVERLAPPED   = 0x00000000
	WS_POPUP        = 0x80000000
	WS_CAPTION      = 0x00C00000
	WS_SYSMENU      = 0x00080000
	WS_MINIMIZEBOX  = 0x00020000
	WS_VISIBLE      = 0x10000000
	WS_CHILD        = 0x40000000
	WS_BORDER       = 0x00800000
	WS_TABSTOP      = 0x00010000
	WS_VSCROLL      = 0x00200000
	WS_CLIPCHILDREN = 0x02000000

	WS_EX_LAYERED = 0x00080000

	ES_LEFT        = 0x0000
	ES_MULTILINE   = 0x0004
	ES_AUTOVSCROLL = 0x0040
	ES_READONLY    = 0x0800
	ES_WANTRETURN  = 0x1000

	BS_PUSHBUTTON = 0x00000000
	BS_OWNERDRAW  = 0x0000000B
	SS_OWNERDRAW  = 0x0000000D
	SS_NOTIFY     = 0x00000100

	CBS_DROPDOWNLIST = 0x0003

	SW_SHOW       = 5
	SW_SHOWNORMAL = 1
	SW_MINIMIZE   = 6

	COLOR_WINDOW = 5
	IDC_ARROW    = 32512

	MB_OK              = 0x00000000
	MB_ICONERROR       = 0x00000010
	MB_ICONWARNING     = 0x00000030
	MB_ICONINFORMATION = 0x00000040
	MB_YESNO           = 0x00000004
	IDYES              = 6

	BN_CLICKED    = 0
	CBN_SELCHANGE = 1

	CB_ADDSTRING = 0x0143
	CB_GETCURSEL = 0x0147
	CB_SETCURSEL = 0x014E

	EM_SETSEL      = 0x00B1
	EM_REPLACESEL  = 0x00C2
	EM_SCROLLCARET = 0x00B7

	PBM_SETRANGE32 = WM_USER + 6
	PBM_SETPOS     = WM_USER + 2

	BIF_RETURNONLYFSDIRS = 0x00000001
	BIF_NEWDIALOGSTYLE   = 0x00000040

	COINIT_APARTMENTTHREADED = 0x2

	CREATE_NO_WINDOW = 0x08000000

	ODT_BUTTON   = 4
	ODT_STATIC   = 3
	ODS_SELECTED = 0x0001
	ODS_DISABLED = 0x0004
	ODS_FOCUS    = 0x0010

	TME_LEAVE = 0x00000002

	HTCLIENT  = 1
	HTCAPTION = 2

	AC_SRC_OVER = 0x00

	GWLP_WNDPROC = -4

	ID_URL      = 1001
	ID_FOLDER   = 1002
	ID_BROWSE   = 1003
	ID_FORMAT   = 1004
	ID_QUALITY  = 1005
	ID_PLAYLIST = 1006
	ID_SUBTITLE = 1007
	ID_START    = 1008
	ID_CANCEL   = 1009
	ID_OPEN     = 1010
	ID_UPDATE   = 1011
	ID_PROGRESS = 1012
	ID_STATUS   = 1013
	ID_LOG      = 1014
	ID_SSL      = 1015
	ID_MINBTN   = 1016
	ID_CLOSEBTN = 1017
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	comctl32 = syscall.NewLazyDLL("comctl32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	msimg32  = syscall.NewLazyDLL("msimg32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")

	procRegisterClassExW     = user32.NewProc("RegisterClassExW")
	procCreateWindowExW      = user32.NewProc("CreateWindowExW")
	procDefWindowProcW       = user32.NewProc("DefWindowProcW")
	procShowWindow           = user32.NewProc("ShowWindow")
	procUpdateWindow         = user32.NewProc("UpdateWindow")
	procGetMessageW          = user32.NewProc("GetMessageW")
	procTranslateMessage     = user32.NewProc("TranslateMessage")
	procDispatchMessageW     = user32.NewProc("DispatchMessageW")
	procPostQuitMessage      = user32.NewProc("PostQuitMessage")
	procDestroyWindow        = user32.NewProc("DestroyWindow")
	procSetWindowTextW       = user32.NewProc("SetWindowTextW")
	procGetWindowTextW       = user32.NewProc("GetWindowTextW")
	procGetWindowTextLengthW = user32.NewProc("GetWindowTextLengthW")
	procEnableWindow         = user32.NewProc("EnableWindow")
	procSendMessageW         = user32.NewProc("SendMessageW")
	procSetTimer             = user32.NewProc("SetTimer")
	procMessageBoxW          = user32.NewProc("MessageBoxW")
	procLoadCursorW          = user32.NewProc("LoadCursorW")
	procSetProcessDPIAware   = user32.NewProc("SetProcessDPIAware")
	procInvalidateRect       = user32.NewProc("InvalidateRect")
	procGetClientRect        = user32.NewProc("GetClientRect")
	procBeginPaint           = user32.NewProc("BeginPaint")
	procEndPaint             = user32.NewProc("EndPaint")
	procFillRect             = user32.NewProc("FillRect")
	procDrawTextW            = user32.NewProc("DrawTextW")
	procSetWindowPos         = user32.NewProc("SetWindowPos")
	procGetWindowLongPtrW    = user32.NewProc("GetWindowLongPtrW")
	procSetWindowLongPtrW    = user32.NewProc("SetWindowLongPtrW")
	procCallWindowProcW      = user32.NewProc("CallWindowProcW")
	procTrackMouseEvent      = user32.NewProc("TrackMouseEvent")
	procReleaseCapture       = user32.NewProc("ReleaseCapture")
	procSetWindowRgn         = user32.NewProc("SetWindowRgn")
	procMoveWindow           = user32.NewProc("MoveWindow")
	procScreenToClient       = user32.NewProc("ScreenToClient")
	procGetCursorPos         = user32.NewProc("GetCursorPos")

	procGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")

	procSHBrowseForFolderW   = shell32.NewProc("SHBrowseForFolderW")
	procSHGetPathFromIDListW = shell32.NewProc("SHGetPathFromIDListW")
	procShellExecuteW        = shell32.NewProc("ShellExecuteW")

	procCoInitializeEx = ole32.NewProc("CoInitializeEx")
	procCoUninitialize = ole32.NewProc("CoUninitialize")
	procCoTaskMemFree  = ole32.NewProc("CoTaskMemFree")

	procInitCommonControlsEx = comctl32.NewProc("InitCommonControlsEx")

	procCreateFontW            = gdi32.NewProc("CreateFontW")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procSetBkColor             = gdi32.NewProc("SetBkColor")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procRoundRect              = gdi32.NewProc("RoundRect")
	procRectangle              = gdi32.NewProc("Rectangle")
	procEllipse                = gdi32.NewProc("Ellipse")
	procCreatePen              = gdi32.NewProc("CreatePen")
	procCreateRoundRectRgn     = gdi32.NewProc("CreateRoundRectRgn")
	procSelectClipRgn          = gdi32.NewProc("SelectClipRgn")
	procExtCreatePen           = gdi32.NewProc("ExtCreatePen")
	procGetStockObject         = gdi32.NewProc("GetStockObject")
	procSetTextAlign           = gdi32.NewProc("SetTextAlign")

	procAlphaBlend   = msimg32.NewProc("AlphaBlend")
	procGradientFill = msimg32.NewProc("GradientFill")

	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
)

type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}

type MSG struct {
	Hwnd     uintptr
	Message  uint32
	WParam   uintptr
	LParam   uintptr
	Time     uint32
	PtX      int32
	PtY      int32
	LPrivate uint32
}

type INITCOMMONCONTROLSEX struct {
	DwSize uint32
	DwICC  uint32
}

type BROWSEINFO struct {
	HwndOwner      uintptr
	PidlRoot       uintptr
	PszDisplayName *uint16
	LpszTitle      *uint16
	UlFlags        uint32
	Lpfn           uintptr
	LParam         uintptr
	IImage         int32
}

type RECT struct {
	Left, Top, Right, Bottom int32
}

type POINT struct {
	X, Y int32
}

type PAINTSTRUCT struct {
	Hdc         uintptr
	FErase      int32
	RcPaint     RECT
	FRestore    int32
	FIncUpdate  int32
	RgbReserved [32]byte
}

type DRAWITEMSTRUCT struct {
	CtlType    uint32
	CtlID      uint32
	ItemID     uint32
	ItemAction uint32
	ItemState  uint32
	HwndItem   uintptr
	Hdc        uintptr
	RcItem     RECT
	ItemData   uintptr
}

type TRACKMOUSEEVENT struct {
	CbSize      uint32
	DwFlags     uint32
	HwndTrack   uintptr
	DwHoverTime uint32
}

type TRIVERTEX struct {
	X, Y                    int32
	Red, Green, Blue, Alpha uint16
}

type GRADIENTRECT struct {
	UpperLeft, LowerRight uint32
}

// ============================================================
// 색상 팔레트 - 소프트 글라스 + 뉴모피즘 하이브리드 테마
// ============================================================

var (
	clrBgTop      = rgb(233, 237, 250) // 배경 그라데이션 상단 (라벤더 화이트)
	clrBgBottom   = rgb(219, 225, 245) // 배경 그라데이션 하단
	clrCardFill   = rgb(255, 255, 255) // 유리 카드 채움색 (알파 블렌드됨)
	clrCardBorder = rgb(255, 255, 255) // 카드 상단 하이라이트 보더
	clrCardStroke = rgb(224, 229, 245) // 카드 얇은 외곽선
	clrShadow     = rgb(96, 110, 150)  // 소프트 섀도우 베이스색

	clrTitle  = rgb(30, 35, 55)    // 타이틀 텍스트
	clrLabel  = rgb(52, 61, 82)    // 섹션 라벨
	clrHint   = rgb(133, 141, 163) // 보조 설명 텍스트
	clrFooter = rgb(150, 157, 178) // 하단 푸터 텍스트

	clrPrimary      = rgb(90, 99, 235) // 인디고 - 주요 액션
	clrPrimaryHover = rgb(74, 82, 219)
	clrPrimaryPress = rgb(60, 68, 196)
	clrPrimary2     = rgb(158, 92, 232) // 그라데이션 보조색 (보라)

	clrDanger      = rgb(235, 87, 96)
	clrDangerHover = rgb(220, 68, 78)

	clrNeutral       = rgb(255, 255, 255)
	clrNeutralHover  = rgb(238, 240, 250)
	clrNeutralText   = rgb(63, 71, 92)
	clrNeutralBorder = rgb(221, 226, 242)

	clrInputBg     = rgb(255, 255, 255)
	clrInputText   = rgb(44, 51, 70)
	clrInputBorder = rgb(221, 226, 244)

	clrLogBg     = rgb(35, 39, 58)
	clrLogText   = rgb(198, 214, 230)
	clrLogBorder = rgb(58, 63, 88)

	clrToggleOffTrack = rgb(214, 219, 238)
	clrToggleOnTrack  = rgb(90, 99, 235)
	clrToggleKnob     = rgb(255, 255, 255)

	clrTrackBg = rgb(224, 228, 244)

	clrTitleBarTop = rgb(90, 99, 235)
	clrTitleBarBot = rgb(126, 99, 224)
)

// ============================================================
// 전역 상태
// ============================================================

type controls struct {
	main, url, folder, browse, format, quality uintptr
	playlist, subtitle, ssl, start, cancel     uintptr
	open, update                               uintptr
	progress, status, log                      uintptr
	minBtn, closeBtn                           uintptr

	font      uintptr // 본문 폰트 (Malgun Gothic 10pt)
	fontBold  uintptr // 섹션 라벨/버튼 (세미볼드)
	fontTitle uintptr // 타이틀 (세미볼드 14pt)
	fontSmall uintptr // 보조설명 (9pt)
	fontMono  uintptr // 로그창 (Consolas)
}

var ui controls

var brushBG, brushEdit, brushLog uintptr

var running atomic.Bool
var cancelMu sync.Mutex
var cancelCurrent context.CancelFunc

var progressRE = regexp.MustCompile(`([0-9]+(?:\.[0-9]+)?)%`)

type uiUpdate struct {
	kind  string
	text  string
	value int
	ok    bool
}

var updates = make(chan uiUpdate, 500)

// 토글 스위치(재생목록/자막/SSL) 상태 - 오너드로우 버튼이라 직접 관리
var toggleState = map[uintptr]bool{}

// 오너드로우 버튼 hover 상태 (서브클래싱으로 갱신)
var hoverState = map[uintptr]bool{}

// 서브클래싱 원본 WndProc 보관
var origProc = map[uintptr]uintptr{}

var currentProgressPct int32

// ============================================================
// 기본 유틸리티
// ============================================================

func utf16Ptr(s string) *uint16 {
	p, _ := syscall.UTF16PtrFromString(s)
	return p
}

func loword(v uintptr) uint16 { return uint16(v & 0xffff) }
func hiword(v uintptr) uint16 { return uint16((v >> 16) & 0xffff) }

func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

func setText(hwnd uintptr, s string) {
	procSetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(utf16Ptr(s))))
}

func getText(hwnd uintptr) string {
	n, _, _ := procGetWindowTextLengthW.Call(hwnd)
	buf := make([]uint16, n+1)
	procGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}

func send(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	r, _, _ := procSendMessageW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func messageBox(hwnd uintptr, text, title string, flags uint32) int {
	r, _, _ := procMessageBoxW.Call(hwnd, uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(unsafe.Pointer(utf16Ptr(title))), uintptr(flags))
	return int(r)
}

func createControl(class, text string, style uint32, x, y, w, h int32, parent uintptr, id int) uintptr {
	handle, _, _ := procCreateWindowExW.Call(
		0,
		uintptr(unsafe.Pointer(utf16Ptr(class))),
		uintptr(unsafe.Pointer(utf16Ptr(text))),
		uintptr(style),
		uintptr(x), uintptr(y), uintptr(w), uintptr(h),
		parent,
		uintptr(id),
		0,
		0,
	)
	if handle != 0 && ui.font != 0 {
		send(handle, WM_SETFONT, ui.font, 1)
	}
	return handle
}

func addComboItem(hwnd uintptr, text string) {
	send(hwnd, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16Ptr(text))))
}

func appendLog(text string) {
	if text == "" {
		return
	}
	if !strings.HasSuffix(text, "\r\n") {
		text += "\r\n"
	}
	send(ui.log, EM_SETSEL, ^uintptr(0), ^uintptr(0))
	send(ui.log, EM_REPLACESEL, 0, uintptr(unsafe.Pointer(utf16Ptr(text))))
	send(ui.log, EM_SETSEL, ^uintptr(0), ^uintptr(0))
	send(ui.log, EM_SCROLLCARET, 0, 0)
}

func userLog(text string) {
	appendLog(time.Now().Format("15:04:05") + "  " + text)
}

func enable(hwnd uintptr, yes bool) {
	var v uintptr
	if yes {
		v = 1
	}
	procEnableWindow.Call(hwnd, v)
	invalidate(hwnd)
}

func invalidate(hwnd uintptr) {
	procInvalidateRect.Call(hwnd, 0, 1)
	procUpdateWindow.Call(hwnd)
}

func setStatusText(text string) {
	setText(ui.status, text)
	invalidate(ui.status)
}

func setProgressPercent(pct int) {
	if pct < 0 {
		pct = 0
	}
	if pct > 100 {
		pct = 100
	}
	atomic.StoreInt32(&currentProgressPct, int32(pct))
	invalidate(ui.progress)
}

func setRunningState(on bool) {
	running.Store(on)
	enable(ui.start, !on)
	enable(ui.update, !on)
	enable(ui.url, !on)
	enable(ui.folder, !on)
	enable(ui.browse, !on)
	enable(ui.format, !on)
	if !on {
		idx := int(send(ui.format, CB_GETCURSEL, 0, 0))
		enable(ui.quality, idx == 0)
	} else {
		enable(ui.quality, false)
	}
	enable(ui.playlist, !on)
	enable(ui.subtitle, !on)
	enable(ui.ssl, !on)
	enable(ui.cancel, on)
}

func drainUpdates() {
	for {
		select {
		case u := <-updates:
			switch u.kind {
			case "status":
				setStatusText(u.text)
			case "log":
				userLog(u.text)
			case "progress":
				setProgressPercent(u.value)
			case "done":
				setRunningState(false)
				if u.ok {
					setProgressPercent(100)
					setStatusText(u.text)
					messageBox(ui.main, u.text, appTitle, MB_OK|MB_ICONINFORMATION)
				} else {
					setStatusText(u.text)
					messageBox(ui.main, u.text, appTitle, MB_OK|MB_ICONERROR)
				}
			case "donewarn":
				setRunningState(false)
				setStatusText(u.text)
				messageBox(ui.main, u.text, appTitle, MB_OK|MB_ICONWARNING)
			case "cancelled":
				setRunningState(false)
				setStatusText("작업이 취소되었습니다.")
				userLog("[취소] 사용자가 작업을 중단했습니다.")
			}
		default:
			return
		}
	}
}

// ============================================================
// GDI 저수준 헬퍼
// ============================================================

const (
	DT_LEFT         = 0x00000000
	DT_CENTER       = 0x00000001
	DT_RIGHT        = 0x00000002
	DT_VCENTER      = 0x00000004
	DT_SINGLELINE   = 0x00000020
	DT_WORDBREAK    = 0x00000010
	DT_NOCLIP       = 0x00000100
	DT_END_ELLIPSIS = 0x00008000

	PS_SOLID   = 0
	NULL_PEN   = 8
	NULL_BRUSH = 5

	TRANSPARENT_BK = 1

	GRADIENT_FILL_RECT_H = 0x00000000
	GRADIENT_FILL_RECT_V = 0x00000001
)

func createPen(width int32, color uintptr) uintptr {
	h, _, _ := procCreatePen.Call(PS_SOLID, uintptr(width), color)
	return h
}

func createBrush(color uintptr) uintptr {
	h, _, _ := procCreateSolidBrush.Call(color)
	return h
}

func selectObj(hdc, obj uintptr) uintptr {
	old, _, _ := procSelectObject.Call(hdc, obj)
	return old
}

func deleteObj(obj uintptr) {
	if obj != 0 {
		procDeleteObject.Call(obj)
	}
}

func roundRect(hdc uintptr, l, t, r, b, rw, rh int32) {
	procRoundRect.Call(hdc, uintptr(l), uintptr(t), uintptr(r), uintptr(b), uintptr(rw), uintptr(rh))
}

func fillRoundRect(hdc uintptr, l, t, r, b, radius int32, fillColor uintptr) {
	brush := createBrush(fillColor)
	pen := createPen(1, fillColor)
	oldB := selectObj(hdc, brush)
	oldP := selectObj(hdc, pen)
	roundRect(hdc, l, t, r, b, radius, radius)
	selectObj(hdc, oldB)
	selectObj(hdc, oldP)
	deleteObj(brush)
	deleteObj(pen)
}

func strokeRoundRect(hdc uintptr, l, t, r, b, radius int32, strokeColor uintptr, width int32) {
	pen := createPen(width, strokeColor)
	nullBrush, _, _ := procGetStockObject.Call(NULL_BRUSH)
	oldB := selectObj(hdc, nullBrush)
	oldP := selectObj(hdc, pen)
	roundRect(hdc, l, t, r, b, radius, radius)
	selectObj(hdc, oldB)
	selectObj(hdc, oldP)
	deleteObj(pen)
}

func fillEllipse(hdc uintptr, l, t, r, b int32, fillColor uintptr) {
	brush := createBrush(fillColor)
	pen := createPen(1, fillColor)
	oldB := selectObj(hdc, brush)
	oldP := selectObj(hdc, pen)
	procEllipse.Call(hdc, uintptr(l), uintptr(t), uintptr(r), uintptr(b))
	selectObj(hdc, oldB)
	selectObj(hdc, oldP)
	deleteObj(brush)
	deleteObj(pen)
}

func fillRectSolid(hdc uintptr, l, t, r, b int32, color uintptr) {
	brush := createBrush(color)
	rc := RECT{l, t, r, b}
	procFillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), brush)
	deleteObj(brush)
}

// drawText: 반투명 배경 위에 텍스트를 그린다 (배경모드 투명)
func drawText(hdc uintptr, text string, x, y, w, h int32, color uintptr, font uintptr, format uint32) {
	if font != 0 {
		selectObj(hdc, font)
	}
	procSetBkMode.Call(hdc, TRANSPARENT_BK)
	procSetTextColor.Call(hdc, color)
	rc := RECT{x, y, x + w, y + h}
	p := utf16Ptr(text)
	procDrawTextW.Call(hdc, uintptr(unsafe.Pointer(p)), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), uintptr(format))
}

// verticalGradient: 세로 방향 2색 그라데이션 채우기 (그라데이션 미지원 환경 대비 단색 대체 포함)
func verticalGradient(hdc uintptr, l, t, r, b int32, top, bottom uintptr) {
	verts := [2]TRIVERTEX{
		{X: l, Y: t, Red: colorChannel16(top, 0), Green: colorChannel16(top, 1), Blue: colorChannel16(top, 2), Alpha: 0},
		{X: r, Y: b, Red: colorChannel16(bottom, 0), Green: colorChannel16(bottom, 1), Blue: colorChannel16(bottom, 2), Alpha: 0},
	}
	mesh := GRADIENTRECT{UpperLeft: 0, LowerRight: 1}
	ok, _, _ := procGradientFill.Call(hdc, uintptr(unsafe.Pointer(&verts[0])), 2, uintptr(unsafe.Pointer(&mesh)), 1, GRADIENT_FILL_RECT_V)
	if ok == 0 {
		// 일부 사내망 PC/원격 데스크톱 환경은 GDI 그라데이션을 지원하지 않아 아무것도 그려지지 않을 수 있다.
		// 이 경우 두 색의 중간값으로 단색 채움 처리해 최소한 항상 보이도록 한다.
		fillRectSolid(hdc, l, t, r, b, blendColor(top, bottom))
	}
}

// horizontalGradient: 가로 방향 2색 그라데이션 채우기 (그라데이션 미지원 환경 대비 단색 대체 포함)
func horizontalGradient(hdc uintptr, l, t, r, b int32, left, right uintptr) {
	verts := [2]TRIVERTEX{
		{X: l, Y: t, Red: colorChannel16(left, 0), Green: colorChannel16(left, 1), Blue: colorChannel16(left, 2), Alpha: 0},
		{X: r, Y: b, Red: colorChannel16(right, 0), Green: colorChannel16(right, 1), Blue: colorChannel16(right, 2), Alpha: 0},
	}
	mesh := GRADIENTRECT{UpperLeft: 0, LowerRight: 1}
	ok, _, _ := procGradientFill.Call(hdc, uintptr(unsafe.Pointer(&verts[0])), 2, uintptr(unsafe.Pointer(&mesh)), 1, GRADIENT_FILL_RECT_H)
	if ok == 0 {
		fillRectSolid(hdc, l, t, r, b, blendColor(left, right))
	}
}

// blendColor: 두 COLORREF의 평균색을 계산한다 (그라데이션 대체용)
func blendColor(a, b uintptr) uintptr {
	ar, ag, ab := byte(a), byte(a>>8), byte(a>>16)
	br, bg, bb := byte(b), byte(b>>8), byte(b>>16)
	return rgb(byte((int(ar)+int(br))/2), byte((int(ag)+int(bg))/2), byte((int(ab)+int(bb))/2))
}

func colorChannel16(colorref uintptr, idx int) uint16 {
	b := byte(colorref >> (uintptr(idx) * 8))
	return uint16(b) << 8
}

// blendBlit: 메모리 DC의 내용을 지정한 상수 알파값으로 대상 DC에 블렌딩한다
func blendBlit(destDC uintptr, x, y, w, h int32, srcDC uintptr, alpha byte) {
	blend := uintptr(AC_SRC_OVER) | uintptr(0)<<8 | uintptr(alpha)<<16 | uintptr(0)<<24
	procAlphaBlend.Call(destDC, uintptr(x), uintptr(y), uintptr(w), uintptr(h), srcDC, 0, 0, uintptr(w), uintptr(h), blend)
}

// makeSolidMemDC: 지정 크기의 단색 메모리 비트맵 DC를 만든다 (호출자가 정리해야 함)
func makeSolidMemDC(refDC uintptr, w, h int32, color uintptr) (uintptr, uintptr) {
	memDC, _, _ := procCreateCompatibleDC.Call(refDC)
	bmp, _, _ := procCreateCompatibleBitmap.Call(refDC, uintptr(w), uintptr(h))
	old := selectObj(memDC, bmp)
	_ = old
	fillRectSolid(memDC, 0, 0, w, h, color)
	return memDC, bmp
}

// softShadow: 카드 아래에 은은한 그림자를 여러 겹으로 흉내낸다
func softShadow(hdc uintptr, x, y, w, h, radius int32) {
	layers := []struct {
		expand int32
		alpha  byte
	}{
		{6, 10}, {4, 14}, {2, 18},
	}
	for _, ly := range layers {
		l := x - ly.expand
		t := y - ly.expand + 4
		r := x + w + ly.expand
		b := y + h + ly.expand + 4
		memDC, bmp := makeSolidMemDC(hdc, r-l, b-t, clrShadow)
		rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(r-l), uintptr(b-t), uintptr(radius+ly.expand), uintptr(radius+ly.expand))
		procSelectClipRgn.Call(memDC, rgn)
		fillRectSolid(memDC, 0, 0, r-l, b-t, clrShadow)
		procSelectClipRgn.Call(memDC, 0)
		deleteObj(rgn)
		blendBlit(hdc, l, t, r-l, b-t, memDC, ly.alpha)
		procDeleteDC.Call(memDC)
		deleteObj(bmp)
	}
}

// glassCard: 반투명 유리 카드 패널을 그린다 (그림자 + 반투명 채움 + 얇은 외곽선)
func glassCard(hdc uintptr, x, y, w, h, radius int32, alpha byte) {
	softShadow(hdc, x, y, w, h, radius)
	memDC, bmp := makeSolidMemDC(hdc, w, h, clrCardFill)
	rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(w), uintptr(h), uintptr(radius), uintptr(radius))
	dstRgn, _, _ := procCreateRoundRectRgn.Call(uintptr(x), uintptr(y), uintptr(x+w), uintptr(y+h), uintptr(radius), uintptr(radius))
	_ = rgn
	procSelectClipRgn.Call(hdc, dstRgn)
	blendBlit(hdc, x, y, w, h, memDC, alpha)
	procSelectClipRgn.Call(hdc, 0)
	deleteObj(dstRgn)
	deleteObj(rgn)
	procDeleteDC.Call(memDC)
	deleteObj(bmp)
	strokeRoundRect(hdc, x, y, x+w, y+h, radius, clrCardStroke, 1)
}

// ============================================================
// 오너드로우 컨트롤 렌더링
// ============================================================

type btnKind int

const (
	btnPrimary btnKind = iota
	btnDanger
	btnNeutral
	btnTitleGlyph
)

var buttonKind = map[uintptr]btnKind{}
var buttonLabel = map[uintptr]string{}

// 카드 위에 놓이는 오너드로우 컨트롤은 WS_CLIPCHILDREN 때문에 부모가 그 영역을
// 실제로 칠하지 않으므로, 라운드 모서리 바깥을 채울 배경색을 미리 지정해둔다.
var controlBackdrop = map[uintptr]uintptr{}

const backdropCard = uintptr(0xFFFFFFFF)     // 표식: 카드(유리 패널) 위
const backdropTitleBar = uintptr(0xFFFFFFFE) // 표식: 타이틀 바 위

func backdropColorFor(hwnd uintptr) uintptr {
	c, ok := controlBackdrop[hwnd]
	if !ok {
		return rgb(240, 242, 251) // 기본값: 카드 근사색
	}
	switch c {
	case backdropCard:
		return rgb(246, 248, 253)
	case backdropTitleBar:
		return rgb(112, 103, 231)
	default:
		return c
	}
}

func registerButton(hwnd uintptr, kind btnKind, label string) {
	buttonKind[hwnd] = kind
	buttonLabel[hwnd] = label
	controlBackdrop[hwnd] = backdropCard
	subclassForHover(hwnd)
}

// subclassForHover: 표준 버튼 윈도우를 서브클래싱해서 마우스 hover 상태를 추적한다
func subclassForHover(hwnd uintptr) {
	cb := syscall.NewCallback(hoverSubclassProc)
	idx := int32(GWLP_WNDPROC)
	old, _, _ := procSetWindowLongPtrW.Call(hwnd, uintptr(idx), cb)
	origProc[hwnd] = old
}

func hoverSubclassProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_MOUSEMOVE:
		if !hoverState[hwnd] {
			hoverState[hwnd] = true
			invalidate(hwnd)
			tme := TRACKMOUSEEVENT{DwFlags: TME_LEAVE, HwndTrack: hwnd}
			tme.CbSize = uint32(unsafe.Sizeof(tme))
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&tme)))
		}
	case WM_MOUSELEAVE:
		hoverState[hwnd] = false
		invalidate(hwnd)
	}
	old := origProc[hwnd]
	r, _, _ := procCallWindowProcW.Call(old, hwnd, uintptr(msg), wParam, lParam)
	return r
}

// drawOwnerButton: WM_DRAWITEM에서 호출되어 일반 버튼(시작/취소/폴더선택 등)을 커스텀 렌더링한다
func drawOwnerButton(dis *DRAWITEMSTRUCT) {
	hdc := dis.Hdc
	l, t, r, b := dis.RcItem.Left, dis.RcItem.Top, dis.RcItem.Right, dis.RcItem.Bottom
	w, h := r-l, b-t
	kind := buttonKind[dis.HwndItem]
	label := buttonLabel[dis.HwndItem]
	pressed := dis.ItemState&ODS_SELECTED != 0
	disabled := dis.ItemState&ODS_DISABLED != 0
	hovered := hoverState[dis.HwndItem]

	memDC, _, _ := procCreateCompatibleDC.Call(hdc)
	bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
	old := selectObj(memDC, bmp)

	// 라운드 모서리 바깥쪽을 주변과 자연스럽게 잇기 위한 배경색 채우기
	fillRectSolid(memDC, 0, 0, w, h, backdropColorFor(dis.HwndItem))

	radius := int32(12)
	switch kind {
	case btnPrimary:
		top, bot := clrPrimary, clrPrimary2
		if disabled {
			top, bot = rgb(200, 204, 224), rgb(200, 204, 224)
		} else if pressed {
			top, bot = clrPrimaryPress, clrPrimaryPress
		} else if hovered {
			top, bot = clrPrimaryHover, clrPrimary2
		}
		rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(w), uintptr(h), uintptr(radius), uintptr(radius))
		procSelectClipRgn.Call(memDC, rgn)
		horizontalGradient(memDC, 0, 0, w, h, top, bot)
		procSelectClipRgn.Call(memDC, 0)
		deleteObj(rgn)
		txtColor := rgb(255, 255, 255)
		drawText(memDC, label, 0, 0, w, h, txtColor, ui.fontBold, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	case btnDanger:
		fill := rgb(255, 255, 255)
		stroke := clrDanger
		txt := clrDanger
		if disabled {
			stroke = rgb(220, 224, 238)
			txt = rgb(190, 195, 212)
		} else if pressed {
			fill = rgb(252, 232, 233)
		} else if hovered {
			fill = rgb(254, 242, 243)
			stroke = clrDangerHover
		}
		fillRoundRect(memDC, 0, 0, w, h, radius, fill)
		strokeRoundRect(memDC, 0, 0, w, h, radius, stroke, 2)
		drawText(memDC, label, 0, 0, w, h, txt, ui.fontBold, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	default: // btnNeutral
		fill := clrNeutral
		txt := clrNeutralText
		border := clrNeutralBorder
		if disabled {
			fill = rgb(240, 242, 250)
			txt = rgb(180, 186, 205)
		} else if pressed {
			fill = rgb(224, 228, 246)
			border = clrPrimary
		} else if hovered {
			fill = clrNeutralHover
			border = rgb(196, 203, 232)
		}
		fillRoundRect(memDC, 0, 0, w, h, radius, fill)
		strokeRoundRect(memDC, 0, 0, w, h, radius, border, 1)
		drawText(memDC, label, 0, 0, w, h, txt, ui.fontBold, DT_CENTER|DT_VCENTER|DT_SINGLELINE)
	}

	procBitBlt.Call(hdc, uintptr(l), uintptr(t), uintptr(w), uintptr(h), memDC, 0, 0, 0x00CC0020)
	selectObj(memDC, old)
	procDeleteDC.Call(memDC)
	deleteObj(bmp)
}

// 토글 스위치 라벨/설명
var toggleLabel = map[uintptr]string{}
var toggleHint = map[uintptr]string{}

func registerToggle(hwnd uintptr, label, hint string) {
	toggleLabel[hwnd] = label
	toggleHint[hwnd] = hint
	toggleState[hwnd] = false
	controlBackdrop[hwnd] = backdropCard
	subclassForHover(hwnd)
}

// drawOwnerToggle: 재생목록/자막/SSL 옵션을 뉴모피즘 토글 스위치로 렌더링한다
func drawOwnerToggle(dis *DRAWITEMSTRUCT) {
	hdc := dis.Hdc
	l, t, r, b := dis.RcItem.Left, dis.RcItem.Top, dis.RcItem.Right, dis.RcItem.Bottom
	w, h := r-l, b-t
	on := toggleState[dis.HwndItem]
	disabled := dis.ItemState&ODS_DISABLED != 0
	label := toggleLabel[dis.HwndItem]
	hint := toggleHint[dis.HwndItem]

	memDC, _, _ := procCreateCompatibleDC.Call(hdc)
	bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
	old := selectObj(memDC, bmp)
	fillRectSolid(memDC, 0, 0, w, h, backdropColorFor(dis.HwndItem))

	swW, swH := int32(40), int32(22)
	swX, swY := int32(0), (h-swH)/2
	track := clrToggleOffTrack
	if on {
		track = clrToggleOnTrack
	}
	if disabled {
		track = rgb(230, 233, 244)
	}
	fillRoundRect(memDC, swX, swY, swX+swW, swY+swH, swH, track)
	knobD := swH - 6
	knobX := swX + 3
	if on {
		knobX = swX + swW - knobD - 3
	}
	fillEllipse(memDC, knobX, swY+3, knobX+knobD, swY+3+knobD, clrToggleKnob)

	txtColor := clrLabel
	hintColor := clrHint
	if disabled {
		txtColor = rgb(180, 186, 205)
		hintColor = rgb(200, 204, 220)
	}
	tx := swX + swW + 12
	if hint == "" {
		drawText(memDC, label, tx, 0, w-tx, h, txtColor, ui.font, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	} else {
		drawText(memDC, label, tx, 0, w-tx, h/2+2, txtColor, ui.font, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
		drawText(memDC, hint, tx, h/2, w-tx, h/2, hintColor, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	}

	procBitBlt.Call(hdc, uintptr(l), uintptr(t), uintptr(w), uintptr(h), memDC, 0, 0, 0x00CC0020)
	selectObj(memDC, old)
	procDeleteDC.Call(memDC)
	deleteObj(bmp)
}

// drawOwnerStatus: 상태 표시줄을 색상 코드가 있는 알약(pill) 형태로 렌더링한다
func drawOwnerStatus(dis *DRAWITEMSTRUCT) {
	hdc := dis.Hdc
	l, t, r, b := dis.RcItem.Left, dis.RcItem.Top, dis.RcItem.Right, dis.RcItem.Bottom
	w, h := r-l, b-t
	text := getText(dis.HwndItem)

	memDC, _, _ := procCreateCompatibleDC.Call(hdc)
	bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
	old := selectObj(memDC, bmp)
	fillRectSolid(memDC, 0, 0, w, h, backdropColorFor(dis.HwndItem))

	dotColor := rgb(150, 158, 180)
	switch {
	case strings.Contains(text, "실패") || strings.Contains(text, "오류"):
		dotColor = clrDanger
	case strings.Contains(text, "완료"):
		dotColor = rgb(52, 178, 122)
	case strings.Contains(text, "취소"):
		dotColor = rgb(214, 158, 46)
	case running.Load():
		dotColor = clrPrimary
	}
	dotSize := int32(10)
	dotY := (h - dotSize) / 2
	fillEllipse(memDC, 0, dotY, dotSize, dotY+dotSize, dotColor)
	drawText(memDC, text, dotSize+10, 0, w-dotSize-10, h, clrLabel, ui.fontBold, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS)

	procBitBlt.Call(hdc, uintptr(l), uintptr(t), uintptr(w), uintptr(h), memDC, 0, 0, 0x00CC0020)
	selectObj(memDC, old)
	procDeleteDC.Call(memDC)
	deleteObj(bmp)
}

// drawTitleBarButton: 최소화/닫기 버튼 (원형 아이콘)
func drawTitleBarButton(dis *DRAWITEMSTRUCT) {
	hdc := dis.Hdc
	l, t, r, b := dis.RcItem.Left, dis.RcItem.Top, dis.RcItem.Right, dis.RcItem.Bottom
	w, h := r-l, b-t
	hovered := hoverState[dis.HwndItem]
	isClose := dis.HwndItem == ui.closeBtn

	memDC, _, _ := procCreateCompatibleDC.Call(hdc)
	bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
	old := selectObj(memDC, bmp)
	fillRectSolid(memDC, 0, 0, w, h, rgb(112, 103, 231))

	if hovered {
		bg := rgb(255, 255, 255)
		if isClose {
			bg = rgb(232, 92, 100)
		}
		fillEllipse(memDC, 2, 2, w-2, h-2, bg)
	}
	symColor := rgb(255, 255, 255)
	cx, cy := w/2, h/2
	if isClose {
		penColor := createPen(2, symColor)
		oldP := selectObj(memDC, penColor)
		drawLine(memDC, cx-5, cy-5, cx+5, cy+5)
		drawLine(memDC, cx-5, cy+5, cx+5, cy-5)
		selectObj(memDC, oldP)
		deleteObj(penColor)
	} else {
		penColor := createPen(2, symColor)
		oldP := selectObj(memDC, penColor)
		drawLine(memDC, cx-5, cy, cx+5, cy)
		selectObj(memDC, oldP)
		deleteObj(penColor)
	}

	procBitBlt.Call(hdc, uintptr(l), uintptr(t), uintptr(w), uintptr(h), memDC, 0, 0, 0x00CC0020)
	selectObj(memDC, old)
	procDeleteDC.Call(memDC)
	deleteObj(bmp)
}

var procMoveToEx = gdi32.NewProc("MoveToEx")
var procLineTo = gdi32.NewProc("LineTo")

func drawLine(hdc uintptr, x1, y1, x2, y2 int32) {
	procMoveToEx.Call(hdc, uintptr(x1), uintptr(y1), 0)
	procLineTo.Call(hdc, uintptr(x2), uintptr(y2))
}

// ============================================================
// 커스텀 진행률 바 컨트롤 (별도 윈도우 클래스)
// ============================================================

const progressClassName = "HJWProgressCtl"

func registerProgressClass(hInstance uintptr) {
	cursor, _, _ := procLoadCursorW.Call(0, IDC_ARROW)
	wc := WNDCLASSEX{
		CbSize:        uint32(unsafe.Sizeof(WNDCLASSEX{})),
		LpfnWndProc:   syscall.NewCallback(progressWndProc),
		HInstance:     hInstance,
		HCursor:       cursor,
		HbrBackground: 0,
		LpszClassName: utf16Ptr(progressClassName),
	}
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))
}

func progressWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		var ps PAINTSTRUCT
		hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		w, h := rc.Right-rc.Left, rc.Bottom-rc.Top

		memDC, _, _ := procCreateCompatibleDC.Call(hdc)
		bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
		old := selectObj(memDC, bmp)
		fillRectSolid(memDC, 0, 0, w, h, rgb(246, 248, 253))

		radius := h
		fillRoundRect(memDC, 0, 0, w, h, radius, clrTrackBg)
		pct := int(atomic.LoadInt32(&currentProgressPct))
		fillW := int32(float64(w) * float64(pct) / 100.0)
		if fillW > 4 {
			rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(w), uintptr(h), uintptr(radius), uintptr(radius))
			procSelectClipRgn.Call(memDC, rgn)
			horizontalGradient(memDC, 0, 0, fillW, h, clrPrimary, clrPrimary2)
			procSelectClipRgn.Call(memDC, 0)
			deleteObj(rgn)
		}
		label := fmt.Sprintf("%d%%", pct)
		txtColor := clrLabel
		if fillW > w-30 {
			txtColor = rgb(255, 255, 255)
		}
		drawText(memDC, label, 0, 0, w-10, h, txtColor, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)

		procBitBlt.Call(hdc, 0, 0, uintptr(w), uintptr(h), memDC, 0, 0, 0x00CC0020)
		selectObj(memDC, old)
		procDeleteDC.Call(memDC)
		deleteObj(bmp)
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

// ============================================================
// 메인 창 배경(그라데이션/카드/텍스트) 렌더링
// ============================================================

type layout struct {
	winW, winH                        int32
	titleBarH                         int32
	pad                               int32
	cardA, cardB, cardC, cardD, cardE RECT
	btnRow                            RECT
}

var L layout

func computeLayout() {
	L.winW = 900
	L.winH = 900
	L.titleBarH = 56
	L.pad = 24
	x := L.pad
	w := L.winW - L.pad*2
	y := L.titleBarH + 16

	L.cardA = RECT{x, y, x + w, y + 158}
	y = L.cardA.Bottom + 14

	L.cardB = RECT{x, y, x + w, y + 84}
	y = L.cardB.Bottom + 14

	L.cardC = RECT{x, y, x + w, y + 186}
	y = L.cardC.Bottom + 16

	L.btnRow = RECT{x, y, x + w, y + 52}
	y = L.btnRow.Bottom + 16

	L.cardD = RECT{x, y, x + w, y + 92}
	y = L.cardD.Bottom + 14

	L.cardE = RECT{x, y, x + w, y + 150}
	y = L.cardE.Bottom + 44

	L.winH = y
}

func paintMainBackground(hdc uintptr, w, h int32) {
	// 전체 배경 라벤더 그라데이션
	verticalGradient(hdc, 0, 0, w, h, clrBgTop, clrBgBottom)

	// 타이틀 바 (인디고 -> 보라 그라데이션)
	horizontalGradient(hdc, 0, 0, w, L.titleBarH, clrTitleBarTop, clrTitleBarBot)
	drawText(hdc, appTitle, 24, 0, 500, L.titleBarH, rgb(255, 255, 255), ui.fontTitle, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	// 카드들 (유리 패널)
	glassCard(hdc, L.cardA.Left, L.cardA.Top, L.cardA.Right-L.cardA.Left, L.cardA.Bottom-L.cardA.Top, 18, 176)
	glassCard(hdc, L.cardB.Left, L.cardB.Top, L.cardB.Right-L.cardB.Left, L.cardB.Bottom-L.cardB.Top, 18, 176)
	glassCard(hdc, L.cardC.Left, L.cardC.Top, L.cardC.Right-L.cardC.Left, L.cardC.Bottom-L.cardC.Top, 18, 176)
	glassCard(hdc, L.cardD.Left, L.cardD.Top, L.cardD.Right-L.cardD.Left, L.cardD.Bottom-L.cardD.Top, 18, 176)
	glassCard(hdc, L.cardE.Left, L.cardE.Top, L.cardE.Right-L.cardE.Left, L.cardE.Bottom-L.cardE.Top, 18, 200)

	pad := int32(24)

	// 카드A: 링크 입력
	drawText(hdc, "1 · 링크 입력", L.cardA.Left+pad, L.cardA.Top+14, 300, 22, clrLabel, ui.fontBold, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, "여러 개는 한 줄에 하나씩 입력하세요.", L.cardA.Left+pad, L.cardA.Top+38, 500, 20, clrHint, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	// 카드B: 저장 위치
	drawText(hdc, "2 · 저장 위치", L.cardB.Left+pad, L.cardB.Top+14, 300, 22, clrLabel, ui.fontBold, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	// 카드C: 다운로드 설정
	drawText(hdc, "3 · 다운로드 설정", L.cardC.Left+pad, L.cardC.Top+14, 300, 22, clrLabel, ui.fontBold, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, "형식", L.cardC.Left+pad, L.cardC.Top+42, 120, 20, clrHint, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, "화질", L.cardC.Left+pad+206, L.cardC.Top+42, 120, 20, clrHint, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	// 카드D: 진행 상황
	drawText(hdc, "진행 상황", L.cardD.Left+pad, L.cardD.Top+12, 300, 20, clrLabel, ui.fontBold, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	// 카드E: 작업 로그
	drawText(hdc, "작업 로그", L.cardE.Left+pad, L.cardE.Top+14, 300, 20, clrLabel, ui.fontBold, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, "필요한 내용만 순서대로 표시되며 자동으로 아래로 이동합니다.", L.cardE.Left+pad+96, L.cardE.Top+14, 500, 20, clrHint, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)

	// 푸터
	footerY := L.cardE.Bottom + 12
	drawText(hdc, "다운로드 권한이 있는 영상에만 사용하십시오.", L.cardE.Left, footerY, 420, 20, clrFooter, ui.fontSmall, DT_LEFT|DT_VCENTER|DT_SINGLELINE)
	drawText(hdc, "제작자 하정욱  ·  업데이트 "+buildDate, L.cardE.Right-320, footerY, 320, 20, clrFooter, ui.fontSmall, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)
}

// ============================================================
// 컨트롤 생성 (레이아웃 배치)
// ============================================================

func installedFontFace() string {
	// 한글 글꼴 파일명과 실제 Windows font face 이름이 다른 경우가 있어
	// 자동 감지는 사용하지 않는다. 모든 한국어 Windows에 기본 포함된
	// 맑은 고딕(Malgun Gothic)을 고정 사용한다.
	return "Malgun Gothic"
}

func makeFont(height int32, weight uint32, face string) uintptr {
	h, _, _ := procCreateFontW.Call(
		uintptr(height), 0, 0, 0, uintptr(weight), 0, 0, 0,
		129, 0, 0, 5, 0, uintptr(unsafe.Pointer(utf16Ptr(face))),
	)
	return h
}

func ownerDrawButton(text string, x, y, w, h int32, parent uintptr, id int) uintptr {
	hwnd := createControl("BUTTON", text, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, x, y, w, h, parent, id)
	return hwnd
}

func createUI(hwnd uintptr) {
	face := installedFontFace()
	ui.font = makeFont(-13, 400, face)
	ui.fontBold = makeFont(-14, 600, face)
	ui.fontTitle = makeFont(-19, 600, face)
	ui.fontSmall = makeFont(-12, 400, face)
	ui.fontMono = makeFont(-13, 400, "Consolas")

	computeLayout()

	// ---- 타이틀 바 버튼 (최소화 / 닫기) ----
	ui.minBtn = createControl("BUTTON", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, L.winW-76, 12, 32, 32, hwnd, ID_MINBTN)
	ui.closeBtn = createControl("BUTTON", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, L.winW-40, 12, 32, 32, hwnd, ID_CLOSEBTN)
	subclassForHover(ui.minBtn)
	subclassForHover(ui.closeBtn)

	// ---- 카드 A: 링크 입력 ----
	urlX, urlY := L.cardA.Left+24, L.cardA.Top+64
	urlW, urlH := (L.cardA.Right-L.cardA.Left)-48, (L.cardA.Bottom-L.cardA.Top)-64-16
	ui.url = createControl("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_LEFT|ES_MULTILINE|ES_AUTOVSCROLL|ES_WANTRETURN|WS_VSCROLL, urlX, urlY, urlW, urlH, hwnd, ID_URL)

	// ---- 카드 B: 저장 위치 ----
	folderY := L.cardB.Top + 40
	browseW := int32(140)
	folderW := (L.cardB.Right - L.cardB.Left) - 48 - browseW - 12
	defaultFolder := filepath.Join(userHomeDir(), "Downloads", "YouTube")
	ui.folder = createControl("EDIT", defaultFolder, WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_LEFT, L.cardB.Left+24, folderY, folderW, 34, hwnd, ID_FOLDER)
	ui.browse = ownerDrawButton("폴더 선택", L.cardB.Left+24+folderW+12, folderY, browseW, 34, hwnd, ID_BROWSE)
	registerButton(ui.browse, btnNeutral, "폴더 선택")

	// ---- 카드 C: 다운로드 설정 ----
	comboY := L.cardC.Top + 64
	ui.format = createControl("COMBOBOX", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST, L.cardC.Left+24, comboY, 190, 140, hwnd, ID_FORMAT)
	addComboItem(ui.format, "영상 (MP4)")
	addComboItem(ui.format, "음원 (MP3)")
	send(ui.format, CB_SETCURSEL, 0, 0)

	ui.quality = createControl("COMBOBOX", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST, L.cardC.Left+24+206, comboY, 170, 220, hwnd, ID_QUALITY)
	for _, q := range []string{"최고화질", "2160p", "1440p", "1080p", "720p", "480p", "360p"} {
		addComboItem(ui.quality, q)
	}
	send(ui.quality, CB_SETCURSEL, 0, 0)

	toggleY := L.cardC.Top + 122
	cardCW := L.cardC.Right - L.cardC.Left
	_ = cardCW
	ui.playlist = createControl("BUTTON", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, L.cardC.Left+24, toggleY, 250, 40, hwnd, ID_PLAYLIST)
	registerToggle(ui.playlist, "재생목록 전체", "")
	ui.subtitle = createControl("BUTTON", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, L.cardC.Left+24+270, toggleY, 250, 40, hwnd, ID_SUBTITLE)
	registerToggle(ui.subtitle, "한글·영문 자막", "")
	ui.ssl = createControl("BUTTON", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, L.cardC.Left+24+540, toggleY, 250, 40, hwnd, ID_SSL)
	registerToggle(ui.ssl, "사내망 SSL 호환 모드", "인증서 오류 시에만 사용")

	// ---- 액션 버튼 행 ----
	ui.start = ownerDrawButton("다운로드 시작", L.btnRow.Left, L.btnRow.Top, 190, 52, hwnd, ID_START)
	registerButton(ui.start, btnPrimary, "다운로드 시작")
	controlBackdrop[ui.start] = rgb(224, 229, 246)
	ui.cancel = ownerDrawButton("취소", L.btnRow.Left+206, L.btnRow.Top, 110, 52, hwnd, ID_CANCEL)
	registerButton(ui.cancel, btnDanger, "취소")
	controlBackdrop[ui.cancel] = rgb(224, 229, 246)
	ui.open = ownerDrawButton("저장 폴더 열기", L.btnRow.Left+330, L.btnRow.Top, 170, 52, hwnd, ID_OPEN)
	registerButton(ui.open, btnNeutral, "저장 폴더 열기")
	controlBackdrop[ui.open] = rgb(224, 229, 246)
	ui.update = ownerDrawButton("도구 업데이트", L.btnRow.Left+516, L.btnRow.Top, 170, 52, hwnd, ID_UPDATE)
	registerButton(ui.update, btnNeutral, "도구 업데이트")
	controlBackdrop[ui.update] = rgb(224, 229, 246)
	enable(ui.cancel, false)

	// ---- 카드 D: 진행 상황 ----
	progW := (L.cardD.Right - L.cardD.Left) - 48
	ui.progress, _, _ = procCreateWindowExW.Call(
		0,
		uintptr(unsafe.Pointer(utf16Ptr(progressClassName))),
		uintptr(unsafe.Pointer(utf16Ptr(""))),
		WS_CHILD|WS_VISIBLE,
		uintptr(L.cardD.Left+24), uintptr(L.cardD.Top+40), uintptr(progW), uintptr(16),
		hwnd, uintptr(ID_PROGRESS), 0, 0,
	)
	ui.status = createControl("STATIC", "준비됨", WS_CHILD|WS_VISIBLE|SS_OWNERDRAW, L.cardD.Left+24, L.cardD.Top+64, progW, 24, hwnd, ID_STATUS)
	controlBackdrop[ui.status] = backdropCard

	// ---- 카드 E: 작업 로그 ----
	logY := L.cardE.Top + 44
	logW := (L.cardE.Right - L.cardE.Left) - 48
	logH := (L.cardE.Bottom - L.cardE.Top) - 44 - 16
	ui.log = createControl("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|ES_LEFT|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY|WS_VSCROLL, L.cardE.Left+24, logY, logW, logH, hwnd, ID_LOG)
	send(ui.log, WM_SETFONT, ui.fontMono, 1)
}

// ============================================================
// 메인 창 프로시저
// ============================================================

const SC_MOVE_HTCAPTION = 0xF012

func wndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		ui.main = hwnd
		createUI(hwnd)
		procSetTimer.Call(hwnd, 1, 100, 0)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		var ps PAINTSTRUCT
		hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		w, h := rc.Right-rc.Left, rc.Bottom-rc.Top
		memDC, _, _ := procCreateCompatibleDC.Call(hdc)
		bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
		old := selectObj(memDC, bmp)
		paintMainBackground(memDC, w, h)
		procBitBlt.Call(hdc, 0, 0, uintptr(w), uintptr(h), memDC, 0, 0, 0x00CC0020)
		selectObj(memDC, old)
		procDeleteDC.Call(memDC)
		deleteObj(bmp)
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case WM_LBUTTONDOWN:
		x := int32(int16(loword(lParam)))
		y := int32(int16(hiword(lParam)))
		if y >= 0 && y < L.titleBarH && x < L.winW-84 {
			procReleaseCapture.Call()
			procSendMessageW.Call(hwnd, WM_SYSCOMMAND, SC_MOVE_HTCAPTION, 0)
		}
		return 0
	case WM_DRAWITEM:
		dis := (*DRAWITEMSTRUCT)(unsafe.Pointer(lParam))
		switch dis.CtlID {
		case uint32(ID_START), uint32(ID_CANCEL), uint32(ID_OPEN), uint32(ID_UPDATE), uint32(ID_BROWSE):
			drawOwnerButton(dis)
		case uint32(ID_PLAYLIST), uint32(ID_SUBTITLE), uint32(ID_SSL):
			drawOwnerToggle(dis)
		case uint32(ID_STATUS):
			drawOwnerStatus(dis)
		case uint32(ID_MINBTN), uint32(ID_CLOSEBTN):
			drawTitleBarButton(dis)
		}
		return 1
	case WM_COMMAND:
		id := int(loword(wParam))
		code := int(hiword(wParam))
		switch id {
		case ID_BROWSE:
			if code == BN_CLICKED {
				chooseFolder()
			}
		case ID_START:
			if code == BN_CLICKED {
				startDownload()
			}
		case ID_CANCEL:
			if code == BN_CLICKED {
				cancelDownload()
			}
		case ID_OPEN:
			if code == BN_CLICKED {
				openFolder()
			}
		case ID_UPDATE:
			if code == BN_CLICKED {
				updateTools()
			}
		case ID_FORMAT:
			if code == CBN_SELCHANGE && !running.Load() {
				idx := int(send(ui.format, CB_GETCURSEL, 0, 0))
				enable(ui.quality, idx == 0)
			}
		case ID_PLAYLIST, ID_SUBTITLE, ID_SSL:
			if code == BN_CLICKED {
				var target uintptr
				switch id {
				case ID_PLAYLIST:
					target = ui.playlist
				case ID_SUBTITLE:
					target = ui.subtitle
				case ID_SSL:
					target = ui.ssl
				}
				toggleState[target] = !toggleState[target]
				invalidate(target)
			}
		case ID_MINBTN:
			if code == BN_CLICKED {
				procShowWindow.Call(hwnd, SW_MINIMIZE)
			}
		case ID_CLOSEBTN:
			if code == BN_CLICKED {
				procSendMessageW.Call(hwnd, WM_CLOSE, 0, 0)
			}
		}
		return 0
	case WM_TIMER:
		drainUpdates()
		return 0
	case WM_CTLCOLORSTATIC:
		procSetBkMode.Call(wParam, TRANSPARENT_BK)
		procSetTextColor.Call(wParam, clrLabel)
		return brushBG
	case WM_CTLCOLOREDIT, WM_CTLCOLORLISTBOX:
		hCtl := lParam
		if hCtl == ui.log {
			procSetBkColor.Call(wParam, clrLogBg)
			procSetTextColor.Call(wParam, clrLogText)
			return brushLog
		}
		procSetBkColor.Call(wParam, clrInputBg)
		procSetTextColor.Call(wParam, clrInputText)
		return brushEdit
	case WM_CLOSE:
		if running.Load() {
			answer := messageBox(hwnd, "다운로드가 진행 중입니다. 작업을 취소하고 종료할까요?", appTitle, MB_YESNO|MB_ICONWARNING)
			if answer != IDYES {
				return 0
			}
			cancelDownload()
		}
		procDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		for _, f := range []uintptr{ui.font, ui.fontBold, ui.fontTitle, ui.fontSmall, ui.fontMono} {
			deleteObj(f)
		}
		deleteObj(brushBG)
		deleteObj(brushEdit)
		deleteObj(brushLog)
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

// ============================================================
// 백엔드 로직 (다운로드 도구 준비 / 실행) - 원본 기능 그대로 유지
// ============================================================

func chooseFolder() {
	display := make([]uint16, 260)
	bi := BROWSEINFO{
		HwndOwner:      ui.main,
		PszDisplayName: &display[0],
		LpszTitle:      utf16Ptr("저장할 폴더를 선택하세요."),
		UlFlags:        BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE,
	}
	pidl, _, _ := procSHBrowseForFolderW.Call(uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return
	}
	defer procCoTaskMemFree.Call(pidl)
	pathBuf := make([]uint16, 32768)
	ok, _, _ := procSHGetPathFromIDListW.Call(pidl, uintptr(unsafe.Pointer(&pathBuf[0])))
	if ok != 0 {
		setText(ui.folder, syscall.UTF16ToString(pathBuf))
	}
}

func openFolder() {
	folder := strings.TrimSpace(getText(ui.folder))
	if folder == "" {
		return
	}
	os.MkdirAll(folder, 0755)
	procShellExecuteW.Call(
		ui.main,
		uintptr(unsafe.Pointer(utf16Ptr("open"))),
		uintptr(unsafe.Pointer(utf16Ptr(folder))),
		0, 0, SW_SHOWNORMAL,
	)
}

func cancelDownload() {
	cancelMu.Lock()
	cancel := cancelCurrent
	cancelMu.Unlock()
	if cancel != nil {
		cancel()
	}
}

func updateTools() {
	if running.Load() {
		return
	}
	setRunningState(true)
	setProgressPercent(0)
	setStatusText("다운로드 도구를 업데이트하는 중...")
	setText(ui.log, "")
	userLog("[도구] 최신 구성요소 확인 시작")
	insecure := toggleState[ui.ssl]
	ctx, cancel := context.WithCancel(context.Background())
	cancelMu.Lock()
	cancelCurrent = cancel
	cancelMu.Unlock()
	go func() {
		defer func() {
			cancelMu.Lock()
			cancelCurrent = nil
			cancelMu.Unlock()
		}()
		if err := ensureTools(ctx, true, insecure); err != nil {
			if ctx.Err() != nil {
				updates <- uiUpdate{kind: "cancelled"}
				return
			}
			updates <- uiUpdate{kind: "done", text: "도구 업데이트 실패: " + err.Error(), ok: false}
			return
		}
		updates <- uiUpdate{kind: "done", text: "다운로드 도구 업데이트가 완료되었습니다.", ok: true}
	}()
}

func startDownload() {
	if running.Load() {
		return
	}
	rawURLs := strings.TrimSpace(getText(ui.url))
	folder := strings.TrimSpace(getText(ui.folder))
	urls, err := parseYouTubeURLs(rawURLs)
	if err != nil {
		messageBox(ui.main, err.Error(), appTitle, MB_OK|MB_ICONERROR)
		return
	}
	if folder == "" {
		messageBox(ui.main, "저장 폴더를 선택하세요.", appTitle, MB_OK|MB_ICONERROR)
		return
	}
	if err := os.MkdirAll(folder, 0755); err != nil {
		messageBox(ui.main, "저장 폴더를 만들 수 없습니다: "+err.Error(), appTitle, MB_OK|MB_ICONERROR)
		return
	}

	formatIdx := int(send(ui.format, CB_GETCURSEL, 0, 0))
	qualityIdx := int(send(ui.quality, CB_GETCURSEL, 0, 0))
	playlist := toggleState[ui.playlist]
	subtitle := toggleState[ui.subtitle]
	insecure := toggleState[ui.ssl]

	setRunningState(true)
	setProgressPercent(0)
	setStatusText("필요한 구성요소를 확인하는 중...")
	setText(ui.log, "")
	userLog(fmt.Sprintf("[시작] 링크 %d개 확인", len(urls)))
	if insecure {
		userLog("[안내] 사내망 SSL 호환 모드 사용 중 (인증서 검증 생략)")
	}

	ctx, cancel := context.WithCancel(context.Background())
	cancelMu.Lock()
	cancelCurrent = cancel
	cancelMu.Unlock()

	go func() {
		defer func() {
			cancelMu.Lock()
			cancelCurrent = nil
			cancelMu.Unlock()
		}()
		if err := ensureTools(ctx, false, insecure); err != nil {
			if ctx.Err() != nil {
				updates <- uiUpdate{kind: "cancelled"}
				return
			}
			updates <- uiUpdate{kind: "done", text: "구성요소 준비 실패: " + err.Error(), ok: false}
			return
		}
		success, failed, err := executeDownload(ctx, urls, folder, formatIdx, qualityIdx, playlist, subtitle, insecure)
		if ctx.Err() != nil {
			updates <- uiUpdate{kind: "cancelled"}
			return
		}
		if err != nil && success == 0 {
			updates <- uiUpdate{kind: "done", text: "다운로드 실패: " + friendlyError(err.Error()), ok: false}
			return
		}
		if failed > 0 {
			updates <- uiUpdate{kind: "donewarn", text: fmt.Sprintf("작업 완료: %d개 성공, %d개 실패. 작업 진행 기록을 확인하세요.", success, failed)}
			return
		}
		updates <- uiUpdate{kind: "done", text: fmt.Sprintf("다운로드가 완료되었습니다. (%d개)", success), ok: true}
	}()
}

func parseYouTubeURLs(raw string) ([]string, error) {
	if raw == "" {
		return nil, fmt.Errorf("YouTube 주소를 입력하세요.")
	}
	fields := strings.FieldsFunc(raw, func(r rune) bool { return r == '\n' || r == '\r' || r == '\t' || r == ' ' })
	var out []string
	seen := map[string]bool{}
	for _, s := range fields {
		s = strings.TrimSpace(s)
		if s == "" {
			continue
		}
		u, err := url.Parse(s)
		if err != nil || u.Scheme == "" || u.Host == "" {
			continue
		}
		host := strings.ToLower(strings.TrimPrefix(u.Hostname(), "www."))
		if host != "youtube.com" && host != "m.youtube.com" && host != "music.youtube.com" && host != "youtu.be" {
			continue
		}
		if !seen[s] {
			seen[s] = true
			out = append(out, s)
		}
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("올바른 YouTube 주소가 없습니다.")
	}
	return out, nil
}

func qualityHeight(idx int) int {
	switch idx {
	case 1:
		return 2160
	case 2:
		return 1440
	case 3:
		return 1080
	case 4:
		return 720
	case 5:
		return 480
	case 6:
		return 360
	default:
		return 0
	}
}

func executeDownload(ctx context.Context, urls []string, folder string, formatIdx, qualityIdx int, playlist, subtitle, insecure bool) (int, int, error) {
	bin := toolDir()
	ytdlp := filepath.Join(bin, "yt-dlp.exe")
	ffmpeg := filepath.Join(bin, "ffmpeg.exe")
	ffprobe := filepath.Join(bin, "ffprobe.exe")
	deno := filepath.Join(bin, "deno.exe")
	success, failed := 0, 0
	var lastErr error

	for i, target := range urls {
		if ctx.Err() != nil {
			return success, failed, ctx.Err()
		}
		index := i + 1
		pathLog, err := os.CreateTemp("", "hjw-ytdlp-paths-*.txt")
		if err != nil {
			failed++
			lastErr = fmt.Errorf("저장 경로 기록 파일 생성 실패: %w", err)
			updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 실패: %s", index, len(urls), lastErr.Error())}
			continue
		}
		pathLogPath := pathLog.Name()
		pathLog.Close()
		baseArgs := []string{
			"--no-color", "--newline", "--progress", "--progress-delta", "0.2", "--encoding", "utf-8",
			"--windows-filenames", "--continue", "--no-overwrites",
			"--paths", folder, "--ffmpeg-location", ffmpeg, "--js-runtimes", "deno:" + deno,
			"--progress-template", "download:HJW_PROGRESS:%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s",
			"--print", "before_dl:HJW_TITLE:%(title)s",
			"--print-to-file", "after_move:%(filepath)s", pathLogPath,
			"-o", "%(title).180B [%(id)s].%(ext)s",
		}
		if insecure {
			baseArgs = append(baseArgs, "--no-check-certificates")
		}
		if playlist {
			baseArgs = append(baseArgs, "--yes-playlist")
		} else {
			baseArgs = append(baseArgs, "--no-playlist")
		}
		if subtitle {
			baseArgs = append(baseArgs, "--write-subs", "--write-auto-subs", "--sub-langs", "ko.*,en.*", "--convert-subs", "srt")
		}
		if formatIdx == 1 {
			baseArgs = append(baseArgs, "--extract-audio", "--audio-format", "mp3", "--audio-quality", "0", "--embed-thumbnail", "--add-metadata")
		} else {
			h := qualityHeight(qualityIdx)
			if h > 0 {
				format := fmt.Sprintf("bv*[height<=%d][ext=mp4]+ba[ext=m4a]/bv*[height<=%d]+ba/b[height<=%d]", h, h, h)
				baseArgs = append(baseArgs, "-f", format)
			} else {
				baseArgs = append(baseArgs, "-f", "bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b")
			}
			baseArgs = append(baseArgs, "--merge-output-format", "mp4", "--add-metadata")
		}
		baseArgs = append(baseArgs, target)

		updates <- uiUpdate{kind: "status", text: fmt.Sprintf("[%d/%d] 영상 정보를 확인하는 중...", index, len(urls))}
		updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 영상 정보 확인 중", index, len(urls))}
		updateURLProgress(index, len(urls), 0.02)
		finalPaths, err := runOneDownload(ctx, ytdlp, baseArgs, pathLogPath, index, len(urls))
		os.Remove(pathLogPath)
		if err != nil {
			if ctx.Err() != nil {
				return success, failed, ctx.Err()
			}
			failed++
			lastErr = err
			updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 실패: %s", index, len(urls), friendlyError(err.Error()))}
			continue
		}
		updateURLProgress(index, len(urls), 0.82)
		for _, finalPath := range finalPaths {
			updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 저장: %s", index, len(urls), filepath.Base(finalPath))}
		}
		if formatIdx == 0 {
			if len(finalPaths) == 0 {
				err = fmt.Errorf("다운로드한 파일의 저장 경로를 확인하지 못했습니다")
			} else {
				for fileIndex, finalPath := range finalPaths {
					err = ensureEditingCompatible(ctx, ffmpeg, ffprobe, finalPath, index, len(urls), fileIndex+1, len(finalPaths))
					if err != nil {
						break
					}
				}
			}
			if err != nil {
				if ctx.Err() != nil {
					return success, failed, ctx.Err()
				}
				failed++
				lastErr = err
				updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 편집 호환 변환 실패: %s", index, len(urls), friendlyError(err.Error()))}
				continue
			}
		}
		success++
		updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 완료", index, len(urls))}
		updates <- uiUpdate{kind: "progress", value: int(float64(index) / float64(len(urls)) * 100)}
	}
	return success, failed, lastErr
}

func runOneDownload(ctx context.Context, ytdlp string, args []string, pathLogPath string, index, total int) ([]string, error) {
	cmd := exec.CommandContext(ctx, ytdlp, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	cmd.Env = append(os.Environ(), "PYTHONUTF8=1", "PYTHONIOENCODING=utf-8")
	pr, pw := io.Pipe()
	cmd.Stdout = pw
	cmd.Stderr = pw
	if err := cmd.Start(); err != nil {
		return nil, err
	}

	scanDone := make(chan struct{})
	var lastError string
	var lastLoggedBucket = -1
	go func() {
		defer close(scanDone)
		scanner := bufio.NewScanner(pr)
		scanner.Buffer(make([]byte, 4096), 1024*1024)
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())
			if line == "" {
				continue
			}
			lower := strings.ToLower(line)
			if strings.HasPrefix(line, "HJW_TITLE:") {
				title := strings.TrimSpace(strings.TrimPrefix(line, "HJW_TITLE:"))
				updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 제목: %s", index, total, title)}
				updates <- uiUpdate{kind: "status", text: fmt.Sprintf("[%d/%d] %s", index, total, title)}
				continue
			}
			if strings.HasPrefix(line, "HJW_PROGRESS:") {
				payload := strings.TrimSpace(strings.TrimPrefix(line, "HJW_PROGRESS:"))
				parts := strings.Split(payload, "|")
				percentText := strings.TrimSpace(parts[0])
				if m := progressRE.FindStringSubmatch(percentText); len(m) == 2 {
					if f, e := strconv.ParseFloat(m[1], 64); e == nil {
						updateURLProgress(index, total, 0.82*f/100.0)
						speed, eta := "", ""
						if len(parts) > 1 {
							speed = strings.TrimSpace(parts[1])
						}
						if len(parts) > 2 {
							eta = strings.TrimSpace(parts[2])
						}
						status := fmt.Sprintf("[%d/%d] %.1f%%", index, total, f)
						if speed != "" && speed != "NA" {
							status += " · " + speed
						}
						if eta != "" && eta != "NA" {
							status += " · 남은 시간 " + eta
						}
						updates <- uiUpdate{kind: "status", text: status}
						bucket := int(f) / 10
						if bucket > lastLoggedBucket && bucket > 0 && bucket < 10 {
							lastLoggedBucket = bucket
							updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 다운로드 %d%%", index, total, bucket*10)}
						}
					}
				}
				continue
			}
			if strings.Contains(lower, "certificate_verify_failed") || strings.Contains(lower, "self signed certificate") {
				lastError = line
				continue
			}
			if strings.Contains(lower, "error:") || strings.Contains(lower, "private video") || strings.Contains(lower, "video unavailable") || strings.Contains(lower, "sign in") {
				lastError = line
			}
		}
	}()
	waitErr := cmd.Wait()
	pw.Close()
	<-scanDone
	pr.Close()
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}
	if waitErr != nil {
		if lastError != "" {
			return nil, fmt.Errorf("%s", lastError)
		}
		return nil, waitErr
	}
	paths, err := readDownloadedPaths(pathLogPath)
	if err != nil {
		return nil, err
	}
	return paths, nil
}

func readDownloadedPaths(pathLogPath string) ([]string, error) {
	data, err := os.ReadFile(pathLogPath)
	if err != nil {
		return nil, fmt.Errorf("다운로드 경로 기록 읽기 실패: %w", err)
	}
	value := strings.TrimPrefix(string(data), "\uFEFF")
	seen := make(map[string]bool)
	var paths []string
	for _, line := range nonEmptyLines(value) {
		path := filepath.Clean(strings.TrimSpace(line))
		key := strings.ToLower(path)
		if seen[key] {
			continue
		}
		if !fileExists(path) {
			return nil, fmt.Errorf("다운로드 파일을 찾지 못했습니다: %s", path)
		}
		seen[key] = true
		paths = append(paths, path)
	}
	if len(paths) == 0 {
		return nil, fmt.Errorf("yt-dlp가 저장 경로를 기록하지 않았습니다")
	}
	return paths, nil
}

func updateURLProgress(index, total int, fraction float64) {
	if fraction < 0 {
		fraction = 0
	}
	if fraction > 1 {
		fraction = 1
	}
	overall := ((float64(index-1) + fraction) / float64(total)) * 100.0
	updates <- uiUpdate{kind: "progress", value: int(overall + 0.5)}
}

func updateFileProgress(urlIndex, urlTotal, fileIndex, fileTotal int, fraction float64) {
	if fileTotal < 1 {
		fileTotal = 1
	}
	postFraction := (float64(fileIndex-1) + fraction) / float64(fileTotal)
	updateURLProgress(urlIndex, urlTotal, 0.82+0.18*postFraction)
}

// ensureEditingCompatible keeps an already compatible H.264/AAC MP4 untouched.
// AV1, VP9, Opus and 10-bit sources are converted to the broadest editor-safe
// combination: H.264 (8-bit yuv420p) video and AAC audio in an MP4 container.
func ensureEditingCompatible(ctx context.Context, ffmpeg, ffprobe, path string, index, total, fileIndex, fileTotal int) error {
	updateFileProgress(index, total, fileIndex, fileTotal, 0.05)
	videoCodec, pixelFormat, err := probeVideo(ctx, ffprobe, path)
	if err != nil {
		return fmt.Errorf("영상 코덱 확인 실패: %w", err)
	}
	audioCodec, hasAudio, err := probeAudio(ctx, ffprobe, path)
	if err != nil {
		return fmt.Errorf("음성 코덱 확인 실패: %w", err)
	}

	videoOK := strings.EqualFold(videoCodec, "h264") &&
		(strings.EqualFold(pixelFormat, "yuv420p") || strings.EqualFold(pixelFormat, "yuvj420p"))
	audioOK := !hasAudio || strings.EqualFold(audioCodec, "aac")
	if videoOK && audioOK {
		updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 편집 호환 확인: H.264/AAC", index, total)}
		updateFileProgress(index, total, fileIndex, fileTotal, 1)
		return nil
	}

	updates <- uiUpdate{kind: "status", text: fmt.Sprintf("[%d/%d] 편집용 H.264/AAC로 변환 중...", index, total)}
	updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 코덱 변환: %s/%s -> H.264/AAC", index, total, videoCodec, audioCodec)}

	tempPath := path + ".hjw-compatible.tmp.mp4"
	backupPath := path + ".hjw-original.bak"
	os.Remove(tempPath)
	os.Remove(backupPath)

	args := []string{"-y", "-hide_banner", "-i", path, "-map", "0:v:0", "-map", "0:a?", "-map_metadata", "0", "-map_chapters", "0"}
	if videoOK {
		args = append(args, "-c:v", "copy")
	} else {
		args = append(args, "-c:v", "libx264", "-preset", "fast", "-crf", "20", "-pix_fmt", "yuv420p")
	}
	if hasAudio {
		if audioOK {
			args = append(args, "-c:a", "copy")
		} else {
			args = append(args, "-c:a", "aac", "-b:a", "192k")
		}
	}
	args = append(args, "-movflags", "+faststart", tempPath)

	duration, _ := probeDuration(ctx, ffprobe, path)
	args = append([]string{"-progress", "pipe:1", "-nostats"}, args...)
	if runErr := runFFmpegWithProgress(ctx, ffmpeg, args, duration, func(fraction float64) {
		updateFileProgress(index, total, fileIndex, fileTotal, 0.15+0.8*fraction)
	}); runErr != nil {
		os.Remove(tempPath)
		return runErr
	}
	if ctx.Err() != nil {
		os.Remove(tempPath)
		return ctx.Err()
	}
	if err := replaceDownloadedFile(path, tempPath, backupPath); err != nil {
		os.Remove(tempPath)
		return err
	}
	updates <- uiUpdate{kind: "log", text: fmt.Sprintf("[%d/%d] 편집 호환 변환 완료: H.264/AAC MP4", index, total)}
	updateFileProgress(index, total, fileIndex, fileTotal, 1)
	return nil
}

func probeVideo(ctx context.Context, ffprobe, path string) (string, string, error) {
	cmd := exec.CommandContext(ctx, ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_name,pix_fmt", "-of", "default=noprint_wrappers=1:nokey=1", path)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	output, err := cmd.CombinedOutput()
	if err != nil {
		return "", "", detailedCommandError("FFprobe", err, output)
	}
	lines := nonEmptyLines(string(output))
	if len(lines) < 2 {
		return "", "", fmt.Errorf("영상 스트림 정보가 없습니다")
	}
	return lines[0], lines[1], nil
}

func probeAudio(ctx context.Context, ffprobe, path string) (string, bool, error) {
	cmd := exec.CommandContext(ctx, ffprobe, "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_name", "-of", "default=noprint_wrappers=1:nokey=1", path)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	output, err := cmd.CombinedOutput()
	if err != nil {
		return "", false, detailedCommandError("FFprobe", err, output)
	}
	lines := nonEmptyLines(string(output))
	if len(lines) == 0 {
		return "", false, nil
	}
	return lines[0], true, nil
}

func probeDuration(ctx context.Context, ffprobe, path string) (float64, error) {
	cmd := exec.CommandContext(ctx, ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", path)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	output, err := cmd.CombinedOutput()
	if err != nil {
		return 0, detailedCommandError("FFprobe", err, output)
	}
	duration, err := strconv.ParseFloat(strings.TrimSpace(string(output)), 64)
	if err != nil || duration <= 0 {
		return 0, fmt.Errorf("영상 길이 확인 실패")
	}
	return duration, nil
}

func runFFmpegWithProgress(ctx context.Context, ffmpeg string, args []string, duration float64, onProgress func(float64)) error {
	cmd := exec.CommandContext(ctx, ffmpeg, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return fmt.Errorf("FFmpeg 진행률 연결 실패: %w", err)
	}
	var stderr strings.Builder
	cmd.Stderr = &stderr
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("FFmpeg 실행 실패: %w", err)
	}
	scanner := bufio.NewScanner(stdout)
	scanner.Buffer(make([]byte, 4096), 1024*1024)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if strings.HasPrefix(line, "out_time_us=") && duration > 0 {
			microseconds, parseErr := strconv.ParseInt(strings.TrimPrefix(line, "out_time_us="), 10, 64)
			if parseErr == nil {
				fraction := float64(microseconds) / (duration * 1000000.0)
				if fraction > 1 {
					fraction = 1
				}
				onProgress(fraction)
			}
		}
	}
	waitErr := cmd.Wait()
	if ctx.Err() != nil {
		return ctx.Err()
	}
	if waitErr != nil {
		return detailedCommandError("FFmpeg 변환", waitErr, []byte(stderr.String()))
	}
	onProgress(1)
	return nil
}

func detailedCommandError(label string, err error, output []byte) error {
	message := strings.TrimSpace(string(output))
	if len(message) > 1200 {
		message = message[len(message)-1200:]
	}
	if message == "" {
		return fmt.Errorf("%s 실패: %w", label, err)
	}
	return fmt.Errorf("%s 실패: %w (%s)", label, err, message)
}

func nonEmptyLines(value string) []string {
	var lines []string
	for _, line := range strings.FieldsFunc(value, func(r rune) bool { return r == '\r' || r == '\n' }) {
		line = strings.TrimSpace(line)
		if line != "" {
			lines = append(lines, line)
		}
	}
	return lines
}

func replaceDownloadedFile(original, converted, backup string) error {
	if err := os.Rename(original, backup); err != nil {
		return fmt.Errorf("원본 파일 임시 보관 실패: %w", err)
	}
	if err := os.Rename(converted, original); err != nil {
		_ = os.Rename(backup, original)
		return fmt.Errorf("변환 파일 교체 실패: %w", err)
	}
	if err := os.Remove(backup); err != nil {
		return fmt.Errorf("임시 원본 정리 실패: %w", err)
	}
	return nil
}

func toolDir() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base = os.TempDir()
	}
	return filepath.Join(base, "HJWYouTubeDownloader", "bin")
}

func ensureTools(ctx context.Context, force, insecure bool) error {
	dir := toolDir()
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	ytdlp := filepath.Join(dir, "yt-dlp.exe")
	ffmpeg := filepath.Join(dir, "ffmpeg.exe")
	ffprobe := filepath.Join(dir, "ffprobe.exe")
	deno := filepath.Join(dir, "deno.exe")

	if force || !fileExists(ytdlp) {
		updates <- uiUpdate{kind: "status", text: "yt-dlp 다운로드 중..."}
		updates <- uiUpdate{kind: "log", text: "[도구] yt-dlp를 공식 배포처에서 받습니다."}
		if err := downloadFile(ctx, "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe", ytdlp, "yt-dlp", insecure); err != nil {
			return err
		}
	}

	if force || !fileExists(ffmpeg) || !fileExists(ffprobe) {
		updates <- uiUpdate{kind: "status", text: "FFmpeg 다운로드 중..."}
		updates <- uiUpdate{kind: "log", text: "[도구] 영상·음원 변환용 FFmpeg를 받습니다."}
		zipPath := filepath.Join(dir, "ffmpeg.zip")
		os.Remove(zipPath)
		if err := downloadFile(ctx, "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip", zipPath, "FFmpeg", insecure); err != nil {
			return err
		}
		if err := extractNamedExecutables(zipPath, dir, map[string]string{"ffmpeg.exe": "ffmpeg.exe", "ffprobe.exe": "ffprobe.exe"}); err != nil {
			return err
		}
		os.Remove(zipPath)
	}

	if force || !fileExists(deno) {
		updates <- uiUpdate{kind: "status", text: "Deno 다운로드 중..."}
		updates <- uiUpdate{kind: "log", text: "[도구] YouTube 분석용 JavaScript 런타임을 받습니다."}
		zipPath := filepath.Join(dir, "deno.zip")
		os.Remove(zipPath)
		if err := downloadFile(ctx, "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip", zipPath, "Deno", insecure); err != nil {
			return err
		}
		if err := extractNamedExecutables(zipPath, dir, map[string]string{"deno.exe": "deno.exe"}); err != nil {
			return err
		}
		os.Remove(zipPath)
	}
	updates <- uiUpdate{kind: "progress", value: 0}
	updates <- uiUpdate{kind: "log", text: "[도구] 구성요소 준비 완료"}
	return nil
}

func downloadFile(ctx context.Context, src, dst, label string, insecure bool) error {
	tmp := dst + ".part"
	os.Remove(tmp)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, src, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "HJW-YouTube-Downloader/1.0")
	transport := http.DefaultTransport.(*http.Transport).Clone()
	if insecure {
		transport.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	}
	client := &http.Client{Timeout: 0, Transport: transport}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("%s 다운로드 HTTP 오류: %s", label, resp.Status)
	}
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	defer f.Close()

	total := resp.ContentLength
	buf := make([]byte, 256*1024)
	var written int64
	last := time.Now()
	for {
		n, readErr := resp.Body.Read(buf)
		if n > 0 {
			if _, err := f.Write(buf[:n]); err != nil {
				return err
			}
			written += int64(n)
			if total > 0 && time.Since(last) > 150*time.Millisecond {
				pct := int(float64(written) / float64(total) * 100)
				updates <- uiUpdate{kind: "progress", value: pct}
				updates <- uiUpdate{kind: "status", text: fmt.Sprintf("%s 다운로드 중... %d%%", label, pct)}
				last = time.Now()
			}
		}
		if readErr == io.EOF {
			break
		}
		if readErr != nil {
			return readErr
		}
	}
	if err := f.Close(); err != nil {
		return err
	}
	os.Remove(dst)
	if err := os.Rename(tmp, dst); err != nil {
		return err
	}
	updates <- uiUpdate{kind: "log", text: "[도구] " + label + " 다운로드 완료"}
	return nil
}

func extractNamedExecutables(zipPath, dstDir string, wanted map[string]string) error {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return fmt.Errorf("압축 파일 열기 실패: %w", err)
	}
	defer zr.Close()
	found := map[string]bool{}
	for _, zf := range zr.File {
		base := strings.ToLower(filepath.Base(zf.Name))
		outName, ok := wanted[base]
		if !ok {
			continue
		}
		rc, err := zf.Open()
		if err != nil {
			return err
		}
		outPath := filepath.Join(dstDir, outName)
		tmp := outPath + ".part"
		out, err := os.Create(tmp)
		if err != nil {
			rc.Close()
			return err
		}
		_, copyErr := io.Copy(out, rc)
		closeErr := out.Close()
		rc.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
		os.Remove(outPath)
		if err := os.Rename(tmp, outPath); err != nil {
			return err
		}
		found[base] = true
	}
	for name := range wanted {
		if !found[strings.ToLower(name)] {
			return fmt.Errorf("압축 파일에서 %s을(를) 찾지 못했습니다.", name)
		}
	}
	return nil
}

func fileExists(path string) bool {
	st, err := os.Stat(path)
	return err == nil && !st.IsDir() && st.Size() > 0
}

func friendlyError(s string) string {
	lower := strings.ToLower(s)
	switch {
	case strings.Contains(lower, "certificate_verify_failed") || strings.Contains(lower, "self signed certificate"):
		return "사내 보안장비/프록시가 HTTPS 인증서를 바꿔 전달하는 것으로 보입니다. 회사 정책상 허용되는 경우 '사내망 SSL 호환 모드'를 켜고 다시 시도하세요."
	case strings.Contains(lower, "sign in") || strings.Contains(lower, "cookies"):
		return "로그인이 필요하거나 접근이 제한된 영상입니다. 공개 영상인지 확인하세요."
	case strings.Contains(lower, "403") || strings.Contains(lower, "forbidden"):
		return "YouTube가 요청을 차단했습니다 (403 Forbidden). 대부분 다운로드 도구(yt-dlp)가 오래되어 YouTube의 최신 보안 방식을 처리하지 못해 발생합니다. 화면의 '도구 업데이트' 버튼을 눌러 최신 버전으로 갱신한 뒤 다시 시도하세요. 갱신 후에도 반복되면 잠시 후 다시 시도하거나 다른 영상으로 확인해보세요."
	case strings.Contains(lower, "private video"):
		return "비공개 영상은 다운로드할 수 없습니다."
	case strings.Contains(lower, "video unavailable"):
		return "영상을 사용할 수 없습니다. 주소 또는 공개 상태를 확인하세요."
	case strings.Contains(lower, "network") || strings.Contains(lower, "connection"):
		return "네트워크 연결에 실패했습니다. 인터넷 연결을 확인하세요."
	default:
		return s
	}
}

func userHomeDir() string {
	if h, err := os.UserHomeDir(); err == nil && h != "" {
		return h
	}
	return os.Getenv("USERPROFILE")
}

// ============================================================
// 진입점
// ============================================================

const (
	DWMWA_WINDOW_CORNER_PREFERENCE = 33
	DWMWCP_ROUND                   = 2
	DWMWA_SYSTEMBACKDROP_TYPE      = 38
	DWMSBT_TRANSIENTWINDOW         = 3
)

func main() {
	runtime.LockOSThread()
	procSetProcessDPIAware.Call()
	procCoInitializeEx.Call(0, COINIT_APARTMENTTHREADED)
	defer procCoUninitialize.Call()

	icc := INITCOMMONCONTROLSEX{DwSize: uint32(unsafe.Sizeof(INITCOMMONCONTROLSEX{})), DwICC: 0x00000020}
	procInitCommonControlsEx.Call(uintptr(unsafe.Pointer(&icc)))

	brushBG, _, _ = procCreateSolidBrush.Call(clrBgTop)
	brushEdit, _, _ = procCreateSolidBrush.Call(clrInputBg)
	brushLog, _, _ = procCreateSolidBrush.Call(clrLogBg)
	hInstance, _, _ := procGetModuleHandleW.Call(0)
	cursor, _, _ := procLoadCursorW.Call(0, IDC_ARROW)
	className := utf16Ptr("HJWYouTubeDownloaderWindow")
	wc := WNDCLASSEX{
		CbSize:        uint32(unsafe.Sizeof(WNDCLASSEX{})),
		LpfnWndProc:   syscall.NewCallback(wndProc),
		HInstance:     hInstance,
		HCursor:       cursor,
		HbrBackground: 0,
		LpszClassName: className,
	}
	atom, _, err := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))
	if atom == 0 {
		messageBox(0, "프로그램 창을 초기화하지 못했습니다: "+err.Error(), appTitle, MB_OK|MB_ICONERROR)
		return
	}

	registerProgressClass(hInstance)

	computeLayout()

	hwnd, _, err := procCreateWindowExW.Call(
		0,
		uintptr(unsafe.Pointer(className)),
		uintptr(unsafe.Pointer(utf16Ptr(appTitle))),
		WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN,
		0x80000000, 0x80000000, uintptr(L.winW), uintptr(L.winH),
		0, 0, hInstance, 0,
	)
	if hwnd == 0 {
		messageBox(0, "프로그램 창을 만들지 못했습니다: "+err.Error(), appTitle, MB_OK|MB_ICONERROR)
		return
	}

	// 라운드 코너 창 영역 지정 (모든 Windows 버전에서 동작)
	rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(L.winW+1), uintptr(L.winH+1), 22, 22)
	procSetWindowRgn.Call(hwnd, rgn, 1)

	// Windows 11 에서는 DWM 라운드 코너/투명 배경 힌트도 함께 적용 (구버전에서는 무시됨)
	pref := int32(DWMWCP_ROUND)
	procDwmSetWindowAttribute.Call(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, uintptr(unsafe.Pointer(&pref)), unsafe.Sizeof(pref))

	// 화면 중앙 배치
	centerWindow(hwnd)

	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)

	var msg MSG
	for {
		ret, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(ret) <= 0 {
			break
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}
}

var procGetSystemMetrics = user32.NewProc("GetSystemMetrics")

func centerWindow(hwnd uintptr) {
	const SM_CXSCREEN = 0
	const SM_CYSCREEN = 1
	sw, _, _ := procGetSystemMetrics.Call(SM_CXSCREEN)
	sh, _, _ := procGetSystemMetrics.Call(SM_CYSCREEN)
	x := (int32(sw) - L.winW) / 2
	y := (int32(sh) - L.winH) / 2
	if x < 0 {
		x = 0
	}
	if y < 0 {
		y = 0
	}
	procMoveWindow.Call(hwnd, uintptr(x), uintptr(y), uintptr(L.winW), uintptr(L.winH), 1)
}
